# منیبین

پایگاه فارسی درس‌ها و سخنرانی‌های استاد حامد رنجبر. این مرحله اسکلت قابل اجرا و RTL، ورود سروری و تنظیمات محیطی را آماده می‌کند؛ هیچ محتوای نمونه یا اطلاعات تأییدنشده‌ای منتشر نمی‌شود.

## فناوری و وضعیت

- Laravel 13 و PHP 8.3 یا جدیدتر؛ قالب‌های Blade و CSS واکنش‌گرا، بدون SPA.
- Vazirmatn به‌صورت محلی از npm بسته‌بندی می‌شود؛ بارگذاری فونت از سرویس بیرونی لازم نیست.
- SQLite و PDO برای توسعه، همراه با قابلیت تغییر اتصال به MySQL یا PostgreSQL از راه متغیرهای محیطی.
- محتوای اصلی و روابط پایدار آن در SQLite/MySQL/PostgreSQL ذخیره می‌شوند. fixtureهای طراحی فقط با `SITE_DEMO_CONTENT=true` نمایش داده می‌شوند و هرگز به پایگاه واقعی seed نمی‌شوند.
- پنل مشترک مدیریت، احراز هویت، نقش سروری مدیر/خواننده، برچسب چندوالدی، جست‌وجوی محتوای منتشرشده و نگهداری خصوصی رسانه فعال است. نام، شعار و نشان سایت در `config/site.php` متمرکز است.
- فایل‌های محیطی و پایگاه‌های SQLite در Git قرار نمی‌گیرند. فایل رسانه در دیسک خصوصی Laravel ذخیره و فقط برای مدیر یا پس از انتشار محتوا سرو می‌شود.

ثبت‌نام عمومی، workflow چندمرحله‌ای تأیید انتشار، نقش‌های جداگانهٔ سردبیر/ناشر، Markdown، صفحه‌بندی گالری و مدیریت پشتیبان خودکار هنوز پیاده نشده‌اند. ورود محدودشده و گذرواژهٔ امن‌اند؛ حساب مدیر با فرمان ترمینال ساخته می‌شود و رمز پیش‌فرض یا مدیر نمونه وجود ندارد.

## مسیرها

| نشانی | بخش |
| --- | --- |
| `/` | صفحهٔ اصلی |
| `/sessions` | آرشیو جلسات |
| `/series` | سلسله‌جلسات |
| `/notes` | یادداشت‌ها |
| `/texts` | مقاله‌ها و متن جلسات |
| `/announcements` | اعلان‌ها |
| `/about` | دربارهٔ استاد |
| `/tags` و `/tags/{slug}` | برچسب‌ها و محتواهای منتشرشدهٔ مرتبط |
| `/gallery` | نگارخانه و نمایش امن فایل‌های منتشرشده |
| `/search` | جست‌وجوی عنوان، خلاصه و متن با همسان‌سازی حروف رایج فارسی/عربی |
| `/login` و `/account` | ورود و حسابِ نیازمند احراز هویت |
| `/admin` | پنل مدیر، پس از ورود با نقش مدیر |

## نصب و اجرا

پیش‌نیازها: PHP 8.3+ با افزونه‌های `mbstring`, `openssl`, `pdo_sqlite`, `fileinfo`, `xml` و `curl`؛ Composer 2؛ Node.js 20.19+ یا 22.12+ و npm.

در ریشهٔ پروژه:

```sh
cp .env.example .env
composer install
npm ci
touch database/database.sqlite
php artisan key:generate
php artisan migrate
npm run build
php artisan serve --host=0.0.0.0 --port=8000
```

پس از migration، نخستین مدیر را در ترمینال بسازید؛ گذرواژه به‌صورت مخفی پرسیده و تأیید می‌شود:

```sh
php artisan content:make-admin admin@example.com "نام مدیر"
```

برای ارتقای حساب موجود باید هم `--promote` را بدهید و هم تأیید تعاملی را انجام دهید. این فرمان را در پایانهٔ امن اجرا کنید، نه در پنل وب.

در Codespaces، پورت `8000` را در پنل **Ports** باز کنید و نشانی forwarding همان پورت را در مرورگر باز کنید. برای HMR، `php artisan serve --host=0.0.0.0 --port=8000` و `npm run dev -- --host 0.0.0.0` را در دو ترمینال اجرا کنید.

## تنظیمات محیط

`.env.example` فقط مقادیر عمومی و نمونه دارد. پس از کپی، `APP_KEY` را با `php artisan key:generate` بسازید و فایل `.env` را منتشر نکنید. متغیرهای مهم:

- `APP_ENV`, `APP_DEBUG`, `APP_URL`, `APP_KEY`, `APP_TIMEZONE`, `TRUSTED_PROXIES`
- `APP_LOCALE`, `APP_FALLBACK_LOCALE`
- `SITE_NAME`, `SITE_TAGLINE`, `SITE_TEACHER`, `SITE_LOGO_PATH`, `SITE_LOGO_MARK`, `SITE_DEMO_CONTENT`
- `DB_CONNECTION`, `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`
- `SESSION_DRIVER`, `CACHE_STORE`, `QUEUE_CONNECTION`, `FILESYSTEM_DISK`

در هاست واقعی، `TRUSTED_PROXIES` را فقط به IP/CIDR پروکسی‌های مورداعتماد همان میزبان محدود کنید؛ مقدار نمونهٔ loopback برای توسعه/Codespaces است. مقادیر `DB_*` را با اطلاعات امن هاست جایگزین کنید؛ برای MySQL یا PostgreSQL درایور متناظر PDO را نیز نصب کنید. `APP_ENV=production` و `APP_DEBUG=false` را تنظیم کنید، سپس اجرا کنید:

```sh
composer install --no-dev --optimize-autoloader
npm ci
npm run build
php artisan migrate --force
php artisan optimize
```

کلید تولیدی، رمز پایگاه‌داده و دیگر اسرار را در تنظیمات امن هاست نگه دارید، نه در Git. مهاجرت از SQLite محلی به پایگاه‌دادهٔ هاست باید با انتقال مستقل و بررسی‌شدهٔ داده انجام شود؛ صرف تغییر `DB_CONNECTION` داده‌ها را منتقل نمی‌کند.

## آزمون‌ها

```sh
php artisan test
npm run build
```

آزمون‌های Feature CRUD، انتشار/بایگانی/بازیابی، مجوز مدیر، روابط شناسه‌محور، چندوالدی/چرخهٔ برچسب، جست‌وجوی واقعی، حریم draft و فایل، رد SVG و routeهای فارسی را با SQLite موقت بررسی می‌کنند.

## بازگشت و پشتیبان

وضعیت کد و SQLite پیش از migration این مرحله در `/workspaces/monib12-stage3-pre-migration-20261012.tar.gz` جدا از Git آرشیو شده است. SQLite در snapshot با online backup گرفته شده؛ کاربران، نشست‌ها، فایل‌های `storage/app` و assets حفظ می‌شوند. `.env`، وابستگی‌های قابل‌بازسازی و cache/log موقت عمداً بیرون آرشیو هستند.

برای بررسی/استخراج امن، ابتدا snapshot را به مسیر جدا باز کنید تا پروژهٔ فعال overwrite نشود. بعد `.env` و `APP_KEY` را جداگانه بسازید و وابستگی‌ها را نصب کنید. این آرشیو پیش از migration مرحلهٔ سوم است؛ بازگردانی آن هم schema و هم دادهٔ همان لحظه را برمی‌گرداند. برای استقرار، از پایگاه‌داده و رسانه‌ها نسخهٔ پشتیبان خارج از workspace نگه دارید؛ این snapshot جایگزین پشتیبان دوره‌ای production نیست.