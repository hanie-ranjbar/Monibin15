<?php

namespace Tests\Feature;

use App\Models\ContentItem;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SitePagesTest extends TestCase
{
    use RefreshDatabase;

    public function test_public_sections_render_in_persian_rtl(): void
    {
        $pages = [
            '/sessions' => 'آرشیو جلسات',
            '/series' => 'سلسله‌جلسات',
            '/notes' => 'یادداشت‌ها',
            '/texts' => 'متن‌ها و مقاله‌ها',
            '/announcements' => 'اعلانات',
            '/about' => 'دربارهٔ استاد',
            '/tags' => 'برچسب‌ها',
            '/gallery' => 'نگارخانه',
        ];

        foreach ($pages as $path => $heading) {
            $this->get($path)
                ->assertOk()
                ->assertSee($heading)
                ->assertSee('lang="fa" dir="rtl"', false);
        }
    }

    public function test_search_finds_published_content_when_demo_mode_is_disabled(): void
    {
        ContentItem::factory()->create([
            'type' => 'text',
            'title' => 'جست‌وجوی قابل اعتماد',
            'slug' => 'reliable-search',
            'status' => 'published',
            'published_at' => now(),
        ]);

        $this->get('/search?q=قابل اعتماد')
            ->assertOk()
            ->assertSee('جست‌وجوی قابل اعتماد')
            ->assertDontSee('disabled', false);
    }

    public function test_shared_header_includes_accessible_site_navigation(): void
    {
        $this->get('/')
            ->assertOk()
            ->assertSee('id="site-drawer"', false)
            ->assertSee('aria-controls="site-drawer"', false)
            ->assertSee('aria-label="جست‌وجو در پایگاه"', false)
            ->assertSee('پایگاه معارف استاد حامد رنجبر')
            ->assertSee('منیبین');
    }

    public function test_trusted_https_proxy_generates_https_asset_urls(): void
    {
        $this->withServerVariables([
            'REMOTE_ADDR' => '127.0.0.1',
            'HTTP_HOST' => '127.0.0.1:8001',
            'HTTP_X_FORWARDED_HOST' => 'preview.example.test',
            'HTTP_X_FORWARDED_PORT' => '443',
            'HTTP_X_FORWARDED_PROTO' => 'https',
        ])->get('/')->assertOk()->assertSee(
            '<link rel="preload" as="style" href="https://preview.example.test/build/assets/app-',
            false,
        );
    }

    public function test_account_requires_authentication(): void
    {
        $this->get('/account')->assertRedirect(route('login'));
    }
}
