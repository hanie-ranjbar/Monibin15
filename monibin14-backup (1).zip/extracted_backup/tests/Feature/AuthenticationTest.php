<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AuthenticationTest extends TestCase
{
    use RefreshDatabase;

    public function test_a_user_can_log_in_and_log_out(): void
    {
        $user = User::factory()->create([
            'email' => 'reader@example.test',
            'password' => Hash::make('secure-password'),
        ]);

        $this->post('/login', [
            'email' => $user->email,
            'password' => 'secure-password',
        ])->assertRedirect(route('account'));

        $this->assertAuthenticatedAs($user);
        $this->get('/account')->assertOk()->assertSee($user->email);

        $this->post('/logout')->assertRedirect(route('home'));
        $this->assertGuest();
    }

    public function test_invalid_credentials_are_rejected(): void
    {
        $this->post('/login', [
            'email' => 'reader@example.test',
            'password' => 'incorrect-password',
        ])->assertSessionHasErrors('email');

        $this->assertGuest();
    }

    public function test_login_is_limited_to_five_attempts_per_email_and_ip(): void
    {
        $credentials = [
            'email' => 'reader@example.test',
            'password' => 'incorrect-password',
        ];

        for ($attempt = 1; $attempt <= 5; $attempt++) {
            $this->post('/login', $credentials)->assertSessionHasErrors('email');
        }

        $this->post('/login', $credentials)->assertTooManyRequests();
    }

    public function test_array_email_is_validated_without_breaking_login_throttling(): void
    {
        $this->post('/login', [
            'email' => ['reader@example.test'],
            'password' => 'incorrect-password',
        ])->assertSessionHasErrors('email');

        $this->assertGuest();
    }
}
