<?php

namespace Tests\Feature;

use App\Models\ContentItem;
use App\Models\Tag;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ContentManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_content_management_requires_an_authenticated_admin(): void
    {
        $this->get('/admin')->assertRedirect(route('login'));

        $reader = User::factory()->create();

        $this->actingAs($reader)->get('/admin')->assertForbidden();
        $this->actingAs($reader)->post('/admin/content', [])->assertForbidden();
    }

    public function test_admin_can_create_edit_publish_and_link_content_by_stable_ids(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $tag = Tag::factory()->create(['name' => 'اخلاق', 'slug' => 'ethics']);
        $this->actingAs($admin);

        $this->get('/admin')->assertOk()->assertSee('مدیریت محتوا');
        $this->get('/admin/content')->assertOk()->assertSee('<h1>محتوا</h1>', false);
        $this->get('/admin/content/create')->assertOk()->assertSee('ثبت محتوای تازه');
        $this->get('/admin/tags')->assertOk()->assertSee('اخلاق');
        $this->get('/admin/tags/create')->assertOk()->assertSee('ساخت برچسب');
        $this->get('/admin/tags/'.$tag->id.'/edit')->assertOk()->assertSee('ویرایش برچسب');

        $this->post('/admin/content', [
            'type' => 'series',
            'title' => 'اخلاق و خودشناسی',
            'slug' => 'ethics-and-self-knowledge',
            'status' => 'draft',
            'tag_ids' => [$tag->id],
        ])->assertRedirect();

        $series = ContentItem::query()->where('slug', 'ethics-and-self-knowledge')->firstOrFail();
        $seriesId = $series->id;

        $this->post('/admin/content', [
            'type' => 'session',
            'title' => 'درآمدی بر خودشناسی',
            'slug' => 'introduction-to-self-knowledge',
            'status' => 'draft',
            'series_id' => $seriesId,
            'tag_ids' => [$tag->id],
        ])->assertRedirect();

        $session = ContentItem::query()->where('slug', 'introduction-to-self-knowledge')->firstOrFail();
        $sessionId = $session->id;

        $this->post('/admin/content', [
            'type' => 'note',
            'title' => 'پرسش‌هایی دربارهٔ خودشناسی',
            'slug' => 'questions-about-self-knowledge',
            'status' => 'published',
            'body' => 'این یادداشت به جلسه پیوند دارد.',
            'parent_type' => 'session',
            'parent_id' => $sessionId,
            'tag_ids' => [$tag->id],
        ])->assertRedirect();

        $note = ContentItem::query()->where('slug', 'questions-about-self-knowledge')->firstOrFail();
        $noteId = $note->id;
        $this->assertDatabaseHas('content_items', ['id' => $noteId, 'parent_type' => 'session', 'parent_id' => $sessionId, 'status' => 'published']);
        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $noteId, 'tag_id' => $tag->id]);

        $this->put('/admin/content/'.$sessionId, [
            'type' => 'session',
            'title' => 'درآمدی بر خودشناسی (ویرایش‌شده)',
            'slug' => 'introduction-to-self-knowledge',
            'status' => 'published',
            'series_id' => $seriesId,
            'tag_ids' => [$tag->id],
        ])->assertRedirect();

        $this->assertDatabaseHas('content_items', ['id' => $sessionId, 'title' => 'درآمدی بر خودشناسی (ویرایش‌شده)', 'series_id' => $seriesId]);
        $this->assertDatabaseHas('content_items', ['id' => $noteId, 'parent_id' => $sessionId]);
        $this->get('/sessions/introduction-to-self-knowledge')->assertOk()->assertSee('پرسش‌هایی دربارهٔ خودشناسی');
        $this->get('/notes/questions-about-self-knowledge')->assertOk()->assertSee('درآمدی بر خودشناسی (ویرایش‌شده)');
        $this->get('/tags/ethics')->assertOk()->assertSee('درآمدی بر خودشناسی (ویرایش‌شده)')->assertSee('پرسش‌هایی دربارهٔ خودشناسی');
    }

    public function test_drafts_are_private_and_archive_restore_preserves_content_and_tag_links(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $tag = Tag::factory()->create();
        $item = ContentItem::factory()->create([
            'type' => 'article',
            'slug' => 'private-draft',
            'status' => 'draft',
            'published_at' => null,
        ]);
        $item->tags()->attach($tag);

        $this->get('/texts/private-draft')->assertNotFound();
        $this->actingAs($admin)->get('/admin/content/'.$item->id.'/edit')->assertOk()->assertSee('private-draft');

        $this->post('/admin/content/'.$item->id.'/archive')->assertRedirect(route('admin.content.index'));
        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $item->id, 'tag_id' => $tag->id]);
        $this->get('/texts/private-draft')->assertNotFound();

        $this->post('/admin/content/'.$item->id.'/restore')->assertRedirect(route('admin.content.edit', $item));
        $this->assertDatabaseHas('content_items', ['id' => $item->id, 'status' => 'draft', 'archived_at' => null]);
    }

    public function test_tag_parents_cannot_form_cycles_and_archiving_keeps_links(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $parent = Tag::factory()->create(['name' => 'اندیشه', 'slug' => 'thought']);
        $secondParent = Tag::factory()->create(['name' => 'خواندن', 'slug' => 'reading']);
        $child = Tag::factory()->create(['name' => 'اخلاق', 'slug' => 'ethics']);
        $child->parents()->sync([$parent->id, $secondParent->id]);
        $item = ContentItem::factory()->create([
            'type' => 'article',
            'slug' => 'ethics-article',
            'status' => 'published',
            'published_at' => now(),
        ]);
        $item->tags()->attach($child);

        $this->actingAs($admin)->post('/admin/tags', [
            'name' => 'مطالعهٔ دقیق',
            'slug' => 'close-reading',
            'description' => 'تعریف برچسب.',
            'parent_ids' => [$parent->id, $secondParent->id],
        ])->assertRedirect();

        $createdTag = Tag::query()->where('slug', 'close-reading')->firstOrFail();
        $this->assertDatabaseHas('tag_hierarchies', ['parent_id' => $parent->id, 'child_id' => $createdTag->id]);
        $this->assertDatabaseHas('tag_hierarchies', ['parent_id' => $secondParent->id, 'child_id' => $createdTag->id]);

        $this->actingAs($admin)->put('/admin/tags/'.$parent->id, [
            'name' => 'اندیشه',
            'slug' => 'thought',
            'parent_ids' => [$child->id],
        ])->assertSessionHasErrors('parent_ids');

        $this->post('/admin/tags/'.$child->id.'/archive')->assertRedirect(route('admin.tags.index'));
        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $item->id, 'tag_id' => $child->id]);
        $this->get('/tags/ethics')->assertNotFound();

        $this->post('/admin/tags/'.$child->id.'/restore')->assertRedirect(route('admin.tags.edit', $child));
        $this->get('/tags/ethics')->assertOk()->assertSee('ethics-article')->assertSee('اندیشه')->assertSee('خواندن');
    }

    public function test_search_normalizes_common_arabic_and_persian_letter_variants(): void
    {
        ContentItem::factory()->create([
            'type' => 'text',
            'title' => 'حکمت و تربیت',
            'slug' => 'wisdom-and-upbringing',
            'status' => 'published',
            'published_at' => now(),
        ]);

        $this->get('/search?q=حكمت')
            ->assertOk()
            ->assertSee('حکمت و تربیت');

        $this->get('/search?q=تربيت')
            ->assertOk()
            ->assertSee('حکمت و تربیت');
    }

    public function test_private_media_is_not_available_until_content_is_published(): void
    {
        Storage::fake('local');
        $item = ContentItem::factory()->create([
            'type' => 'gallery',
            'status' => 'draft',
            'media_path' => 'content/1/poster.jpg',
            'media_kind' => 'image',
            'media_mime' => 'image/jpeg',
        ]);
        Storage::disk('local')->put($item->media_path, 'test image data');

        $this->get('/media/'.$item->id)->assertNotFound();

        $item->forceFill(['status' => 'published', 'published_at' => now()])->save();

        $this->get('/media/'.$item->id)
            ->assertOk()
            ->assertHeader('content-type', 'image/jpeg')
            ->assertHeader('x-content-type-options', 'nosniff');
    }

    public function test_published_about_content_is_shown_on_the_about_page(): void
    {
        ContentItem::factory()->create([
            'type' => 'about',
            'title' => 'درباره استاد',
            'slug' => 'about',
            'body' => 'زندگی‌نامهٔ بررسی‌شده.',
            'status' => 'published',
            'published_at' => now(),
        ]);

        $this->get('/about')->assertOk()->assertSee('زندگی‌نامهٔ بررسی‌شده.');
    }

    public function test_admin_upload_rejects_active_or_unsupported_image_formats(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);

        $this->actingAs($admin)->post('/admin/content', [
            'type' => 'gallery',
            'title' => 'تصویر آزمایشی',
            'slug' => 'unsafe-gallery-image',
            'status' => 'draft',
            'media_kind' => 'image',
            'media' => UploadedFile::fake()->create('active.svg', 1, 'image/svg+xml'),
        ])->assertSessionHasErrors('media');

        $this->assertDatabaseMissing('content_items', ['slug' => 'unsafe-gallery-image']);
    }
}
