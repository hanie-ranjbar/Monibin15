<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class DemoContentTest extends TestCase
{
    use RefreshDatabase;

    public function test_demo_routes_are_available_and_demo_records_are_hidden_by_default(): void
    {
        config(['site.demo_content_enabled' => false]);

        foreach (['/tags', '/gallery', '/sessions', '/announcements', '/notes', '/texts'] as $path) {
            $this->get($path)->assertOk();
        }

        $this->get('/sessions/self-knowledge-demo')->assertNotFound();
        $this->get('/')->assertViewHas('demoEnabled', false);
    }

    public function test_enabled_demo_content_and_filters_are_read_from_isolated_fixtures(): void
    {
        config(['site.demo_content_enabled' => true]);

        $this->get('/')
            ->assertOk()
            ->assertViewHas('sections', static fn ($sections): bool => count($sections['sessions']['items']) === 3);

        $this->get('/sessions?year=1403')
            ->assertOk()
            ->assertViewHas('items', static fn (array $items): bool => count($items) === 2
                && collect($items)->every(static fn (array $item): bool => $item['year'] === '1403'));

        $this->get('/sessions/unknown-session')->assertNotFound();
    }

    public function test_search_only_matches_demo_fixtures_when_the_demo_switch_is_enabled(): void
    {
        $this->get('/search?q=توجه')->assertOk()->assertViewHas('items', []);

        config(['site.demo_content_enabled' => true]);

        $this->get('/search?q=توجه')
            ->assertOk()
            ->assertViewHas('items', static fn (array $items): bool => count($items) === 2
                && in_array('habits-and-attention-demo', array_column($items, 'slug'), true)
                && in_array('attention-and-reflection-demo', array_column($items, 'slug'), true));
    }

    public function test_demo_detail_routes_render_their_related_content(): void
    {
        config(['site.demo_content_enabled' => true]);

        $this->get('/sessions/self-knowledge-demo')
            ->assertOk()
            ->assertSee('درآمدی بر خودشناسی');

        $this->get('/series/ethics-and-self-knowledge-demo')
            ->assertOk()
            ->assertSee('درآمدی بر خودشناسی')
            ->assertSee('خواندن برای فهمیدن');

        $this->get('/notes/questions-of-self-knowledge-demo')
            ->assertOk()
            ->assertSee('پرسش‌هایی دربارهٔ خودشناسی');

        $this->get('/texts/attention-and-reflection-demo')
            ->assertOk()
            ->assertSee('این متن ساختگی فقط برای آزمودن صفحهٔ مطالعه نوشته شده است.');

        $this->get('/announcements/reading-circle-demo')
            ->assertOk()
            ->assertSee('تصویر نمایشی')
            ->assertSee('محتوای نمایشی');
    }

    public function test_demo_gallery_and_multi_parent_tags_render_only_with_the_demo_switch(): void
    {
        config(['site.demo_content_enabled' => true]);

        $this->get('/gallery')
            ->assertOk()
            ->assertSee('data-lightbox-open', false)
            ->assertSee('nigaristan-court.webp');

        $this->get('/tags')
            ->assertOk()
            ->assertSee('پیوندهای بالادستی')
            ->assertSee('اخلاق')
            ->assertSee('یادگیری');
    }
}
