<?php

use App\Http\Controllers\Admin\ContentItemController as AdminContentItemController;
use App\Http\Controllers\Admin\TagController as AdminTagController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\ContentMediaController;
use App\Http\Controllers\PageController;
use Illuminate\Support\Facades\Route;

Route::get('/', [PageController::class, 'home'])->name('home');

Route::get('/sessions', [PageController::class, 'show'])->defaults('section', 'sessions')->name('sessions.index');
Route::get('/sessions/{slug}', [PageController::class, 'showItem'])->defaults('section', 'sessions')->name('sessions.show');
Route::get('/series', [PageController::class, 'show'])->defaults('section', 'series')->name('series.index');
Route::get('/series/{slug}', [PageController::class, 'showItem'])->defaults('section', 'series')->name('series.show');
Route::get('/notes', [PageController::class, 'show'])->defaults('section', 'notes')->name('notes.index');
Route::get('/notes/{slug}', [PageController::class, 'showItem'])->defaults('section', 'notes')->name('notes.show');
Route::get('/texts', [PageController::class, 'show'])->defaults('section', 'texts')->name('texts.index');
Route::get('/texts/{slug}', [PageController::class, 'showItem'])->defaults('section', 'texts')->name('texts.show');
Route::get('/announcements', [PageController::class, 'show'])->defaults('section', 'announcements')->name('announcements.index');
Route::get('/announcements/{slug}', [PageController::class, 'showItem'])->defaults('section', 'announcements')->name('announcements.show');
Route::get('/about', [PageController::class, 'show'])->defaults('section', 'about')->name('about');
Route::get('/search', [PageController::class, 'show'])->defaults('section', 'search')->name('search');
Route::get('/tags', [PageController::class, 'show'])->defaults('section', 'tags')->name('tags.index');
Route::get('/tags/{tag:slug}', [PageController::class, 'showTag'])->name('tags.show');
Route::get('/gallery', [PageController::class, 'show'])->defaults('section', 'gallery')->name('gallery.index');
Route::get('/gallery/{slug}', [PageController::class, 'showItem'])->defaults('section', 'gallery')->name('gallery.show');
Route::get('/media/{contentItem}', ContentMediaController::class)->name('media.show');

Route::get('/login', [AuthenticatedSessionController::class, 'create'])->name('login');
Route::post('/login', [AuthenticatedSessionController::class, 'store'])->middleware('throttle:login')->name('login.store');
Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])->middleware('auth')->name('logout');
Route::view('/account', 'auth.account')->middleware('auth')->name('account');

Route::middleware(['auth', 'can:manage-content'])->prefix('admin')->name('admin.')->group(function (): void {
    Route::get('/', [AdminContentItemController::class, 'dashboard'])->name('dashboard');
    Route::post('/content/{content}/archive', [AdminContentItemController::class, 'archive'])->name('content.archive');
    Route::post('/content/{content}/restore', [AdminContentItemController::class, 'restore'])->name('content.restore');
    Route::resource('content', AdminContentItemController::class)->except(['show', 'destroy']);
    Route::post('/tags/{tag}/archive', [AdminTagController::class, 'archive'])->name('tags.archive');
    Route::post('/tags/{tag}/restore', [AdminTagController::class, 'restore'])->name('tags.restore');
    Route::resource('tags', AdminTagController::class)->except(['show', 'destroy']);
});
