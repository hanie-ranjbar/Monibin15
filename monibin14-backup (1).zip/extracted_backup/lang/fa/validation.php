<?php

return [
    'accepted' => 'پذیرفتن :attribute الزامی است.',
    'array' => ':attribute باید فهرست باشد.',
    'confirmed' => 'تأیید :attribute با آن مطابقت ندارد.',
    'date' => ':attribute باید تاریخ معتبری باشد.',
    'distinct' => ':attribute مقدار تکراری دارد.',
    'email' => ':attribute باید نشانی ایمیل معتبری باشد.',
    'exists' => 'مقدار انتخاب‌شدهٔ :attribute معتبر نیست.',
    'file' => ':attribute باید فایل باشد.',
    'image' => ':attribute باید تصویر باشد.',
    'in' => 'مقدار انتخاب‌شدهٔ :attribute معتبر نیست.',
    'integer' => ':attribute باید عدد صحیح باشد.',
    'max' => [
        'file' => 'حجم :attribute نباید بیشتر از :max کیلوبایت باشد.',
        'numeric' => ':attribute نباید بیشتر از :max باشد.',
        'string' => ':attribute نباید بیش از :max نویسه باشد.',
        'array' => ':attribute نباید بیش از :max مورد داشته باشد.',
    ],
    'mimes' => 'فرمت :attribute باید یکی از این موارد باشد: :values.',
    'min' => [
        'string' => ':attribute باید دست‌کم :min نویسه باشد.',
    ],
    'required' => 'واردکردن :attribute الزامی است.',
    'required_with' => 'واردکردن :attribute همراه با :values الزامی است.',
    'regex' => 'قالب :attribute معتبر نیست.',
    'string' => ':attribute باید متن باشد.',
    'unique' => 'این :attribute پیش‌تر ثبت شده است.',
    'attributes' => [
        'title' => 'عنوان', 'slug' => 'نشانی', 'type' => 'نوع محتوا', 'excerpt' => 'خلاصه',
        'body' => 'متن', 'author' => 'نویسنده', 'category' => 'دسته‌بندی', 'occurred_at' => 'تاریخ',
        'status' => 'وضعیت', 'series_id' => 'سلسله‌جلسه', 'parent_id' => 'محتوای مادر',
        'parent_type' => 'نوع محتوای مادر', 'tag_ids' => 'برچسب‌ها', 'tag_ids.*' => 'برچسب',
        'media' => 'فایل', 'media_kind' => 'نوع فایل', 'media_alt' => 'توضیح تصویر',
        'name' => 'نام', 'description' => 'تعریف', 'parent_ids' => 'والدها', 'parent_ids.*' => 'والد',
        'email' => 'ایمیل', 'password' => 'گذرواژه', 'password_confirmation' => 'تکرار گذرواژه',
    ],
];
