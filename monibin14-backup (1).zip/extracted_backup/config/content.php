<?php

return [
    'types' => [
        'session' => 'جلسه',
        'series' => 'سلسله‌جلسه',
        'note' => 'یادداشت',
        'text' => 'متن جلسه',
        'article' => 'مقاله',
        'announcement' => 'اعلان',
        'about' => 'درباره استاد',
        'gallery' => 'تصویر نگارخانه',
    ],

    'statuses' => [
        'draft' => 'پیش‌نویس',
        'published' => 'منتشرشده',
        'archived' => 'بایگانی‌شده',
    ],
];
