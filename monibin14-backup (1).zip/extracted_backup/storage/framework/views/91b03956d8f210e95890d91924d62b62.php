<?php $__env->startSection('content'); ?>
    <section class="home-hero">
        <div class="container home-hero-grid">
            <div class="home-hero-copy">
                <p class="eyebrow"><span class="eyebrow-mark" aria-hidden="true">✳</span> یک پایگاه برای آموختن و بازخواندن</p>
                <h1><?php echo e(config('site.full_name')); ?></h1>
                <p class="hero-subtitle">درس‌ها و سخنرانی‌های <?php echo e(config('site.teacher')); ?></p>
                <p class="hero-description">آرشیوی برای دسترسی روشن و پیوسته به جلسه‌ها، یادداشت‌ها و متن‌ها؛ با پیوندهایی برای بازگشت به ایده‌ها.</p>
                <a class="button button-primary" href="<?php echo e(route('sessions.index')); ?>">ورود به آرشیو جلسات <span aria-hidden="true">←</span></a>
            </div>
            <figure class="hero-artwork">
                <img src="<?php echo e(asset('images/demo/nigaristan-assembly.webp')); ?>" alt="نگارهٔ مینیاتور ایرانی از یک مجلس، تصویر نمایشی طراحی" width="1200" height="1516" fetchpriority="high">
                <figcaption><span>نگارگری ایرانی</span><span>تصویر نمایشی</span></figcaption>
            </figure>
            <div class="hero-index" aria-hidden="true"><span>پایگاه محتوایی</span><span>فارسی · راست‌به‌چپ</span></div>
        </div>
    </section>

    <div class="container home-sections">
        <?php $__currentLoopData = config('site.home_sections'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $title): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $section = $sections[$key];
                $detailRoute = config("site.pages.{$key}.detail_route");
                $indexRoute = $key === 'announcements' ? 'announcements.index' : $key.'.index';
            ?>
            <section class="content-section" aria-labelledby="home-<?php echo e($key); ?>">
                <div class="section-header">
                    <div class="section-heading-copy">
                        <span class="section-index"><?php echo e(strtr(str_pad((string) $loop->iteration, 2, '0', STR_PAD_LEFT), '0123456789', '۰۱۲۳۴۵۶۷۸۹')); ?></span>
                        <div>
                            <p class="eyebrow">پایگاه / <?php echo e($title); ?></p>
                            <h2 id="home-<?php echo e($key); ?>"><?php echo e($title); ?></h2>
                        </div>
                    </div>
                    <a class="section-more" href="<?php echo e(route($indexRoute)); ?>">مشاهدهٔ همه <span aria-hidden="true">←</span></a>
                </div>

                <?php if(count($section['items'])): ?>
                    <div class="content-grid">
                        <?php $__currentLoopData = $section['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('partials.content-card', ['item' => $item, 'type' => $key, 'detailRoute' => $detailRoute], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <div class="section-empty">
                        <span class="empty-symbol" aria-hidden="true">↗</span>
                        <div>
                            <h3>هنوز محتوایی منتشر نشده است</h3>
                            <p><?php echo e($demoEnabled ? 'برای این بخش دادهٔ نمایشی هم ثبت نشده است.' : 'محتوای این بخش پس از ثبت و بررسی منابع منتشر می‌شود.'); ?></p>
                        </div>
                        <a href="<?php echo e(route($indexRoute)); ?>" aria-label="رفتن به <?php echo e($title); ?>">←</a>
                    </div>
                <?php endif; ?>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => config('site.full_name'), 'description' => config('site.tagline')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monibin12/resources/views/pages/home.blade.php ENDPATH**/ ?>