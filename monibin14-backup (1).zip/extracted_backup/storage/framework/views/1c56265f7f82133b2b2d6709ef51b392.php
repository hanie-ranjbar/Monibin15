<?php $__env->startSection('content'); ?>
    <header class="archive-heading">
        <div class="container archive-heading-inner">
            <div><p class="eyebrow">فضای خصوصی</p><h1>مدیریت محتوا</h1><p class="archive-description">پیش‌نویس‌ها را بررسی و محتواهای آماده را منتشر کنید.</p></div>
        </div>
    </header>
    <section class="container admin-page">
        <?php echo $__env->make('admin.partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('admin.partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="admin-metrics">
            <a href="<?php echo e(route('admin.content.index', ['status' => 'draft'])); ?>"><strong><?php echo e($drafts); ?></strong><span>پیش‌نویس</span></a>
            <a href="<?php echo e(route('admin.content.index', ['status' => 'published'])); ?>"><strong><?php echo e($published); ?></strong><span>منتشرشده</span></a>
            <a href="<?php echo e(route('admin.content.index', ['status' => 'archived'])); ?>"><strong><?php echo e($archived); ?></strong><span>بایگانی</span></a>
            <a href="<?php echo e(route('admin.tags.index')); ?>"><strong><?php echo e($tags); ?></strong><span>برچسب فعال</span></a>
        </div>
        <div class="admin-actions">
            <a class="button button-primary" href="<?php echo e(route('admin.content.create')); ?>">ثبت محتوا</a>
            <a class="button button-secondary" href="<?php echo e(route('admin.tags.create')); ?>">ساخت برچسب</a>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'مدیریت محتوا'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monibin12/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>