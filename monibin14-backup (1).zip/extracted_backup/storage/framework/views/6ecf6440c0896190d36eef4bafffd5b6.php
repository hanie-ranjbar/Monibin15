<?php $__env->startSection('content'); ?>
    <section class="page-intro">
        <div class="container">
            <p class="eyebrow"><?php echo e(config('site.name')); ?></p>
            <h1>حساب کاربری</h1>
            <p class="page-description">واردشده با حساب <?php echo e(auth()->user()->email); ?></p>
        </div>
    </section>

    <section class="page-body container">
        <p class="account-note">بخش‌های ویژهٔ حساب کاربری در مراحل بعدی توسعه داده می‌شوند.</p>
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button class="text-action-button" type="submit">خروج از حساب</button>
        </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'حساب کاربری'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monibin12/resources/views/auth/account.blade.php ENDPATH**/ ?>