<?php
    $detailRoute = $detailRoute ?? null;
    $tagLookup = collect(config('demo_content.tags', []))->keyBy('slug');
    $image = $item['image'] ?? null;
    $cardTags = $item['tags'] ?? collect($item['tag_slugs'] ?? [])
        ->map(fn ($slug) => $tagLookup->get($slug))
        ->filter()
        ->map(fn ($tag) => ['slug' => $tag['slug'], 'title' => $tag['title']])
        ->all();
?>

<article class="content-card content-card--<?php echo e($type); ?>">
    <?php if($image): ?>
        <a class="card-poster" href="<?php echo e(route($detailRoute ?? 'gallery.show', $item['slug'])); ?>">
            <img src="<?php echo e(($item['is_demo'] ?? false) ? asset($image) : $image); ?>" alt="<?php echo e($item['image_alt'] ?? $item['title']); ?>" width="900" height="1200" loading="lazy">
            <?php if($item['is_demo'] ?? false): ?><span class="demo-label poster-label">تصویر دمو</span><?php endif; ?>
        </a>
    <?php else: ?>
        <div class="card-ornament" aria-hidden="true"><span><?php echo e(strtr(str_pad((string) (crc32($item['slug']) % 99 + 1), 2, '0', STR_PAD_LEFT), '0123456789', '۰۱۲۳۴۵۶۷۸۹')); ?></span><span class="ornament-rule"></span><span>منیبین</span></div>
    <?php endif; ?>

    <div class="card-content">
        <div class="card-meta"><span><?php echo e($item['category_label'] ?? $item['author'] ?? config("site.pages.{$type}.title", 'پایگاه')); ?></span><?php if($item['is_demo'] ?? false): ?><span class="demo-label">دمو</span><?php endif; ?></div>
        <h3><a href="<?php echo e(route($detailRoute ?? ($item['detail_route'] ?? 'gallery.show'), $item['slug'])); ?>"><?php echo e($item['title']); ?></a></h3>
        <p class="card-excerpt"><?php echo e($item['excerpt'] ?? ''); ?></p>
        <div class="card-bottom">
            <?php if(isset($item['date'])): ?><time><?php echo e($item['date']); ?></time><?php endif; ?>
            <?php if(isset($item['note_slugs']) && count($item['note_slugs'])): ?><span><?php echo e(strtr((string) count($item['note_slugs']), '0123456789', '۰۱۲۳۴۵۶۷۸۹')); ?> یادداشت پیوندخورده</span><?php endif; ?>
            <?php if(count($cardTags)): ?>
                <div class="card-tags" aria-label="برچسب‌ها">
                    <?php $__currentLoopData = array_slice($cardTags, 0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="tag-chip" href="<?php echo e(($item['is_demo'] ?? false) ? route('search', ['q' => $tag['title']]) : route('tags.show', $tag['slug'])); ?>"><?php echo e($tag['title']); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(! empty($item['audio'])): ?><audio controls preload="none" aria-label="پخش صوت <?php echo e($item['title']); ?>"><source src="<?php echo e($item['audio']); ?>" type="<?php echo e($item['media_mime'] ?? 'audio/mpeg'); ?>"></audio><?php endif; ?>
            <a class="card-open" href="<?php echo e(route($detailRoute ?? ($item['detail_route'] ?? 'gallery.show'), $item['slug'])); ?>" aria-label="خواندن <?php echo e($item['title']); ?>">←</a>
        </div>
    </div>
</article><?php /**PATH /workspaces/monibin12/resources/views/partials/content-card.blade.php ENDPATH**/ ?>