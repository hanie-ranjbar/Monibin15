<?php $__env->startSection('content'); ?>
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">مدیریت / <a href="<?php echo e(route('admin.content.index')); ?>">محتوا</a></p><h1><?php echo e($item->exists ? 'ویرایش محتوا' : 'ثبت محتوای تازه'); ?></h1><p class="archive-description">ذخیره، انتشار و پیونددهی بر اساس شناسهٔ محتوا انجام می‌شود.</p></div></div></header>
    <section class="container admin-page admin-form-page">
        <?php echo $__env->make('admin.partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('admin.partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <form class="admin-form" method="POST" action="<?php echo e($item->exists ? route('admin.content.update', $item) : route('admin.content.store')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php if($item->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
            <div class="admin-field"><label for="type">نوع محتوا</label><select id="type" name="type" required><?php $__currentLoopData = config('content.types'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>" <?php if(old('type', $item->type) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="title">عنوان</label><input id="title" name="title" value="<?php echo e(old('title', $item->title)); ?>" required maxlength="255"><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="slug">نشانی یکتا (slug)</label><input id="slug" name="slug" value="<?php echo e(old('slug', $item->slug)); ?>" dir="auto" required maxlength="255"><?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="excerpt">خلاصه</label><textarea id="excerpt" name="excerpt" rows="3"><?php echo e(old('excerpt', $item->excerpt)); ?></textarea><?php $__errorArgs = ['excerpt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field admin-field--wide"><label for="body">متن</label><textarea id="body" name="body" rows="12"><?php echo e(old('body', $item->body)); ?></textarea><?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="author">نویسنده</label><input id="author" name="author" value="<?php echo e(old('author', $item->author)); ?>"><?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="category">دسته‌بندی</label><input id="category" name="category" value="<?php echo e(old('category', $item->category)); ?>"><?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="occurred_at">تاریخ برگزاری/محتوا</label><input id="occurred_at" name="occurred_at" type="date" value="<?php echo e(old('occurred_at', $item->occurred_at?->format('Y-m-d'))); ?>"><?php $__errorArgs = ['occurred_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="status">وضعیت</label><select id="status" name="status" required><option value="draft" <?php if(old('status', $item->status ?: 'draft') === 'draft'): echo 'selected'; endif; ?>>پیش‌نویس</option><option value="published" <?php if(old('status', $item->status) === 'published'): echo 'selected'; endif; ?>>انتشار</option></select><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="series_id">سلسله‌جلسهٔ مادر</label><select id="series_id" name="series_id"><option value="">بدون سلسله‌جلسه</option><?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($entry->id); ?>" <?php if((string) old('series_id', $item->series_id) === (string) $entry->id): echo 'selected'; endif; ?>><?php echo e($entry->title); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['series_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="parent_type">نوع محتوای مادر</label><select id="parent_type" name="parent_type"><option value="">بدون محتوای مادر</option><option value="session" <?php if(old('parent_type', $item->parent_type) === 'session'): echo 'selected'; endif; ?>>جلسه</option><option value="text" <?php if(old('parent_type', $item->parent_type) === 'text'): echo 'selected'; endif; ?>>متن جلسه</option><option value="article" <?php if(old('parent_type', $item->parent_type) === 'article'): echo 'selected'; endif; ?>>مقاله</option></select><?php $__errorArgs = ['parent_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="parent_id">محتوای مادر</label><select id="parent_id" name="parent_id"><option value="">انتخاب محتوا</option><?php $__currentLoopData = $parents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($parent->id); ?>" <?php if((string) old('parent_id', $item->parent_id) === (string) $parent->id): echo 'selected'; endif; ?>><?php echo e(config('content.types.'.$parent->type)); ?>: <?php echo e($parent->title); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <fieldset class="admin-field admin-field--wide"><legend>برچسب‌ها</legend><div class="admin-tag-options"><?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label><input type="checkbox" name="tag_ids[]" value="<?php echo e($tag->id); ?>" <?php if(in_array($tag->id, (array) old('tag_ids', $item->exists ? $item->tags->modelKeys() : []))): echo 'checked'; endif; ?>><span><?php echo e($tag->name); ?></span></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><a href="<?php echo e(route('admin.tags.create')); ?>">ساخت برچسب تازه</a><?php $__errorArgs = ['tag_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></fieldset>
            <fieldset class="admin-field admin-field--wide"><legend>فایل رسانه‌ای</legend><?php if($item->media_path): ?><p>فایل فعلی: <a href="<?php echo e(route('media.show', $item)); ?>">مشاهدهٔ فایل</a></p><label><input type="checkbox" name="remove_media" value="1"> حذف فایل فعلی</label><?php endif; ?><label for="media_kind">نوع فایل</label><select id="media_kind" name="media_kind"><option value="">انتخاب نوع</option><option value="image">تصویر</option><option value="audio">صوت</option></select><label for="media">فایل (تصویر حداکثر ۵ مگابایت؛ صوت حداکثر ۵۰ مگابایت)</label><input id="media" name="media" type="file" accept="image/jpeg,image/png,image/webp,audio/mpeg,audio/wav,audio/mp4"><?php $__errorArgs = ['media'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><label for="media_alt">توضیح تصویر</label><input id="media_alt" name="media_alt" maxlength="255" value="<?php echo e(old('media_alt', $item->media_alt)); ?>"><?php $__errorArgs = ['media_alt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></fieldset>
            <div class="admin-form-actions"><button class="button button-primary" type="submit">ذخیرهٔ محتوا</button><a class="button button-secondary" href="<?php echo e(route('admin.content.index')); ?>">بازگشت</a></div>
        </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => $item->exists ? 'ویرایش محتوا' : 'ثبت محتوا'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monibin12/resources/views/admin/content/form.blade.php ENDPATH**/ ?>