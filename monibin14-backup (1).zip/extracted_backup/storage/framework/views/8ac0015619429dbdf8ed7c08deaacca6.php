<?php $__env->startSection('content'); ?>
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">فضای خصوصی / مدیریت</p><h1>محتوا</h1><p class="archive-description">پیش‌نویس‌ها، موارد منتشرشده و بایگانی؛ حذف دائمی در این پنل انجام نمی‌شود.</p></div><a class="button button-primary" href="<?php echo e(route('admin.content.create')); ?>">محتوای تازه</a></div></header>
    <section class="container admin-page">
        <?php echo $__env->make('admin.partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('admin.partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <form class="admin-filters" method="GET">
            <label>نوع محتوا<select name="type"><option value="">همهٔ انواع</option><?php $__currentLoopData = config('content.types'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>" <?php if(request('type') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <label>وضعیت<select name="status"><option value="">همهٔ وضعیت‌ها</option><?php $__currentLoopData = config('content.statuses'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($value); ?>" <?php if(request('status') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
            <button class="button button-secondary" type="submit">اعمال</button>
        </form>
        <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>عنوان</th><th>نوع</th><th>وضعیت</th><th>برچسب‌ها</th><th>تغییر</th><th>عملیات</th></tr></thead><tbody>
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><a href="<?php echo e(route('admin.content.edit', $item)); ?>"><?php echo e($item->title); ?></a><small dir="ltr"><?php echo e($item->slug); ?></small></td>
                    <td><?php echo e(config('content.types.'.$item->type)); ?></td>
                    <td><span class="admin-status admin-status--<?php echo e($item->status); ?>"><?php echo e(config('content.statuses.'.$item->status)); ?></span></td>
                    <td><?php echo e($item->tags->pluck('name')->join('، ') ?: '—'); ?></td>
                    <td><?php echo e($item->updated_at->format('Y-m-d')); ?></td>
                    <td class="admin-row-actions">
                        <?php if($item->status === 'archived'): ?>
                            <form method="POST" action="<?php echo e(route('admin.content.restore', $item)); ?>"><?php echo csrf_field(); ?><button class="text-link-button" type="submit">بازگردانی به پیش‌نویس</button></form>
                        <?php else: ?>
                            <a href="<?php echo e(route('admin.content.edit', $item)); ?>">ویرایش</a>
                            <form method="POST" action="<?php echo e(route('admin.content.archive', $item)); ?>"><?php echo csrf_field(); ?><button class="text-link-button" type="submit">بایگانی</button></form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6">محتوایی ثبت نشده است.</td></tr>
            <?php endif; ?>
        </tbody></table></div>
        <?php echo e($items->links()); ?>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'مدیریت محتوا'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monibin12/resources/views/admin/content/index.blade.php ENDPATH**/ ?>