<?php $__env->startSection('content'); ?>
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">مدیریت / برچسب‌ها</p><h1><?php echo e($tag->exists ? 'ویرایش برچسب' : 'ساخت برچسب'); ?></h1><p class="archive-description">یک برچسب می‌تواند چند والد داشته باشد؛ ساخت پیوند دوری پذیرفته نمی‌شود.</p></div></div></header>
    <section class="container admin-page admin-form-page">
        <?php echo $__env->make('admin.partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('admin.partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <form class="admin-form" method="POST" action="<?php echo e($tag->exists ? route('admin.tags.update', $tag) : route('admin.tags.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($tag->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
            <div class="admin-field"><label for="name">نام</label><input id="name" name="name" value="<?php echo e(old('name', $tag->name)); ?>" required maxlength="120"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field"><label for="slug">نشانی یکتا</label><input id="slug" name="slug" value="<?php echo e(old('slug', $tag->slug)); ?>" dir="auto" required maxlength="150"><?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <div class="admin-field admin-field--wide"><label for="description">تعریف</label><textarea id="description" name="description" rows="4"><?php echo e(old('description', $tag->description)); ?></textarea><?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></div>
            <fieldset class="admin-field admin-field--wide"><legend>برچسب‌های والد</legend><div class="admin-tag-options"><?php $__currentLoopData = $availableTags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><label><input type="checkbox" name="parent_ids[]" value="<?php echo e($parent->id); ?>" <?php if(in_array($parent->id, (array) old('parent_ids', $tag->exists ? $tag->parents->modelKeys() : []))): echo 'checked'; endif; ?>><span><?php echo e($parent->name); ?></span></label><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php $__errorArgs = ['parent_ids'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small class="field-error"><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></fieldset>
            <div class="admin-form-actions"><button class="button button-primary" type="submit">ذخیرهٔ برچسب</button><a class="button button-secondary" href="<?php echo e(route('admin.tags.index')); ?>">بازگشت</a></div>
        </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => $tag->exists ? 'ویرایش برچسب' : 'ساخت برچسب'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monibin12/resources/views/admin/tags/form.blade.php ENDPATH**/ ?>