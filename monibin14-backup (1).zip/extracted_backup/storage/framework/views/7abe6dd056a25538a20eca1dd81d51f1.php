<?php $__env->startSection('content'); ?>
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">فضای خصوصی / مدیریت</p><h1>برچسب‌ها</h1><p class="archive-description">برچسب‌ها را بایگانی کنید؛ پیوندهای محتوایی حذف نمی‌شوند.</p></div><a class="button button-primary" href="<?php echo e(route('admin.tags.create')); ?>">برچسب تازه</a></div></header>
    <section class="container admin-page">
        <?php echo $__env->make('admin.partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('admin.partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>نام</th><th>والدها</th><th>محتوای منتشرشده</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>
            <?php $__empty_1 = true; $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr><td><a href="<?php echo e(route('admin.tags.edit', $tag)); ?>"><?php echo e($tag->name); ?></a><small dir="ltr"><?php echo e($tag->slug); ?></small></td><td><?php echo e($tag->parents->pluck('name')->join('، ') ?: '—'); ?></td><td><?php echo e($tag->content_items_count); ?></td><td><?php echo e($tag->archived_at ? 'بایگانی‌شده' : 'فعال'); ?></td><td class="admin-row-actions"><?php if($tag->archived_at): ?><form method="POST" action="<?php echo e(route('admin.tags.restore', $tag)); ?>"><?php echo csrf_field(); ?><button class="text-link-button" type="submit">بازیابی</button></form><?php else: ?><a href="<?php echo e(route('admin.tags.edit', $tag)); ?>">ویرایش</a><form method="POST" action="<?php echo e(route('admin.tags.archive', $tag)); ?>"><?php echo csrf_field(); ?><button class="text-link-button" type="submit">بایگانی</button></form><?php endif; ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5">برچسبی ثبت نشده است.</td></tr>
            <?php endif; ?>
        </tbody></table></div>
        <?php echo e($tags->links()); ?>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'مدیریت برچسب‌ها'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monibin12/resources/views/admin/tags/index.blade.php ENDPATH**/ ?>