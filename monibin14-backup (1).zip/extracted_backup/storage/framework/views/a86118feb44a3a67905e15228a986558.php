<?php $__env->startSection('content'); ?>
    <section class="page-intro">
        <div class="container">
            <p class="eyebrow">حساب کاربری</p>
            <h1>ورود</h1>
            <p class="page-description">برای ورود، با حسابی که برای شما ایجاد شده است وارد شوید. ساخت حساب عمومی در این مرحله فعال نیست.</p>
        </div>
    </section>

    <section class="page-body container">
        <form class="auth-form" method="POST" action="<?php echo e(route('login.store')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-field">
                <label class="field-label" for="email">ایمیل</label>
                <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" autocomplete="username" dir="ltr" required autofocus aria-describedby="email-error">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="field-error" id="email-error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-field">
                <label class="field-label" for="password">گذرواژه</label>
                <input id="password" name="password" type="password" autocomplete="current-password" required aria-describedby="password-error">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="field-error" id="password-error"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <label class="remember-option">
                <input type="checkbox" name="remember" value="1">
                <span>مرا به خاطر بسپار</span>
            </label>

            <button class="primary-button" type="submit">ورود به حساب</button>
        </form>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'ورود به حساب کاربری'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monibin12/resources/views/auth/login.blade.php ENDPATH**/ ?>