<?php if(session('status')): ?>
    <p class="admin-flash" role="status"><?php echo e(session('status')); ?></p>
<?php endif; ?><?php /**PATH /workspaces/monibin12/resources/views/admin/partials/flash.blade.php ENDPATH**/ ?>