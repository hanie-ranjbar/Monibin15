<div class="archive-empty" role="status">
    <span class="archive-empty-symbol" aria-hidden="true">∅</span>
    <div><p class="eyebrow"><?php echo e(config('site.name')); ?> / آرشیو</p><h2><?php echo e($title); ?></h2><p><?php echo e($message); ?></p></div>
</div><?php /**PATH /workspaces/monibin12/resources/views/partials/empty-state.blade.php ENDPATH**/ ?>