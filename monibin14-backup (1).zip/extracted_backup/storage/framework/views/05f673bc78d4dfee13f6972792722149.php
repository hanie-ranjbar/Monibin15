<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f7f6f2">
    <meta name="description" content="<?php echo e($description ?? config('site.tagline')); ?>">
    <title><?php echo e($title ?? config('site.name')); ?> | <?php echo e(config('site.full_name')); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/css/site.css', 'resources/js/app.js']); ?>
</head>
<body>
    <a class="skip-link" href="#main-content">رفتن به محتوای اصلی</a>

    <header class="masthead">
        <div class="container masthead-inner">
            <a class="masthead-brand" href="<?php echo e(route('home')); ?>" aria-label="<?php echo e(config('site.name')); ?>، صفحهٔ اصلی">
                <?php if(filled(config('site.logo_path'))): ?>
                    <img class="brand-image" src="<?php echo e(asset(config('site.logo_path'))); ?>" alt="">
                <?php else: ?>
                    <span class="brand-mark" aria-hidden="true"><?php echo e(config('site.logo_mark')); ?></span>
                <?php endif; ?>
                <span class="masthead-brand-copy">
                    <strong><?php echo e(config('site.name')); ?></strong>
                    <span><?php echo e(config('site.full_name')); ?></span>
                </span>
            </a>

            <nav class="masthead-links" aria-label="دسترسی سریع">
                <a href="<?php echo e(route('announcements.index')); ?>">اعلانات</a>
                <a href="<?php echo e(route('sessions.index')); ?>">جلسات</a>
                <a href="<?php echo e(route('notes.index')); ?>">یادداشت‌ها</a>
                <a href="<?php echo e(route('texts.index')); ?>">متن‌ها</a>
            </nav>

            <div class="masthead-actions">
                <a class="header-search" href="<?php echo e(route('search')); ?>" aria-label="جست‌وجو در پایگاه" title="جست‌وجو">
                    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><circle cx="10.8" cy="10.8" r="6.8" stroke="currentColor" stroke-width="1.7"/><path d="m16 16 4.4 4.4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
                </a>
                <?php if(auth()->guard()->check()): ?>
                    <a class="account-link" href="<?php echo e(route('account')); ?>">حساب کاربری</a>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage-content')): ?><a class="account-link" href="<?php echo e(route('admin.dashboard')); ?>">مدیریت</a><?php endif; ?>
                <?php else: ?>
                    <a class="account-link" href="<?php echo e(route('login')); ?>">ورود</a>
                <?php endif; ?>
            </div>

            <button class="icon-button menu-trigger" type="button" data-drawer-open aria-controls="site-drawer" aria-expanded="false" aria-label="باز کردن فهرست">
                <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
            </button>
        </div>
    </header>

    <?php if(config('site.demo_content_enabled')): ?>
        <div class="demo-banner" role="status">
            <span class="demo-banner-mark" aria-hidden="true">◇</span>
            این محتوا فقط برای نمایش طراحی است و جزو آرشیو واقعی نیست.
        </div>
    <?php endif; ?>

    <main id="main-content">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer class="site-footer">
        <div class="container footer-grid">
            <div>
                <a class="footer-brand" href="<?php echo e(route('home')); ?>"><?php echo e(config('site.name')); ?></a>
                <p class="footer-tagline"><?php echo e(config('site.tagline')); ?></p>
            </div>
            <nav class="footer-navigation" aria-label="پیوندهای پایین صفحه">
                <?php $__currentLoopData = config('site.navigation'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route($item['route'])); ?>"><?php echo e($item['label']); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
            <span class="footer-note">منبع و محتوای آرشیو پس از بررسی منتشر می‌شود.</span>
        </div>
    </footer>

    <dialog class="site-drawer" id="site-drawer" aria-labelledby="drawer-heading">
        <div class="drawer-heading">
            <div>
                <span class="drawer-kicker">فهرست منیبین</span>
                <h2 id="drawer-heading">بخش‌های پایگاه</h2>
            </div>
            <button class="icon-button drawer-close" type="button" data-drawer-close aria-label="بستن فهرست">
                <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
            </button>
        </div>
        <nav class="drawer-navigation" aria-label="ناوبری اصلی">
            <?php echo $__env->make('partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </nav>
        <div class="drawer-bottom">
            <a href="<?php echo e(route('search')); ?>">جست‌وجو در پایگاه <span aria-hidden="true">←</span></a>
            <span><?php echo e(config('site.tagline')); ?></span>
        </div>
    </dialog>

    <dialog class="image-lightbox" id="image-lightbox" aria-label="نمایش بزرگ تصویر">
        <button class="icon-button lightbox-close" type="button" data-lightbox-close aria-label="بستن تصویر">
            <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
        </button>
        <img src="" alt="">
        <p class="lightbox-caption"></p>
    </dialog>

    <button class="back-to-top" type="button" data-back-to-top aria-label="بازگشت به بالای صفحه" hidden>
        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="m6 14 6-6 6 6M12 8v12" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>
</body>
</html><?php /**PATH /workspaces/monibin12/resources/views/layouts/app.blade.php ENDPATH**/ ?>