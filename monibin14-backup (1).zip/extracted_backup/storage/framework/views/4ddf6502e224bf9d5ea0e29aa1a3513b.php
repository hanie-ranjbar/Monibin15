<ul class="nav-list">
    <?php $__currentLoopData = config('site.navigation'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <?php
                $activeRoute = str_contains($item['route'], '.')
                    ? explode('.', $item['route'])[0].'.*'
                    : $item['route'];
            ?>
            <a
                href="<?php echo e(route($item['route'])); ?>"
                <?php if(request()->routeIs($activeRoute)): ?> aria-current="page" <?php endif; ?>
            ><?php echo e($item['label']); ?></a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul><?php /**PATH /workspaces/monibin12/resources/views/partials/navigation.blade.php ENDPATH**/ ?>