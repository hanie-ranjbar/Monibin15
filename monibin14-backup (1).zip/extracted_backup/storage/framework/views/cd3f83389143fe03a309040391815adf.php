<?php $__env->startSection('content'); ?>
    <header class="archive-heading">
        <div class="container archive-heading-inner">
            <div>
                <p class="eyebrow"><?php echo e(config('site.name')); ?> <span aria-hidden="true">/</span> بایگانی</p>
                <h1><?php echo e($page['title']); ?></h1>
                <p class="archive-description"><?php echo e($page['description']); ?></p>
            </div>
            <?php if(in_array($section, ['sessions', 'series'], true)): ?>
                <a class="text-link archive-companion" href="<?php echo e(route($section === 'sessions' ? 'series.index' : 'sessions.index')); ?>"><?php echo e($section === 'sessions' ? 'دیدن سلسله‌جلسات' : 'آرشیو همهٔ جلسات'); ?> <span aria-hidden="true">←</span></a>
            <?php endif; ?>
        </div>
    </header>

    <?php if(collect($items)->contains('is_demo', true)): ?>
        <div class="container archive-demo-note"><span aria-hidden="true">◇</span> همهٔ موارد این صفحه دادهٔ نمایشی هستند و به آرشیو واقعی تعلق ندارند.</div>
    <?php endif; ?>

    <section class="container archive-body" aria-label="محتوای <?php echo e($page['title']); ?>">
        <?php if($section === 'search'): ?>
            <form class="search-form" action="<?php echo e(route('search')); ?>" method="GET">
                <label for="search-query">عبارت موردنظر</label>
                <div class="search-form-row">
                    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><circle cx="10.8" cy="10.8" r="6.8" stroke="currentColor" stroke-width="1.7"/><path d="m16 16 4.4 4.4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
                    <input id="search-query" name="q" type="search" value="<?php echo e(is_string($query) ? $query : ''); ?>" placeholder="جست‌وجو در جلسه‌ها و نوشته‌ها" maxlength="120">
                    <button class="button button-primary" type="submit">جست‌وجو</button>
                </div>
                <p class="form-help"><?php echo e($demoEnabled ? 'نتایج شامل محتوای منتشرشده و موارد دمو با برچسب مشخص هستند.' : 'جست‌وجو میان عنوان، خلاصه و متن محتوای منتشرشده انجام می‌شود.'); ?></p>
            </form>
        <?php endif; ?>

        <?php if($section === 'sessions' && (count($years) || count($categories))): ?>
            <form class="archive-filters" action="<?php echo e(route('sessions.index')); ?>" method="GET">
                <label>سال شمسی
                    <select name="year">
                        <option value="">همهٔ سال‌ها</option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($year); ?>" <?php if(request('year') === $year): echo 'selected'; endif; ?>><?php echo e(strtr($year, '0123456789', '۰۱۲۳۴۵۶۷۸۹')); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <label>موضوع
                    <select name="category">
                        <option value="">همهٔ موضوع‌ها</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($slug); ?>" <?php if(request('category') === $slug): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </label>
                <button class="button button-secondary" type="submit">اعمال فیلتر</button>
                <?php if(request()->hasAny(['year', 'category'])): ?>
                    <a class="filter-reset" href="<?php echo e(route('sessions.index')); ?>">پاک‌کردن فیلتر</a>
                <?php endif; ?>
            </form>
        <?php endif; ?>

        <?php if($section === 'tags' && count($items)): ?>
            <?php ($tagsBySlug = collect($items)->keyBy('slug')); ?>
            <div class="tag-tree">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="tag-tree-item">
                        <?php if($tag['is_demo'] ?? false): ?><span class="demo-label">نمایشی</span><?php endif; ?>
                        <h2><a href="<?php echo e(($tag['is_demo'] ?? false) ? route('search', ['q' => $tag['title']]) : route('tags.show', $tag['slug'])); ?>"><?php echo e($tag['title']); ?></a></h2>
                        <p><?php echo e($tag['description']); ?></p>
                        <?php if(isset($tag['content_count'])): ?><a href="<?php echo e(route('tags.show', $tag['slug'])); ?>"><?php echo e($tag['content_count']); ?> محتوای منتشرشده</a><?php endif; ?>
                        <?php if(count($tag['parent_slugs'])): ?>
                            <div class="tag-parents"><span>پیوندهای بالادستی</span>
                                <?php $__currentLoopData = $tag['parent_slugs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parentSlug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($tagsBySlug->has($parentSlug)): ?><a class="tag-chip" href="<?php echo e(($tagsBySlug->get($parentSlug)['is_demo'] ?? false) ? route('search', ['q' => $tagsBySlug->get($parentSlug)['title']]) : route('tags.show', $parentSlug)); ?>"><?php echo e($tagsBySlug->get($parentSlug)['title']); ?></a><?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <span class="tag-root">موضوع اصلی</span>
                        <?php endif; ?>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php elseif($section === 'gallery' && count($items)): ?>
            <div class="gallery-grid">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <figure class="gallery-item">
                        <button class="gallery-open" type="button" data-lightbox-open data-image="<?php echo e(($item['is_demo'] ?? false) ? asset($item['image']) : $item['image']); ?>" data-caption="<?php echo e($item['title']); ?><?php echo e(($item['is_demo'] ?? false) ? ' · تصویر نمایشی' : ''); ?>">
                            <img src="<?php echo e(($item['is_demo'] ?? false) ? asset($item['image']) : $item['image']); ?>" alt="<?php echo e($item['image_alt'] ?? $item['title']); ?>" loading="lazy" width="900" height="1200">
                            <span class="gallery-zoom" aria-hidden="true">↗</span>
                        </button>
                        <figcaption><span><?php echo e($item['title']); ?></span><?php if($item['is_demo'] ?? false): ?><span class="demo-label">تصویر دمو</span><?php endif; ?></figcaption>
                    </figure>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php elseif($section === 'about'): ?>
            <?php if($aboutContent): ?>
                <article class="editorial-empty reading-copy"><span class="editorial-empty-number"><?php echo e($aboutContent->title); ?></span><?php $__currentLoopData = preg_split('/\R{2,}/u', $aboutContent->body ?? ''); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><p><?php echo e($paragraph); ?></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></article>
            <?php else: ?>
                <div class="editorial-empty"><span class="editorial-empty-number">یادداشت سردبیر</span><h2>زندگی‌نامه پس از بررسی منابع منتشر می‌شود.</h2><p>در این نسخه اطلاعات تأییدنشده‌ای دربارهٔ استاد اضافه نشده است. هدف این پایگاه گردآوری و پیوند دادن درس‌ها، یادداشت‌ها و متن‌های منتشرشده است.</p></div>
            <?php endif; ?>
        <?php elseif($section === 'search' && is_string($query) && trim($query) !== ''): ?>
            <?php if(count($items)): ?>
                <?php $__currentLoopData = ['sessions' => 'جلسات', 'notes' => 'یادداشت‌ها', 'texts' => 'متن‌ها و مقاله‌ها', 'announcements' => 'اعلانات']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source => $sourceTitle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($groupItems = collect($items)->where('source', $source)); ?>
                    <?php if($groupItems->isNotEmpty()): ?><section class="search-result-group"><h2><?php echo e($sourceTitle); ?></h2><div class="content-grid"><?php $__currentLoopData = $groupItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php echo $__env->make('partials.content-card', ['item' => $item, 'type' => $source, 'detailRoute' => $item['detail_route'] ?? config("site.pages.{$source}.detail_route")], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div></section><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php echo $__env->make('partials.empty-state', ['title' => 'نتیجه‌ای پیدا نشد', 'message' => 'این عبارت در داده‌های نمایشی این پیش‌نمایش نبود.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        <?php elseif(in_array($section, ['tags', 'gallery'], true) && ! $demoEnabled): ?>
            <?php echo $__env->make('partials.empty-state', ['title' => 'آرشیو هنوز منتشر نشده است', 'message' => 'موارد این بخش پس از فراهم‌شدن و بررسی منابع معتبر منتشر می‌شوند.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif($section === 'series' && $demoEnabled && count($items)): ?>
            <div class="content-grid">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="series-card">
                        <div class="series-card-top"><span class="series-number"><?php echo e(strtr(str_pad((string) $loop->iteration, 2, '0', STR_PAD_LEFT), '0123456789', '۰۱۲۳۴۵۶۷۸۹')); ?></span><span class="demo-label">دمو</span></div>
                        <p class="eyebrow">سلسله‌جلسه / <?php echo e($item['category']); ?></p>
                        <h2><a href="<?php echo e(route($page['detail_route'], $item['slug'])); ?>"><?php echo e($item['title']); ?></a></h2>
                        <p><?php echo e($item['excerpt']); ?></p>
                        <span class="series-count"><?php echo e(strtr((string) count($item['session_slugs']), '0123456789', '۰۱۲۳۴۵۶۷۸۹')); ?> جلسه <span aria-hidden="true">←</span></span>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php elseif($section !== 'search' && count($items)): ?>
            <div class="content-grid">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('partials.content-card', ['item' => $item, 'type' => $section, 'detailRoute' => $page['detail_route'] ?? null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php elseif($section !== 'search'): ?>
            <?php echo $__env->make('partials.empty-state', ['title' => $demoEnabled ? 'هنوز موردی برای نمایش نیست' : 'هنوز محتوایی منتشر نشده است', 'message' => $demoEnabled ? 'دادهٔ نمایشی این بخش خالی است.' : 'این بخش پس از ثبت و بررسی محتوای معتبر تکمیل می‌شود.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif(! $demoEnabled): ?>
            <?php echo $__env->make('partials.empty-state', ['title' => $section === 'search' ? 'نتیجه‌ای پیدا نشد' : 'محتوایی برای نمایش نیست', 'message' => $section === 'search' ? 'این عبارت در محتوای منتشرشده پیدا نشد.' : 'پس از انتشار محتوا، موارد این بخش در اینجا نمایش داده می‌شوند.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php else: ?>
            <div class="search-prompt"><span aria-hidden="true">⌕</span><p>برای جست‌وجوی آزمایشی، عبارتی وارد کنید.</p></div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => $page['title'], 'description' => $page['description']], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monibin12/resources/views/pages/show.blade.php ENDPATH**/ ?>