<nav class="admin-navigation" aria-label="مدیریت محتوا">
    <a href="<?php echo e(route('admin.dashboard')); ?>">نمای کلی</a>
    <a href="<?php echo e(route('admin.content.index')); ?>">محتوا</a>
    <a href="<?php echo e(route('admin.tags.index')); ?>">برچسب‌ها</a>
    <a href="<?php echo e(route('home')); ?>">مشاهدهٔ پایگاه</a>
</nav><?php /**PATH /workspaces/monibin12/resources/views/admin/partials/navigation.blade.php ENDPATH**/ ?>