<?php $__env->startSection('content'); ?>
    <header class="archive-heading">
        <div class="container archive-heading-inner">
            <div>
                <p class="eyebrow"><a href="<?php echo e(route($section.'.index')); ?>"><?php echo e($page['title']); ?></a> <span aria-hidden="true">/</span> <?php echo e(($item['is_demo'] ?? false) ? 'نمونهٔ نمایشی' : 'محتوای منتشرشده'); ?></p>
                <h1><?php echo e($item['title']); ?></h1>
                <p class="archive-description"><?php echo e($item['excerpt'] ?? ''); ?></p>
            </div>
            <?php if(isset($item['date'])): ?><time class="detail-date"><?php echo e($item['date']); ?></time><?php endif; ?>
        </div>
    </header>

    <article class="container detail-layout">
        <div class="detail-main">
            <?php if(isset($item['image'])): ?>
                <figure class="detail-image"><img src="<?php echo e(asset($item['image'])); ?>" alt="<?php echo e($item['image_alt']); ?>" width="1200" height="1600"><figcaption>تصویر نمایشی · <?php echo e($item['image_alt']); ?></figcaption></figure>
            <?php endif; ?>

            <?php if(isset($item['body'])): ?>
                <div class="reading-copy">
                    <?php $__currentLoopData = $item['body']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><p><?php echo e($paragraph); ?></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php elseif(isset($item['series_sessions']) && count($item['series_sessions'])): ?>
                <ol class="series-session-list">
                    <?php $__currentLoopData = $item['series_sessions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('sessions.show', $session['slug'])); ?>"><span><?php echo e(strtr((string) $loop->iteration, '0123456789', '۰۱۲۳۴۵۶۷۸۹')); ?></span><span><strong><?php echo e($session['title']); ?></strong><small><?php echo e($session['date'] ?? ''); ?> · <?php echo e($session['category_label'] ?? ''); ?></small></span><span aria-hidden="true">←</span></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            <?php elseif(isset($item['session_slugs'])): ?>
                <?php ($sessionsBySlug = collect($content['sessions'])->keyBy('slug')); ?>
                <ol class="series-session-list">
                    <?php $__currentLoopData = $item['session_slugs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sessionSlug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($sessionsBySlug->has($sessionSlug)): ?>
                            <?php ($session = $sessionsBySlug->get($sessionSlug)); ?>
                            <li><a href="<?php echo e(route('sessions.show', $sessionSlug)); ?>"><span><?php echo e(strtr((string) $loop->iteration, '0123456789', '۰۱۲۳۴۵۶۷۸۹')); ?></span><span><strong><?php echo e($session['title']); ?></strong><small><?php echo e($session['date']); ?> · <?php echo e($session['category_label']); ?></small></span><span aria-hidden="true">←</span></a></li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ol>
            <?php else: ?>
                <div class="editorial-empty detail-summary"><span class="editorial-empty-number"><?php echo e($page['title']); ?></span><p><?php echo e($item['excerpt'] ?? ''); ?></p></div>
            <?php endif; ?>
        </div>

        <aside class="detail-sidebar">
            <?php if($item['is_demo'] ?? false): ?><span class="demo-label demo-label--solid">محتوای نمایشی</span><?php endif; ?>
            <?php if(isset($item['author']) && $item['author']): ?>
                <p class="detail-side-meta"><span>نویسنده</span><strong><?php echo e($item['author']); ?></strong></p>
            <?php endif; ?>
            <?php if(isset($item['category_label'])): ?>
                <p class="detail-side-meta"><span>موضوع</span><strong><?php echo e($item['category_label']); ?></strong></p>
            <?php endif; ?>
            <?php if(isset($item['series_url']) && $item['series_url']): ?>
                <p class="detail-side-meta"><span>سلسله‌جلسه</span><strong><a href="<?php echo e($item['series_url']); ?>"><?php echo e($item['series_title']); ?></a></strong></p>
            <?php elseif(isset($item['series_slug'])): ?>
                <?php ($series = collect($content['series'])->firstWhere('slug', $item['series_slug'])); ?>
                <?php if($series): ?><p class="detail-side-meta"><span>سلسله‌جلسه</span><strong><a href="<?php echo e(route('series.show', $series['slug'])); ?>"><?php echo e($series['title']); ?></a></strong></p><?php endif; ?>
            <?php endif; ?>
            <?php if(($item['is_demo'] ?? false) && isset($item['note_slugs']) && count($item['note_slugs'])): ?>
                <div class="detail-related"><span>یادداشت‌های مرتبط · دمو</span>
                    <?php $__currentLoopData = $item['note_slugs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noteSlug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php ($note = collect($content['notes'])->firstWhere('slug', $noteSlug)); ?>
                        <?php if($note): ?><a href="<?php echo e(route('notes.show', $noteSlug)); ?>"><?php echo e($note['title']); ?> <span aria-hidden="true">←</span></a><?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php if(isset($item['related_items']) && count($item['related_items'])): ?>
                <div class="detail-related"><span>محتوای مرتبط</span><?php $__currentLoopData = $item['related_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e($related['url']); ?>"><?php echo e($related['title']); ?> <span aria-hidden="true">←</span></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
            <?php endif; ?>
            <?php if(isset($item['parent_url']) && $item['parent_url']): ?><p class="detail-side-meta"><span>محتوای مادر</span><strong><a href="<?php echo e($item['parent_url']); ?>"><?php echo e($item['parent_title']); ?></a></strong></p><?php endif; ?>
            <?php if(isset($item['tags']) && count($item['tags'])): ?><div class="detail-related"><span>برچسب‌ها</span><?php $__currentLoopData = $item['tags']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(($item['is_demo'] ?? false) ? route('search', ['q' => $tag['title']]) : route('tags.show', $tag['slug'])); ?>"><?php echo e($tag['title']); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endif; ?>
            <a class="text-link detail-back" href="<?php echo e(route($section.'.index')); ?>">بازگشت به <?php echo e($page['title']); ?> <span aria-hidden="true">←</span></a>
        </aside>
    </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => $item['title'], 'description' => $item['excerpt'] ?? config('site.tagline')], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/monibin12/resources/views/pages/detail.blade.php ENDPATH**/ ?>