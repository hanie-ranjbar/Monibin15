const drawer = document.querySelector('#site-drawer');
const drawerTrigger = document.querySelector('[data-drawer-open]');
const drawerClose = document.querySelector('[data-drawer-close]');

if (drawer instanceof HTMLDialogElement && drawerTrigger instanceof HTMLButtonElement) {
	drawerTrigger.addEventListener('click', () => {
		if (!drawer.open) {
			drawer.showModal();
			drawerTrigger.setAttribute('aria-expanded', 'true');
			drawerClose?.focus();
		}
	});

	drawerClose?.addEventListener('click', () => drawer.close());
	drawer.addEventListener('click', (event) => {
		if (event.target === drawer) {
			drawer.close();
		}
	});
	drawer.addEventListener('close', () => {
		drawerTrigger.setAttribute('aria-expanded', 'false');
		drawerTrigger.focus();
	});
}

const lightbox = document.querySelector('#image-lightbox');
const lightboxImage = lightbox?.querySelector('img');
const lightboxCaption = lightbox?.querySelector('.lightbox-caption');

if (lightbox instanceof HTMLDialogElement && lightboxImage instanceof HTMLImageElement) {
	document.querySelectorAll('[data-lightbox-open]').forEach((trigger) => {
		trigger.addEventListener('click', () => {
			if (!(trigger instanceof HTMLButtonElement)) {
				return;
			}

			lightboxImage.src = trigger.dataset.image ?? '';
			lightboxImage.alt = trigger.querySelector('img')?.alt ?? '';

			if (lightboxCaption) {
				lightboxCaption.textContent = trigger.dataset.caption ?? '';
			}

			lightbox.showModal();
		});
	});

	lightbox.querySelector('[data-lightbox-close]')?.addEventListener('click', () => lightbox.close());
	lightbox.addEventListener('click', (event) => {
		if (event.target === lightbox) {
			lightbox.close();
		}
	});
}

const backToTop = document.querySelector('[data-back-to-top]');

if (backToTop instanceof HTMLButtonElement) {
	const updateVisibility = () => {
		backToTop.hidden = window.scrollY < 480;
	};

	window.addEventListener('scroll', updateVisibility, { passive: true });
	updateVisibility();
	backToTop.addEventListener('click', () => {
		window.scrollTo({
			top: 0,
			behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth',
		});
	});
}
