<ul class="nav-list">
    @foreach (config('site.navigation') as $item)
        <li>
            @php
                $activeRoute = str_contains($item['route'], '.')
                    ? explode('.', $item['route'])[0].'.*'
                    : $item['route'];
            @endphp
            <a
                href="{{ route($item['route']) }}"
                @if (request()->routeIs($activeRoute)) aria-current="page" @endif
            >{{ $item['label'] }}</a>
        </li>
    @endforeach
</ul>