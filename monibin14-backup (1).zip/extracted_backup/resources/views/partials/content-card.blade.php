@php
    $detailRoute = $detailRoute ?? null;
    $tagLookup = collect(config('demo_content.tags', []))->keyBy('slug');
    $image = $item['image'] ?? null;
    $cardTags = $item['tags'] ?? collect($item['tag_slugs'] ?? [])
        ->map(fn ($slug) => $tagLookup->get($slug))
        ->filter()
        ->map(fn ($tag) => ['slug' => $tag['slug'], 'title' => $tag['title']])
        ->all();
@endphp

<article class="content-card content-card--{{ $type }}">
    @if ($image)
        <a class="card-poster" href="{{ route($detailRoute ?? 'gallery.show', $item['slug']) }}">
            <img src="{{ ($item['is_demo'] ?? false) ? asset($image) : $image }}" alt="{{ $item['image_alt'] ?? $item['title'] }}" width="900" height="1200" loading="lazy">
            @if ($item['is_demo'] ?? false)<span class="demo-label poster-label">تصویر دمو</span>@endif
        </a>
    @else
        <div class="card-ornament" aria-hidden="true"><span>{{ strtr(str_pad((string) (crc32($item['slug']) % 99 + 1), 2, '0', STR_PAD_LEFT), '0123456789', '۰۱۲۳۴۵۶۷۸۹') }}</span><span class="ornament-rule"></span><span>منیبین</span></div>
    @endif

    <div class="card-content">
        <div class="card-meta"><span>{{ $item['category_label'] ?? $item['author'] ?? config("site.pages.{$type}.title", 'پایگاه') }}</span>@if ($item['is_demo'] ?? false)<span class="demo-label">دمو</span>@endif</div>
        <h3><a href="{{ route($detailRoute ?? ($item['detail_route'] ?? 'gallery.show'), $item['slug']) }}">{{ $item['title'] }}</a></h3>
        <p class="card-excerpt">{{ $item['excerpt'] ?? '' }}</p>
        <div class="card-bottom">
            @if (isset($item['date']))<time>{{ $item['date'] }}</time>@endif
            @if (isset($item['note_slugs']) && count($item['note_slugs']))<span>{{ strtr((string) count($item['note_slugs']), '0123456789', '۰۱۲۳۴۵۶۷۸۹') }} یادداشت پیوندخورده</span>@endif
            @if (count($cardTags))
                <div class="card-tags" aria-label="برچسب‌ها">
                    @foreach (array_slice($cardTags, 0, 2) as $tag)
                        <a class="tag-chip" href="{{ ($item['is_demo'] ?? false) ? route('search', ['q' => $tag['title']]) : route('tags.show', $tag['slug']) }}">{{ $tag['title'] }}</a>
                    @endforeach
                </div>
            @endif
            @if (! empty($item['audio']))<audio controls preload="none" aria-label="پخش صوت {{ $item['title'] }}"><source src="{{ $item['audio'] }}" type="{{ $item['media_mime'] ?? 'audio/mpeg' }}"></audio>@endif
            <a class="card-open" href="{{ route($detailRoute ?? ($item['detail_route'] ?? 'gallery.show'), $item['slug']) }}" aria-label="خواندن {{ $item['title'] }}">←</a>
        </div>
    </div>
</article>