<div class="archive-empty" role="status">
    <span class="archive-empty-symbol" aria-hidden="true">∅</span>
    <div><p class="eyebrow">{{ config('site.name') }} / آرشیو</p><h2>{{ $title }}</h2><p>{{ $message }}</p></div>
</div>