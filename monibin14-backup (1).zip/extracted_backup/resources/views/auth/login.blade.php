@extends('layouts.app', ['title' => 'ورود به حساب کاربری'])

@section('content')
    <section class="page-intro">
        <div class="container">
            <p class="eyebrow">حساب کاربری</p>
            <h1>ورود</h1>
            <p class="page-description">برای ورود، با حسابی که برای شما ایجاد شده است وارد شوید. ساخت حساب عمومی در این مرحله فعال نیست.</p>
        </div>
    </section>

    <section class="page-body container">
        <form class="auth-form" method="POST" action="{{ route('login.store') }}">
            @csrf

            <div class="form-field">
                <label class="field-label" for="email">ایمیل</label>
                <input id="email" name="email" type="email" value="{{ old('email') }}" autocomplete="username" dir="ltr" required autofocus aria-describedby="email-error">
                @error('email')
                    <p class="field-error" id="email-error">{{ $message }}</p>
                @enderror
            </div>

            <div class="form-field">
                <label class="field-label" for="password">گذرواژه</label>
                <input id="password" name="password" type="password" autocomplete="current-password" required aria-describedby="password-error">
                @error('password')
                    <p class="field-error" id="password-error">{{ $message }}</p>
                @enderror
            </div>

            <label class="remember-option">
                <input type="checkbox" name="remember" value="1">
                <span>مرا به خاطر بسپار</span>
            </label>

            <button class="primary-button" type="submit">ورود به حساب</button>
        </form>
    </section>
@endsection