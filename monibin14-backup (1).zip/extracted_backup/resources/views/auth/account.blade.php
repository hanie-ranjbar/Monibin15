@extends('layouts.app', ['title' => 'حساب کاربری'])

@section('content')
    <section class="page-intro">
        <div class="container">
            <p class="eyebrow">{{ config('site.name') }}</p>
            <h1>حساب کاربری</h1>
            <p class="page-description">واردشده با حساب {{ auth()->user()->email }}</p>
        </div>
    </section>

    <section class="page-body container">
        <p class="account-note">بخش‌های ویژهٔ حساب کاربری در مراحل بعدی توسعه داده می‌شوند.</p>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button class="text-action-button" type="submit">خروج از حساب</button>
        </form>
    </section>
@endsection