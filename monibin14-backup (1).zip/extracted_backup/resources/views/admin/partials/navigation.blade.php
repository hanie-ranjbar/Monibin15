<nav class="admin-navigation" aria-label="مدیریت محتوا">
    <a href="{{ route('admin.dashboard') }}">نمای کلی</a>
    <a href="{{ route('admin.content.index') }}">محتوا</a>
    <a href="{{ route('admin.tags.index') }}">برچسب‌ها</a>
    <a href="{{ route('home') }}">مشاهدهٔ پایگاه</a>
</nav>