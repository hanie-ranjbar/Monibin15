@extends('layouts.app', ['title' => $tag->exists ? 'ویرایش برچسب' : 'ساخت برچسب'])

@section('content')
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">مدیریت / برچسب‌ها</p><h1>{{ $tag->exists ? 'ویرایش برچسب' : 'ساخت برچسب' }}</h1><p class="archive-description">یک برچسب می‌تواند چند والد داشته باشد؛ ساخت پیوند دوری پذیرفته نمی‌شود.</p></div></div></header>
    <section class="container admin-page admin-form-page">
        @include('admin.partials.navigation')
        @include('admin.partials.flash')
        <form class="admin-form" method="POST" action="{{ $tag->exists ? route('admin.tags.update', $tag) : route('admin.tags.store') }}">
            @csrf
            @if ($tag->exists) @method('PUT') @endif
            <div class="admin-field"><label for="name">نام</label><input id="name" name="name" value="{{ old('name', $tag->name) }}" required maxlength="120">@error('name')<small class="field-error">{{ $message }}</small>@enderror</div>
            <div class="admin-field"><label for="slug">نشانی یکتا</label><input id="slug" name="slug" value="{{ old('slug', $tag->slug) }}" dir="auto" required maxlength="150">@error('slug')<small class="field-error">{{ $message }}</small>@enderror</div>
            <div class="admin-field admin-field--wide"><label for="description">تعریف</label><textarea id="description" name="description" rows="4">{{ old('description', $tag->description) }}</textarea>@error('description')<small class="field-error">{{ $message }}</small>@enderror</div>
            <fieldset class="admin-field admin-field--wide"><legend>برچسب‌های والد</legend><div class="admin-tag-options">@foreach ($availableTags as $parent)<label><input type="checkbox" name="parent_ids[]" value="{{ $parent->id }}" @checked(in_array($parent->id, (array) old('parent_ids', $tag->exists ? $tag->parents->modelKeys() : [])))><span>{{ $parent->name }}</span></label>@endforeach</div>@error('parent_ids')<small class="field-error">{{ $message }}</small>@enderror</fieldset>
            <div class="admin-form-actions"><button class="button button-primary" type="submit">ذخیرهٔ برچسب</button><a class="button button-secondary" href="{{ route('admin.tags.index') }}">بازگشت</a></div>
        </form>
    </section>
@endsection