@extends('layouts.app', ['title' => 'مدیریت محتوا'])

@section('content')
    <header class="archive-heading">
        <div class="container archive-heading-inner">
            <div><p class="eyebrow">فضای خصوصی</p><h1>مدیریت محتوا</h1><p class="archive-description">پیش‌نویس‌ها را بررسی و محتواهای آماده را منتشر کنید.</p></div>
        </div>
    </header>
    <section class="container admin-page">
        @include('admin.partials.navigation')
        @include('admin.partials.flash')
        <div class="admin-metrics">
            <a href="{{ route('admin.content.index', ['status' => 'draft']) }}"><strong>{{ $drafts }}</strong><span>پیش‌نویس</span></a>
            <a href="{{ route('admin.content.index', ['status' => 'published']) }}"><strong>{{ $published }}</strong><span>منتشرشده</span></a>
            <a href="{{ route('admin.content.index', ['status' => 'archived']) }}"><strong>{{ $archived }}</strong><span>بایگانی</span></a>
            <a href="{{ route('admin.tags.index') }}"><strong>{{ $tags }}</strong><span>برچسب فعال</span></a>
        </div>
        <div class="admin-actions">
            <a class="button button-primary" href="{{ route('admin.content.create') }}">ثبت محتوا</a>
            <a class="button button-secondary" href="{{ route('admin.tags.create') }}">ساخت برچسب</a>
        </div>
    </section>
@endsection