@extends('layouts.app', ['title' => config('site.full_name'), 'description' => config('site.tagline')])

@section('content')
    <section class="home-hero">
        <div class="container home-hero-grid">
            <div class="home-hero-copy">
                <p class="eyebrow"><span class="eyebrow-mark" aria-hidden="true">✳</span> یک پایگاه برای آموختن و بازخواندن</p>
                <h1>{{ config('site.full_name') }}</h1>
                <p class="hero-subtitle">درس‌ها و سخنرانی‌های {{ config('site.teacher') }}</p>
                <p class="hero-description">آرشیوی برای دسترسی روشن و پیوسته به جلسه‌ها، یادداشت‌ها و متن‌ها؛ با پیوندهایی برای بازگشت به ایده‌ها.</p>
                <a class="button button-primary" href="{{ route('sessions.index') }}">ورود به آرشیو جلسات <span aria-hidden="true">←</span></a>
            </div>
            <figure class="hero-artwork">
                <img src="{{ asset('images/demo/nigaristan-assembly.webp') }}" alt="نگارهٔ مینیاتور ایرانی از یک مجلس، تصویر نمایشی طراحی" width="1200" height="1516" fetchpriority="high">
                <figcaption><span>نگارگری ایرانی</span><span>تصویر نمایشی</span></figcaption>
            </figure>
            <div class="hero-index" aria-hidden="true"><span>پایگاه محتوایی</span><span>فارسی · راست‌به‌چپ</span></div>
        </div>
    </section>

    <div class="container home-sections">
        @foreach (config('site.home_sections') as $key => $title)
            @php
                $section = $sections[$key];
                $detailRoute = config("site.pages.{$key}.detail_route");
                $indexRoute = $key === 'announcements' ? 'announcements.index' : $key.'.index';
            @endphp
            <section class="content-section" aria-labelledby="home-{{ $key }}">
                <div class="section-header">
                    <div class="section-heading-copy">
                        <span class="section-index">{{ strtr(str_pad((string) $loop->iteration, 2, '0', STR_PAD_LEFT), '0123456789', '۰۱۲۳۴۵۶۷۸۹') }}</span>
                        <div>
                            <p class="eyebrow">پایگاه / {{ $title }}</p>
                            <h2 id="home-{{ $key }}">{{ $title }}</h2>
                        </div>
                    </div>
                    <a class="section-more" href="{{ route($indexRoute) }}">مشاهدهٔ همه <span aria-hidden="true">←</span></a>
                </div>

                @if (count($section['items']))
                    <div class="content-grid">
                        @foreach ($section['items'] as $item)
                            @include('partials.content-card', ['item' => $item, 'type' => $key, 'detailRoute' => $detailRoute])
                        @endforeach
                    </div>
                @else
                    <div class="section-empty">
                        <span class="empty-symbol" aria-hidden="true">↗</span>
                        <div>
                            <h3>هنوز محتوایی منتشر نشده است</h3>
                            <p>{{ $demoEnabled ? 'برای این بخش دادهٔ نمایشی هم ثبت نشده است.' : 'محتوای این بخش پس از ثبت و بررسی منابع منتشر می‌شود.' }}</p>
                        </div>
                        <a href="{{ route($indexRoute) }}" aria-label="رفتن به {{ $title }}">←</a>
                    </div>
                @endif
            </section>
        @endforeach
    </div>
@endsection