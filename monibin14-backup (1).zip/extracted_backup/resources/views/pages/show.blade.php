@extends('layouts.app', ['title' => $page['title'], 'description' => $page['description']])

@section('content')
    <header class="archive-heading">
        <div class="container archive-heading-inner">
            <div>
                <p class="eyebrow">{{ config('site.name') }} <span aria-hidden="true">/</span> بایگانی</p>
                <h1>{{ $page['title'] }}</h1>
                <p class="archive-description">{{ $page['description'] }}</p>
            </div>
            @if (in_array($section, ['sessions', 'series'], true))
                <a class="text-link archive-companion" href="{{ route($section === 'sessions' ? 'series.index' : 'sessions.index') }}">{{ $section === 'sessions' ? 'دیدن سلسله‌جلسات' : 'آرشیو همهٔ جلسات' }} <span aria-hidden="true">←</span></a>
            @endif
        </div>
    </header>

    @if (collect($items)->contains('is_demo', true))
        <div class="container archive-demo-note"><span aria-hidden="true">◇</span> همهٔ موارد این صفحه دادهٔ نمایشی هستند و به آرشیو واقعی تعلق ندارند.</div>
    @endif

    <section class="container archive-body" aria-label="محتوای {{ $page['title'] }}">
        @if ($section === 'search')
            <form class="search-form" action="{{ route('search') }}" method="GET">
                <label for="search-query">عبارت موردنظر</label>
                <div class="search-form-row">
                    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><circle cx="10.8" cy="10.8" r="6.8" stroke="currentColor" stroke-width="1.7"/><path d="m16 16 4.4 4.4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
                    <input id="search-query" name="q" type="search" value="{{ is_string($query) ? $query : '' }}" placeholder="جست‌وجو در جلسه‌ها و نوشته‌ها" maxlength="120">
                    <button class="button button-primary" type="submit">جست‌وجو</button>
                </div>
                <p class="form-help">{{ $demoEnabled ? 'نتایج شامل محتوای منتشرشده و موارد دمو با برچسب مشخص هستند.' : 'جست‌وجو میان عنوان، خلاصه و متن محتوای منتشرشده انجام می‌شود.' }}</p>
            </form>
        @endif

        @if ($section === 'sessions' && (count($years) || count($categories)))
            <form class="archive-filters" action="{{ route('sessions.index') }}" method="GET">
                <label>سال شمسی
                    <select name="year">
                        <option value="">همهٔ سال‌ها</option>
                        @foreach ($years as $year)
                            <option value="{{ $year }}" @selected(request('year') === $year)>{{ strtr($year, '0123456789', '۰۱۲۳۴۵۶۷۸۹') }}</option>
                        @endforeach
                    </select>
                </label>
                <label>موضوع
                    <select name="category">
                        <option value="">همهٔ موضوع‌ها</option>
                        @foreach ($categories as $slug => $label)
                            <option value="{{ $slug }}" @selected(request('category') === $slug)>{{ $label }}</option>
                        @endforeach
                    </select>
                </label>
                <button class="button button-secondary" type="submit">اعمال فیلتر</button>
                @if (request()->hasAny(['year', 'category']))
                    <a class="filter-reset" href="{{ route('sessions.index') }}">پاک‌کردن فیلتر</a>
                @endif
            </form>
        @endif

        @if ($section === 'tags' && count($items))
            @php($tagsBySlug = collect($items)->keyBy('slug'))
            <div class="tag-tree">
                @foreach ($items as $tag)
                    <article class="tag-tree-item">
                        @if ($tag['is_demo'] ?? false)<span class="demo-label">نمایشی</span>@endif
                        <h2><a href="{{ ($tag['is_demo'] ?? false) ? route('search', ['q' => $tag['title']]) : route('tags.show', $tag['slug']) }}">{{ $tag['title'] }}</a></h2>
                        <p>{{ $tag['description'] }}</p>
                        @if (isset($tag['content_count']))<a href="{{ route('tags.show', $tag['slug']) }}">{{ $tag['content_count'] }} محتوای منتشرشده</a>@endif
                        @if (count($tag['parent_slugs']))
                            <div class="tag-parents"><span>پیوندهای بالادستی</span>
                                @foreach ($tag['parent_slugs'] as $parentSlug)
                                    @if ($tagsBySlug->has($parentSlug))<a class="tag-chip" href="{{ ($tagsBySlug->get($parentSlug)['is_demo'] ?? false) ? route('search', ['q' => $tagsBySlug->get($parentSlug)['title']]) : route('tags.show', $parentSlug) }}">{{ $tagsBySlug->get($parentSlug)['title'] }}</a>@endif
                                @endforeach
                            </div>
                        @else
                            <span class="tag-root">موضوع اصلی</span>
                        @endif
                    </article>
                @endforeach
            </div>
        @elseif ($section === 'gallery' && count($items))
            <div class="gallery-grid">
                @foreach ($items as $item)
                    <figure class="gallery-item">
                        <button class="gallery-open" type="button" data-lightbox-open data-image="{{ ($item['is_demo'] ?? false) ? asset($item['image']) : $item['image'] }}" data-caption="{{ $item['title'] }}{{ ($item['is_demo'] ?? false) ? ' · تصویر نمایشی' : '' }}">
                            <img src="{{ ($item['is_demo'] ?? false) ? asset($item['image']) : $item['image'] }}" alt="{{ $item['image_alt'] ?? $item['title'] }}" loading="lazy" width="900" height="1200">
                            <span class="gallery-zoom" aria-hidden="true">↗</span>
                        </button>
                        <figcaption><span>{{ $item['title'] }}</span>@if ($item['is_demo'] ?? false)<span class="demo-label">تصویر دمو</span>@endif</figcaption>
                    </figure>
                @endforeach
            </div>
        @elseif ($section === 'about')
            @if ($aboutContent)
                <article class="editorial-empty reading-copy"><span class="editorial-empty-number">{{ $aboutContent->title }}</span>@foreach (preg_split('/\R{2,}/u', $aboutContent->body ?? '') as $paragraph)<p>{{ $paragraph }}</p>@endforeach</article>
            @else
                <div class="editorial-empty"><span class="editorial-empty-number">یادداشت سردبیر</span><h2>زندگی‌نامه پس از بررسی منابع منتشر می‌شود.</h2><p>در این نسخه اطلاعات تأییدنشده‌ای دربارهٔ استاد اضافه نشده است. هدف این پایگاه گردآوری و پیوند دادن درس‌ها، یادداشت‌ها و متن‌های منتشرشده است.</p></div>
            @endif
        @elseif ($section === 'search' && is_string($query) && trim($query) !== '')
            @if (count($items))
                @foreach (['sessions' => 'جلسات', 'notes' => 'یادداشت‌ها', 'texts' => 'متن‌ها و مقاله‌ها', 'announcements' => 'اعلانات'] as $source => $sourceTitle)
                    @php($groupItems = collect($items)->where('source', $source))
                    @if ($groupItems->isNotEmpty())<section class="search-result-group"><h2>{{ $sourceTitle }}</h2><div class="content-grid">@foreach ($groupItems as $item)@include('partials.content-card', ['item' => $item, 'type' => $source, 'detailRoute' => $item['detail_route'] ?? config("site.pages.{$source}.detail_route")])@endforeach</div></section>@endif
                @endforeach
            @else
                @include('partials.empty-state', ['title' => 'نتیجه‌ای پیدا نشد', 'message' => 'این عبارت در داده‌های نمایشی این پیش‌نمایش نبود.'])
            @endif
        @elseif (in_array($section, ['tags', 'gallery'], true) && ! $demoEnabled)
            @include('partials.empty-state', ['title' => 'آرشیو هنوز منتشر نشده است', 'message' => 'موارد این بخش پس از فراهم‌شدن و بررسی منابع معتبر منتشر می‌شوند.'])
        @elseif ($section === 'series' && $demoEnabled && count($items))
            <div class="content-grid">
                @foreach ($items as $item)
                    <article class="series-card">
                        <div class="series-card-top"><span class="series-number">{{ strtr(str_pad((string) $loop->iteration, 2, '0', STR_PAD_LEFT), '0123456789', '۰۱۲۳۴۵۶۷۸۹') }}</span><span class="demo-label">دمو</span></div>
                        <p class="eyebrow">سلسله‌جلسه / {{ $item['category'] }}</p>
                        <h2><a href="{{ route($page['detail_route'], $item['slug']) }}">{{ $item['title'] }}</a></h2>
                        <p>{{ $item['excerpt'] }}</p>
                        <span class="series-count">{{ strtr((string) count($item['session_slugs']), '0123456789', '۰۱۲۳۴۵۶۷۸۹') }} جلسه <span aria-hidden="true">←</span></span>
                    </article>
                @endforeach
            </div>
        @elseif ($section !== 'search' && count($items))
            <div class="content-grid">
                @foreach ($items as $item)
                    @include('partials.content-card', ['item' => $item, 'type' => $section, 'detailRoute' => $page['detail_route'] ?? null])
                @endforeach
            </div>
        @elseif ($section !== 'search')
            @include('partials.empty-state', ['title' => $demoEnabled ? 'هنوز موردی برای نمایش نیست' : 'هنوز محتوایی منتشر نشده است', 'message' => $demoEnabled ? 'دادهٔ نمایشی این بخش خالی است.' : 'این بخش پس از ثبت و بررسی محتوای معتبر تکمیل می‌شود.'])
        @elseif (! $demoEnabled)
            @include('partials.empty-state', ['title' => $section === 'search' ? 'نتیجه‌ای پیدا نشد' : 'محتوایی برای نمایش نیست', 'message' => $section === 'search' ? 'این عبارت در محتوای منتشرشده پیدا نشد.' : 'پس از انتشار محتوا، موارد این بخش در اینجا نمایش داده می‌شوند.'])
        @else
            <div class="search-prompt"><span aria-hidden="true">⌕</span><p>برای جست‌وجوی آزمایشی، عبارتی وارد کنید.</p></div>
        @endif
    </section>
@endsection