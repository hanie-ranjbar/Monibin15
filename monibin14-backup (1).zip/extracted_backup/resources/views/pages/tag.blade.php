@extends('layouts.app', ['title' => $tag->name, 'description' => $tag->description ?? 'محتوای پیوندخورده به برچسب'])

@section('content')
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow"><a href="{{ route('tags.index') }}">برچسب‌ها</a> / موضوع</p><h1>{{ $tag->name }}</h1><p class="archive-description">{{ $tag->description }}</p></div><span class="admin-status">{{ $tag->content_items_count }} محتوای منتشرشده</span></div></header>
    <section class="container archive-body">
        @if ($tag->parents->isNotEmpty())<div class="card-tags">@foreach ($tag->parents as $parent)<a class="tag-chip" href="{{ route('tags.show', $parent->slug) }}">{{ $parent->name }}</a>@endforeach</div>@endif
        @if ($items->count())<div class="content-grid">@foreach ($items as $item)@include('partials.content-card', ['item' => $item, 'type' => $item['section'], 'detailRoute' => $item['detail_route']])@endforeach</div>{{ $items->links() }}@else@include('partials.empty-state', ['title' => 'هنوز محتوای منتشرشده‌ای نیست', 'message' => 'محتوای مرتبط پس از انتشار در این صفحه دیده می‌شود.'])@endif
    </section>
@endsection