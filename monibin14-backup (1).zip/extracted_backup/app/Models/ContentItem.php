<?php

namespace App\Models;

use Database\Factories\ContentItemFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ContentItem extends Model
{
    /** @use HasFactory<ContentItemFactory> */
    use HasFactory;

    public const TYPES = ['session', 'series', 'note', 'text', 'article', 'announcement', 'about', 'gallery'];

    protected $fillable = [
        'type',
        'title',
        'slug',
        'excerpt',
        'body',
        'author',
        'category',
        'occurred_at',
        'status',
        'published_at',
        'archived_at',
        'metadata',
        'media_path',
        'media_kind',
        'media_mime',
        'media_alt',
        'parent_type',
        'parent_id',
        'series_id',
        'created_by',
        'updated_by',
    ];

    protected function casts(): array
    {
        return [
            'occurred_at' => 'date',
            'published_at' => 'datetime',
            'archived_at' => 'datetime',
            'metadata' => 'array',
        ];
    }

    public function scopePublished(Builder $query): void
    {
        $query->where('status', 'published')
            ->whereNull('archived_at')
            ->whereNotNull('published_at')
            ->where('published_at', '<=', now());
    }

    public function scopeOfType(Builder $query, string|array $types): void
    {
        is_array($types) ? $query->whereIn('type', $types) : $query->where('type', $types);
    }

    public function tags(): BelongsToMany
    {
        return $this->belongsToMany(Tag::class)->withTimestamps();
    }

    public function parent(): BelongsTo
    {
        return $this->belongsTo(self::class, 'parent_id');
    }

    public function children(): HasMany
    {
        return $this->hasMany(self::class, 'parent_id');
    }

    public function series(): BelongsTo
    {
        return $this->belongsTo(self::class, 'series_id');
    }

    public function sessions(): HasMany
    {
        return $this->hasMany(self::class, 'series_id');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}
