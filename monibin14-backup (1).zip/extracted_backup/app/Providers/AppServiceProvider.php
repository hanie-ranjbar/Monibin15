<?php

namespace App\Providers;

use App\Models\User;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Str;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Gate::define('manage-content', static fn (User $user): bool => $user->role === 'admin');

        RateLimiter::for('login', static function (Request $request): array {
            $email = $request->input('email');
            $normalizedEmail = is_string($email) ? Str::lower(trim($email)) : '';
            $ipAddress = $request->ip();

            return [
                Limit::perMinute(60)->by('ip:'.$ipAddress),
                Limit::perMinute(5)->by(Str::transliterate('account:'.$normalizedEmail.'|ip:'.$ipAddress)),
            ];
        });
    }
}
