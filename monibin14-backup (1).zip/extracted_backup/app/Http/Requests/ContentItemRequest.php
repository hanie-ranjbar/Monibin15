<?php

namespace App\Http\Requests;

use App\Models\ContentItem;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

class ContentItemRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return $this->user()?->can('manage-content') ?? false;
    }

    public function rules(): array
    {
        $item = $this->route('content');

        return [
            'type' => ['required', Rule::in(ContentItem::TYPES)],
            'title' => ['required', 'string', 'max:255'],
            'slug' => [
                'required',
                'string',
                'max:255',
                'regex:/^[\pL\pN]+(?:-[\pL\pN]+)*$/u',
                Rule::when($this->input('type') === 'about', ['in:about']),
                Rule::unique('content_items', 'slug')->ignore($item),
            ],
            'excerpt' => ['nullable', 'string', 'max:2000'],
            'body' => ['nullable', 'string'],
            'author' => ['nullable', 'string', 'max:255'],
            'category' => ['nullable', 'string', 'max:120'],
            'occurred_at' => ['nullable', 'date'],
            'status' => ['required', Rule::in(['draft', 'published'])],
            'series_id' => ['nullable', 'integer', Rule::exists('content_items', 'id')->where('type', 'series')->whereNull('archived_at')],
            'parent_type' => ['nullable', Rule::in(['session', 'text', 'article'])],
            'parent_id' => ['nullable', 'integer', 'required_with:parent_type', Rule::exists('content_items', 'id')->whereIn('type', ['session', 'text', 'article'])->whereNull('archived_at')],
            'tag_ids' => ['nullable', 'array'],
            'tag_ids.*' => ['integer', 'distinct', Rule::exists('tags', 'id')->whereNull('archived_at')],
            'media_kind' => ['nullable', Rule::in(['image', 'audio']), 'required_with:media'],
            'media' => [
                'nullable',
                'file',
                'max:51200',
                Rule::when($this->input('media_kind') === 'image', ['image', 'mimes:jpg,jpeg,png,webp', 'max:5120']),
                Rule::when($this->input('media_kind') === 'audio', ['mimes:mp3,wav,m4a']),
            ],
            'media_alt' => ['nullable', 'string', 'max:255'],
            'remove_media' => ['sometimes', 'boolean'],
        ];
    }

    public function after(): array
    {
        return [function (Validator $validator): void {
            if ($validator->errors()->hasAny(['parent_id', 'parent_type'])) {
                return;
            }

            $parentId = $this->integer('parent_id');
            $parentType = $this->input('parent_type');
            $item = $this->route('content');

            if ($parentId && $item instanceof ContentItem && $item->id === $parentId) {
                $validator->errors()->add('parent_id', 'یک محتوا نمی‌تواند محتوای مادر خودش باشد.');

                return;
            }

            if ($parentId && ContentItem::query()->whereKey($parentId)->value('type') !== $parentType) {
                $validator->errors()->add('parent_id', 'نوع محتوای مادر با محتوای انتخاب‌شده هم‌خوانی ندارد.');
            }

            if ($this->input('type') !== 'session' && $this->filled('series_id')) {
                $validator->errors()->add('series_id', 'فقط جلسه می‌تواند عضو یک سلسله‌جلسه باشد.');
            }

            if (! in_array($this->input('type'), ['note', 'text', 'article'], true) && $parentId) {
                $validator->errors()->add('parent_id', 'این نوع محتوا نمی‌تواند به محتوای مادر متصل شود.');
            }
        }];
    }
}
