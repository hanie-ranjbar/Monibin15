<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

class TagRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return $this->user()?->can('manage-content') ?? false;
    }

    public function rules(): array
    {
        $tag = $this->route('tag');

        return [
            'name' => ['required', 'string', 'max:120'],
            'slug' => ['required', 'string', 'max:150', 'regex:/^[\pL\pN]+(?:-[\pL\pN]+)*$/u', Rule::unique('tags', 'slug')->ignore($tag)],
            'description' => ['nullable', 'string', 'max:2000'],
            'parent_ids' => ['nullable', 'array'],
            'parent_ids.*' => ['integer', 'distinct', Rule::exists('tags', 'id')->whereNull('archived_at')],
        ];
    }

    public function after(): array
    {
        return [function (Validator $validator): void {
            $tag = $this->route('tag');
            $parentIds = array_map('intval', $this->input('parent_ids', []));

            if (! $tag || $validator->errors()->has('parent_ids.*')) {
                return;
            }

            if (in_array($tag->id, $parentIds, true)) {
                $validator->errors()->add('parent_ids', 'یک برچسب نمی‌تواند والد خودش باشد.');

                return;
            }

            $frontier = [$tag->id];
            $seen = [$tag->id => true];

            while ($frontier !== []) {
                $children = DB::table('tag_hierarchies')
                    ->whereIn('parent_id', $frontier)
                    ->pluck('child_id')
                    ->map(static fn ($id): int => (int) $id)
                    ->all();

                if (array_intersect($parentIds, $children) !== []) {
                    $validator->errors()->add('parent_ids', 'این پیوند، دور در ساختار برچسب‌ها ایجاد می‌کند.');

                    return;
                }

                $frontier = array_values(array_filter($children, static function (int $id) use (&$seen): bool {
                    if (isset($seen[$id])) {
                        return false;
                    }

                    $seen[$id] = true;

                    return true;
                }));
            }
        }];
    }
}
