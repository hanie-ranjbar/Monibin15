<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\ContentItemRequest;
use App\Models\ContentItem;
use App\Models\Tag;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use RuntimeException;
use Throwable;

class ContentItemController extends Controller
{
    public function index(Request $request): View
    {
        $items = ContentItem::query()
            ->with('tags')
            ->when($request->query('type'), fn ($query, $type) => $query->where('type', $type))
            ->when($request->query('status'), fn ($query, $status) => $query->where('status', $status))
            ->orderByDesc('updated_at')
            ->paginate(20)
            ->withQueryString();

        return view('admin.content.index', ['items' => $items]);
    }

    public function dashboard(): View
    {
        return view('admin.dashboard', [
            'drafts' => ContentItem::query()->where('status', 'draft')->count(),
            'published' => ContentItem::query()->published()->count(),
            'archived' => ContentItem::query()->where('status', 'archived')->count(),
            'tags' => Tag::query()->active()->count(),
        ]);
    }

    public function create(Request $request): View
    {
        return view('admin.content.form', [
            'item' => new ContentItem(['type' => $request->query('type', 'session')]),
            'tags' => Tag::query()->active()->orderBy('name')->get(),
            'parents' => $this->availableParents(),
            'series' => $this->availableSeries(),
        ]);
    }

    public function store(ContentItemRequest $request): RedirectResponse
    {
        $item = new ContentItem;
        $this->save($request, $item);

        return to_route('admin.content.edit', $item)->with('status', 'محتوا با موفقیت ذخیره شد.');
    }

    public function edit(ContentItem $content): View
    {
        abort_if($content->status === 'archived', 404);

        return view('admin.content.form', [
            'item' => $content->load('tags'),
            'tags' => Tag::query()->active()->orderBy('name')->get(),
            'parents' => $this->availableParents(),
            'series' => $this->availableSeries(),
        ]);
    }

    public function update(ContentItemRequest $request, ContentItem $content): RedirectResponse
    {
        abort_if($content->status === 'archived', 404);
        $this->save($request, $content);

        return to_route('admin.content.edit', $content)->with('status', 'تغییرات با موفقیت ذخیره شد.');
    }

    public function archive(Request $request, ContentItem $content): RedirectResponse
    {
        $content->forceFill(['status' => 'archived', 'archived_at' => now(), 'updated_by' => $request->user()->id])->save();

        return to_route('admin.content.index')->with('status', 'محتوا بایگانی شد؛ پیوندهای آن حفظ شده‌اند.');
    }

    public function restore(Request $request, ContentItem $content): RedirectResponse
    {
        abort_unless($content->status === 'archived', 404);

        $content->forceFill(['status' => 'draft', 'archived_at' => null, 'published_at' => null, 'updated_by' => $request->user()->id])->save();

        return to_route('admin.content.edit', $content)->with('status', 'محتوا به پیش‌نویس بازگردانده شد.');
    }

    private function save(ContentItemRequest $request, ContentItem $item): void
    {
        $validated = $request->validated();
        $attributes = Arr::only($validated, [
            'type', 'title', 'slug', 'excerpt', 'body', 'author', 'category', 'occurred_at',
            'series_id', 'parent_type', 'parent_id',
        ]);
        $previousMedia = $item->media_path;
        $storedMedia = null;

        try {
            DB::transaction(function () use ($request, $item, $validated, $attributes, &$storedMedia): void {
                $item->fill($attributes);
                $item->created_by ??= $request->user()->id;
                $item->updated_by = $request->user()->id;
                $item->status = $validated['status'];
                $item->published_at = $item->status === 'published' ? ($item->published_at ?? now()) : null;

                if ($item->type !== 'session') {
                    $item->series_id = null;
                }

                if (! in_array($item->type, ['note', 'text', 'article'], true)) {
                    $item->parent_type = null;
                    $item->parent_id = null;
                }

                $item->save();

                if ($request->hasFile('media')) {
                    $file = $request->file('media');
                    $filePath = $file->store('content/'.$item->id, 'local');

                    if (! is_string($filePath)) {
                        throw new RuntimeException('ذخیرهٔ فایل رسانه‌ای انجام نشد.');
                    }

                    $storedMedia = $filePath;
                    $item->forceFill([
                        'media_path' => $storedMedia,
                        'media_kind' => $validated['media_kind'],
                        'media_mime' => $file->getMimeType(),
                        'media_alt' => $validated['media_alt'] ?? null,
                    ])->save();
                } elseif ($request->boolean('remove_media')) {
                    $item->forceFill(['media_path' => null, 'media_kind' => null, 'media_mime' => null, 'media_alt' => null])->save();
                }

                $item->tags()->sync($validated['tag_ids'] ?? []);
            });
        } catch (Throwable $exception) {
            if ($storedMedia !== null) {
                Storage::disk('local')->delete($storedMedia);
            }

            throw $exception;
        }

        if ($previousMedia !== null && $previousMedia !== $item->media_path) {
            Storage::disk('local')->delete($previousMedia);
        }
    }

    private function availableParents()
    {
        return ContentItem::query()->whereIn('type', ['session', 'text', 'article'])->where('status', '!=', 'archived')->orderBy('title')->get(['id', 'type', 'title']);
    }

    private function availableSeries()
    {
        return ContentItem::query()->ofType('series')->where('status', '!=', 'archived')->orderBy('title')->get(['id', 'title']);
    }
}
