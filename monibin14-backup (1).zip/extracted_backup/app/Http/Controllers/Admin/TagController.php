<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\TagRequest;
use App\Models\Tag;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class TagController extends Controller
{
    public function index(): View
    {
        $tags = Tag::query()
            ->with(['parents', 'children'])
            ->withCount(['contentItems' => fn ($query) => $query->published()])
            ->orderByRaw('archived_at IS NOT NULL')
            ->orderBy('name')
            ->paginate(30);

        return view('admin.tags.index', ['tags' => $tags]);
    }

    public function create(): View
    {
        return view('admin.tags.form', ['tag' => new Tag, 'availableTags' => Tag::query()->active()->orderBy('name')->get()]);
    }

    public function store(TagRequest $request): RedirectResponse
    {
        $tag = Tag::query()->create($request->safe()->only(['name', 'slug', 'description']));
        $tag->parents()->sync($request->validated('parent_ids', []));

        return to_route('admin.tags.edit', $tag)->with('status', 'برچسب ساخته شد.');
    }

    public function edit(Tag $tag): View
    {
        return view('admin.tags.form', [
            'tag' => $tag->load('parents'),
            'availableTags' => Tag::query()->active()->whereKeyNot($tag->id)->orderBy('name')->get(),
        ]);
    }

    public function update(TagRequest $request, Tag $tag): RedirectResponse
    {
        abort_if($tag->archived_at, 404);

        $tag->update($request->safe()->only(['name', 'slug', 'description']));
        $tag->parents()->sync($request->validated('parent_ids', []));

        return to_route('admin.tags.edit', $tag)->with('status', 'تغییرات برچسب ذخیره شد.');
    }

    public function archive(Request $request, Tag $tag): RedirectResponse
    {
        $tag->forceFill(['archived_at' => now()])->save();

        return to_route('admin.tags.index')->with('status', 'برچسب بایگانی شد؛ محتواها و پیوندهایش حفظ شده‌اند.');
    }

    public function restore(Tag $tag): RedirectResponse
    {
        abort_unless($tag->archived_at, 404);

        $tag->forceFill(['archived_at' => null])->save();

        return to_route('admin.tags.edit', $tag)->with('status', 'برچسب بازیابی شد.');
    }
}
