<?php

namespace App\Http\Controllers;

use App\Models\ContentItem;
use App\Models\Tag;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class PageController extends Controller
{
    public function home(): View
    {
        $demoEnabled = config('site.demo_content_enabled');
        $content = $demoEnabled ? config('demo_content') : [];
        $typeMap = [
            'announcements' => ['announcement'],
            'sessions' => ['session'],
            'notes' => ['note'],
            'texts' => ['text', 'article'],
        ];

        return view('pages.home', [
            'demoEnabled' => $demoEnabled,
            'sections' => collect(config('site.home_sections'))->mapWithKeys(
                function (string $title, string $key) use ($content, $demoEnabled, $typeMap): array {
                    $liveItems = $this->publishedItems($typeMap[$key] ?? [$key], 3);
                    $demoItems = $demoEnabled ? array_slice($content[$key] ?? [], 0, 3) : [];

                    return [$key => ['title' => $title, 'items' => array_merge($liveItems, $demoItems)]];
                },
            ),
        ]);
    }

    public function show(Request $request, string $section): View
    {
        $page = config("site.pages.{$section}");

        abort_unless(is_array($page), 404);

        $demoEnabled = config('site.demo_content_enabled');
        $content = $demoEnabled ? config('demo_content') : [];
        $liveItems = match ($section) {
            'tags' => $this->publishedTags(),
            default => $this->publishedItems($this->contentTypes($section)),
        };
        $items = $section === 'search'
            ? array_merge($this->searchPublishedContent($request), $this->searchDemoContent($request, $content))
            : array_merge($liveItems, $content[$page['source'] ?? ''] ?? []);

        if ($section === 'sessions') {
            $year = $request->query('year');
            $category = $request->query('category');
            $items = array_values(array_filter($items, static fn (array $item): bool => (! is_string($year) || $year === '' || ($item['year'] ?? null) === $year)
                && (! is_string($category) || $category === '' || ($item['category'] ?? null) === $category)
            ));
        }

        $allSessions = $section === 'sessions'
            ? array_merge($this->publishedItems(['session']), $content['sessions'] ?? [])
            : [];
        $categories = [];

        foreach ($allSessions as $session) {
            if (($session['category'] ?? null) !== null) {
                $categories[$session['category']] = $session['category_label'] ?? $session['category'];
            }
        }

        return view('pages.show', [
            'section' => $section,
            'page' => $page,
            'items' => $items,
            'demoEnabled' => $demoEnabled,
            'content' => $content,
            'years' => array_values(array_unique(array_filter(array_column($allSessions, 'year')))),
            'categories' => $categories,
            'query' => $request->query('q', ''),
            'aboutContent' => $section === 'about'
                ? ContentItem::query()->published()->ofType('about')->where('slug', 'about')->first()
                : null,
            'liveTags' => $section === 'tags' ? $liveItems : [],
        ]);
    }

    public function showItem(string $slug, string $section): View
    {
        $source = config("site.pages.{$section}.source");
        $typeMap = $this->contentTypes($section);
        $liveItem = ContentItem::query()
            ->published()
            ->ofType($typeMap)
            ->with(['tags' => fn ($query) => $query->whereNull('archived_at'), 'parent', 'series', 'children' => fn ($query) => $query->published(), 'sessions' => fn ($query) => $query->published()])
            ->where('slug', $slug)
            ->first();

        if ($liveItem) {
            return view('pages.detail', [
                'section' => $section,
                'page' => config("site.pages.{$section}"),
                'item' => $this->present($liveItem),
                'content' => [],
            ]);
        }

        abort_unless(config('site.demo_content_enabled'), 404);
        $item = collect(config("demo_content.{$source}", []))->firstWhere('slug', $slug);

        abort_unless(is_array($item) && ($item['is_demo'] ?? false), 404);

        return view('pages.detail', [
            'section' => $section,
            'page' => config("site.pages.{$section}"),
            'item' => $item,
            'content' => config('demo_content'),
        ]);
    }

    public function showTag(string $tag): View
    {
        $tag = Tag::query()
            ->active()
            ->with(['parents' => fn ($query) => $query->active()])
            ->withCount(['contentItems' => fn ($query) => $query->published()])
            ->where('slug', $tag)
            ->firstOrFail();

        $items = $tag->contentItems()
            ->published()
            ->with(['tags' => fn ($query) => $query->whereNull('archived_at'), 'parent', 'series', 'children' => fn ($query) => $query->published()])
            ->orderByDesc('published_at')
            ->paginate(12)
            ->through(fn (ContentItem $item): array => $this->present($item));

        return view('pages.tag', ['tag' => $tag, 'items' => $items]);
    }

    private function searchPublishedContent(Request $request): array
    {
        $query = $request->query('q');

        if (! is_string($query) || trim($query) === '' || mb_strlen($query) > 120) {
            return [];
        }

        $needle = '%'.$this->normalizePersian($query).'%';
        $items = ContentItem::query()
            ->published()
            ->ofType(['session', 'note', 'text', 'article', 'announcement'])
            ->where(function (Builder $builder) use ($needle): void {
                foreach (['title', 'excerpt', 'body'] as $column) {
                    $builder->orWhereRaw($this->normalizedColumn($column).' LIKE ?', [$needle]);
                }
            })
            ->with(['tags' => fn ($query) => $query->whereNull('archived_at'), 'parent', 'series', 'children' => fn ($query) => $query->published()])
            ->orderByDesc('published_at')
            ->limit(40)
            ->get();

        return $items->map(function (ContentItem $item): array {
            $presented = $this->present($item);
            $presented['source'] = match ($item->type) {
                'session' => 'sessions',
                'note' => 'notes',
                'announcement' => 'announcements',
                default => 'texts',
            };

            return $presented;
        })->all();
    }

    private function searchDemoContent(Request $request, array $content): array
    {
        $query = $request->query('q');

        if (! config('site.demo_content_enabled') || ! is_string($query) || trim($query) === '' || mb_strlen($query) > 120) {
            return [];
        }

        $needle = $this->normalizePersian($query);

        return collect($content)
            ->only(['sessions', 'notes', 'texts', 'announcements'])
            ->flatMap(fn (array $items, string $source) => collect($items)
                ->filter(fn (array $item): bool => Str::contains(
                    $this->normalizePersian(($item['title'] ?? '').' '.($item['excerpt'] ?? '').' '.implode(' ', $item['body'] ?? [])),
                    $needle,
                ))
                ->map(static fn (array $item): array => [...$item, 'source' => $source]))
            ->values()
            ->all();
    }

    private function sessionCategories(array $sessions): array
    {
        $categories = [];

        foreach ($sessions as $session) {
            $categories[$session['category']] = $session['category_label'];
        }

        return $categories;
    }

    private function contentTypes(string $section): array
    {
        return match ($section) {
            'sessions' => ['session'],
            'series' => ['series'],
            'notes' => ['note'],
            'texts' => ['text', 'article'],
            'announcements' => ['announcement'],
            'gallery' => ['gallery'],
            default => [],
        };
    }

    private function publishedItems(array $types, ?int $limit = null): array
    {
        if ($types === []) {
            return [];
        }

        return ContentItem::query()
            ->published()
            ->ofType($types)
            ->with(['tags' => fn ($query) => $query->whereNull('archived_at'), 'parent', 'series', 'children' => fn ($query) => $query->published(), 'sessions' => fn ($query) => $query->published()])
            ->orderByDesc('published_at')
            ->when($limit, fn ($query, $limit) => $query->limit($limit))
            ->get()
            ->map(fn (ContentItem $item): array => $this->present($item))
            ->all();
    }

    private function publishedTags(): array
    {
        return Tag::query()
            ->active()
            ->with(['parents' => fn ($query) => $query->active()])
            ->withCount(['contentItems' => fn ($query) => $query->published()])
            ->orderBy('name')
            ->get()
            ->map(static fn (Tag $tag): array => [
                'slug' => $tag->slug,
                'title' => $tag->name,
                'description' => $tag->description,
                'parent_slugs' => $tag->parents->pluck('slug')->all(),
                'content_count' => $tag->content_items_count,
                'is_demo' => false,
            ])->all();
    }

    private function present(ContentItem $item): array
    {
        $item->loadMissing(['tags' => fn ($query) => $query->whereNull('archived_at'), 'parent', 'series', 'children' => fn ($query) => $query->published(), 'sessions' => fn ($query) => $query->published()]);
        $routeName = $this->detailRoute($item->type);
        $parent = $item->parent && $item->parent->status === 'published' ? $item->parent : null;
        $series = $item->series && $item->series->status === 'published' ? $item->series : null;
        $tags = $item->tags->map(static fn (Tag $tag): array => ['slug' => $tag->slug, 'title' => $tag->name])->all();

        return [
            'id' => $item->id,
            'slug' => $item->slug,
            'title' => $item->title,
            'excerpt' => $item->excerpt ?? '',
            'body' => $item->body ? preg_split('/\R{2,}/u', $item->body) : [],
            'author' => $item->author,
            'date' => $item->occurred_at?->format('Y/m/d'),
            'year' => $item->occurred_at?->format('Y'),
            'category' => $item->category,
            'category_label' => $item->category,
            'detail_route' => $routeName,
            'section' => match ($item->type) {
                'session' => 'sessions',
                'series' => 'series',
                'note' => 'notes',
                'announcement' => 'announcements',
                'gallery' => 'gallery',
                default => 'texts',
            },
            'url' => route($routeName, $item->slug),
            'image' => $item->media_kind === 'image' ? route('media.show', $item) : null,
            'image_alt' => $item->media_alt ?? $item->title,
            'audio' => $item->media_kind === 'audio' ? route('media.show', $item) : null,
            'series_slug' => $series?->slug,
            'series_title' => $series?->title,
            'series_url' => $series ? route('series.show', $series->slug) : null,
            'session_slug' => $parent?->type === 'session' ? $parent->slug : null,
            'parent_title' => $parent?->title,
            'parent_url' => $parent ? route($this->detailRoute($parent->type), $parent->slug) : null,
            'session_slugs' => $item->sessions->pluck('slug')->all(),
            'series_sessions' => $item->sessions->map(fn (ContentItem $session): array => $this->present($session))->all(),
            'note_slugs' => $item->children->where('type', 'note')->pluck('slug')->all(),
            'related_items' => $item->children->map(fn (ContentItem $child): array => [
                'title' => $child->title,
                'url' => route($this->detailRoute($child->type), $child->slug),
            ])->all(),
            'tag_slugs' => array_column($tags, 'slug'),
            'tags' => $tags,
            'is_demo' => false,
            'source' => match ($item->type) {
                'session' => 'sessions',
                'note' => 'notes',
                'announcement' => 'announcements',
                default => 'texts',
            },
        ];
    }

    private function detailRoute(string $type): string
    {
        return match ($type) {
            'session' => 'sessions.show',
            'series' => 'series.show',
            'note' => 'notes.show',
            'announcement' => 'announcements.show',
            'gallery' => 'gallery.show',
            default => 'texts.show',
        };
    }

    private function normalizePersian(string $value): string
    {
        return mb_strtolower(str_replace(['ي', 'ى', 'ك'], ['ی', 'ی', 'ک'], trim($value)), 'UTF-8');
    }

    private function normalizedColumn(string $column): string
    {
        return "replace(replace(replace(lower({$column}), 'ي', 'ی'), 'ى', 'ی'), 'ك', 'ک')";
    }
}
