<?php

namespace App\Models;

use App\Support\TagNameNormalizer;
use Database\Factories\TagFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Tag extends Model
{
    /** @use HasFactory<TagFactory> */
    use HasFactory;

    protected $fillable = ['name', 'slug', 'description', 'archived_at', 'normalized_name'];

    protected function casts(): array
    {
        return ['archived_at' => 'datetime'];
    }

    protected static function booted(): void
    {
        static::saving(static function (self $tag): void {
            $tag->normalized_name = TagNameNormalizer::normalize($tag->name);
        });
    }

    public function scopeActive(Builder $query): void
    {
        $query->whereNull('archived_at');
    }

    public function contentItems(): BelongsToMany
    {
        return $this->belongsToMany(ContentItem::class)->withTimestamps();
    }

    public function parents(): BelongsToMany
    {
        return $this->belongsToMany(self::class, 'tag_hierarchies', 'child_id', 'parent_id');
    }

    public function children(): BelongsToMany
    {
        return $this->belongsToMany(self::class, 'tag_hierarchies', 'parent_id', 'child_id');
    }
}
