<?php

namespace App\Models;

use Database\Factories\TagSuggestionFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class TagSuggestion extends Model
{
    /** @use HasFactory<TagSuggestionFactory> */
    use HasFactory;

    protected $fillable = ['name', 'normalized_name', 'status', 'suggested_by', 'reviewed_by', 'reviewed_at', 'resolved_tag_id'];

    protected function casts(): array
    {
        return ['reviewed_at' => 'datetime'];
    }

    public function suggester(): BelongsTo
    {
        return $this->belongsTo(User::class, 'suggested_by');
    }

    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }

    public function resolvedTag(): BelongsTo
    {
        return $this->belongsTo(Tag::class, 'resolved_tag_id');
    }

    public function contentItems(): BelongsToMany
    {
        return $this->belongsToMany(ContentItem::class)->withTimestamps();
    }
}
