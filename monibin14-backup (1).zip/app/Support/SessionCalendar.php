<?php

namespace App\Support;

use Morilog\Jalali\Jalalian;
use SDOSA\Hijri;
use SDOSA\HijriDate;
use Throwable;

class SessionCalendar
{
    private const SOLAR_MONTHS = [
        1 => 'فروردین',
        2 => 'اردیبهشت',
        3 => 'خرداد',
        4 => 'تیر',
        5 => 'مرداد',
        6 => 'شهریور',
        7 => 'مهر',
        8 => 'آبان',
        9 => 'آذر',
        10 => 'دی',
        11 => 'بهمن',
        12 => 'اسفند',
    ];

    private const HIJRI_MONTHS = [
        1 => 'محرم',
        2 => 'صفر',
        3 => 'ربیع‌الاول',
        4 => 'ربیع‌الثانی',
        5 => 'جمادی‌الاول',
        6 => 'جمادی‌الثانی',
        7 => 'رجب',
        8 => 'شعبان',
        9 => 'رمضان',
        10 => 'شوال',
        11 => 'ذی‌القعده',
        12 => 'ذی‌الحجه',
    ];

    public function toGregorianDate(string $solarDate): string
    {
        [$year, $month, $day] = $this->solarDateParts($solarDate);

        return (new Jalalian($year, $month, $day))->toCarbon()->toDateString();
    }

    public function toSolarDate(string $gregorianDate): string
    {
        return Jalalian::fromDateTime($gregorianDate)->format('%Y-%m-%d');
    }

    public function toHijriDate(string $gregorianDate): string
    {
        return Hijri::toHijri($gregorianDate)->toIso();
    }

    public function supportsHijriConversion(string $solarDate): bool
    {
        try {
            $this->toHijriDate($this->toGregorianDate($solarDate));

            return true;
        } catch (Throwable) {
            return false;
        }
    }

    public function isValidSolarDate(string $solarDate): bool
    {
        try {
            $this->solarDateParts($solarDate);

            return true;
        } catch (Throwable) {
            return false;
        }
    }

    public function isValidHijriDate(string $hijriDate): bool
    {
        try {
            HijriDate::fromString($hijriDate);

            return true;
        } catch (Throwable) {
            return false;
        }
    }

    public function formatSolarDate(?string $solarDate): ?string
    {
        if (! $solarDate || ! $this->isValidSolarDate($solarDate)) {
            return null;
        }

        [$year, $month, $day] = $this->solarDateParts($solarDate);

        return PersianDigits::localize($day.' '.self::SOLAR_MONTHS[$month].' '.$year);
    }

    public function formatHijriDate(?string $hijriDate): ?string
    {
        if (! $hijriDate || ! $this->isValidHijriDate($hijriDate)) {
            return null;
        }

        $date = HijriDate::fromString($hijriDate);

        return PersianDigits::localize($date->day().' '.self::HIJRI_MONTHS[$date->month()].' '.$date->year());
    }

    private function solarDateParts(string $solarDate): array
    {
        if (! preg_match('/^(\d{4})-(\d{2})-(\d{2})$/D', $solarDate, $matches)) {
            throw new \InvalidArgumentException('تاریخ شمسی باید با الگوی YYYY-MM-DD وارد شود.');
        }

        $date = new Jalalian((int) $matches[1], (int) $matches[2], (int) $matches[3]);

        return [$date->getYear(), $date->getMonth(), $date->getDay()];
    }
}
