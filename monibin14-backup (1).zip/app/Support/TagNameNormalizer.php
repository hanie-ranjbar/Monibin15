<?php

namespace App\Support;

class TagNameNormalizer
{
    public static function normalize(string $name): string
    {
        $name = strtr($name, ['ي' => 'ی', 'ى' => 'ی', 'ك' => 'ک', 'ـ' => '', '‌' => ' ']);
        $name = mb_strtolower($name, 'UTF-8');
        $name = preg_replace('/[\p{Mn}\p{Me}]+/u', '', $name) ?? $name;
        $name = preg_replace('/\s+/u', ' ', $name) ?? $name;

        return trim($name);
    }
}
