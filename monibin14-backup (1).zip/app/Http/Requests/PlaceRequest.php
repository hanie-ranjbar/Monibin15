<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class PlaceRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return $this->user()?->can('manage-content') ?? false;
    }

    public function rules(): array
    {
        $place = $this->route('place');

        return [
            'name' => ['required', 'string', 'max:255', Rule::unique('places', 'name')->ignore($place)],
            'code' => [
                Rule::requiredIf(! $place),
                'nullable',
                'string',
                'max:40',
                'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/',
                Rule::unique('places', 'code')->ignore($place),
            ],
        ];
    }
}
