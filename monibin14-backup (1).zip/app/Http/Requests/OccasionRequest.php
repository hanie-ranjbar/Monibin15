<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class OccasionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return $this->user()?->can('manage-content') ?? false;
    }

    public function rules(): array
    {
        $occasion = $this->route('occasion');

        return [
            'name' => ['required', 'string', 'max:255', Rule::unique('occasions', 'name')->ignore($occasion)],
            'code' => [
                'nullable',
                'string',
                'max:40',
                'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/',
                Rule::unique('occasions', 'code')->ignore($occasion),
            ],
        ];
    }
}
