<?php

namespace App\Http\Requests;

use App\Models\ContentItem;
use App\Models\Occasion;
use App\Models\Place;
use App\Models\Tag;
use App\Models\TagSuggestion;
use App\Support\SessionCalendar;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Validator;

class ContentItemRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return $this->user()?->can('manage-content') ?? false;
    }

    protected function prepareForValidation(): void
    {
        $digits = ['۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4', '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9', '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4', '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9'];

        foreach (['solar_date', 'hijri_date'] as $field) {
            if (is_string($this->input($field))) {
                $this->merge([$field => strtr(str_replace('/', '-', $this->input($field)), $digits)]);
            }
        }

        if ($this->boolean('tag_ids_present') && ! $this->exists('tag_ids')) {
            $this->merge(['tag_ids' => []]);
        }

        if ($this->boolean('tag_suggestions_present') && ! $this->exists('tag_suggestion_ids')) {
            $this->merge(['tag_suggestion_ids' => []]);
        }
    }

    public function rules(): array
    {
        $item = $this->route('content');
        $placeRules = match ($this->input('type')) {
            'session' => ['required', 'integer', Rule::exists('places', 'id')],
            'series' => ['nullable', 'integer', Rule::exists('places', 'id')],
            default => ['prohibited'],
        };

        return [
            'type' => ['required', Rule::in(ContentItem::TYPES)],
            'title' => ['required', 'string', 'max:255'],
            'excerpt' => [
                Rule::when($this->input('type') === 'note', ['prohibited'], ['nullable', 'string', 'max:2000']),
            ],
            'body' => [
                Rule::when(in_array($this->input('type'), ['note', 'text', 'article', 'announcement', 'about'], true), ['required', 'string'], ['nullable', 'string']),
            ],
            'author' => [Rule::when(in_array($this->input('type'), ['text', 'article'], true), ['nullable', 'string', 'max:255'], ['prohibited'])],
            'category' => [Rule::when(in_array($this->input('type'), ['series', 'article'], true), ['nullable', 'string', 'max:120'], ['prohibited'])],
            'solar_date' => [
                Rule::when($this->input('type') === 'session', ['required', 'string', 'regex:/^\d{4}-\d{2}-\d{2}$/'], ['prohibited']),
                'nullable',
                'string',
                'regex:/^\d{4}-\d{2}-\d{2}$/',
            ],
            'hijri_date' => [
                Rule::when($this->input('type') === 'session', ['nullable', 'string', 'regex:/^\d{4}-\d{2}-\d{2}$/'], ['prohibited']),
            ],
            'hijri_date_confirmed' => [Rule::when($this->input('type') === 'session', ['sometimes', 'boolean'], ['prohibited'])],
            'session_number' => [
                Rule::when($this->input('type') === 'session', ['nullable', 'integer', 'between:1,65535'], ['prohibited']),
            ],
            'place_id' => $placeRules,
            'occasion_id' => [
                Rule::when($this->input('type') === 'session', ['required', 'integer', Rule::exists('occasions', 'id')], ['prohibited']),
            ],
            'status' => ['required', Rule::in(['draft', 'published'])],
            'series_id' => [Rule::when($this->input('type') === 'session', ['nullable', 'integer', Rule::exists('content_items', 'id')->where('type', 'series')->whereNull('archived_at')], ['prohibited'])],
            'parent_type' => [Rule::when(in_array($this->input('type'), ['note', 'text', 'article'], true), ['nullable', Rule::in(['session', 'text', 'article'])], ['prohibited'])],
            'parent_id' => [Rule::when(in_array($this->input('type'), ['note', 'text', 'article'], true), ['nullable', 'integer', 'required_with:parent_type', Rule::exists('content_items', 'id')->whereIn('type', ['session', 'text', 'article'])->whereNull('archived_at')], ['prohibited'])],
            'tag_ids' => ['nullable', 'array'],
            'tag_ids.*' => ['integer', 'distinct', Rule::exists('tags', 'id')],
            'tag_suggestion_ids' => ['nullable', 'array'],
            'tag_suggestion_ids.*' => ['integer', 'distinct', Rule::exists('tag_suggestions', 'id')],
            'media_kind' => ['nullable', Rule::in(['image', 'audio']), 'required_with:media'],
            'media' => [
                'nullable',
                'file',
                'max:51200',
                Rule::when($this->input('media_kind') === 'image', ['image', 'mimes:jpg,jpeg,png,webp', 'max:5120']),
                Rule::when($this->input('media_kind') === 'audio', ['mimes:mp3,wav,m4a']),
            ],
            'media_alt' => ['nullable', 'string', 'max:255'],
            'remove_media' => ['sometimes', 'boolean'],
        ];
    }

    public function after(): array
    {
        return [function (Validator $validator): void {
            $calendar = new SessionCalendar;
            $item = $this->route('content');

            if ($item instanceof ContentItem && $this->input('type') !== $item->type) {
                $validator->errors()->add('type', 'نوع محتوای ذخیره‌شده قابل تغییر نیست.');
            }

            if ($this->input('type') === 'session' && $this->filled('solar_date') && ! $calendar->isValidSolarDate($this->string('solar_date')->toString())) {
                $validator->errors()->add('solar_date', 'تاریخ شمسی معتبر نیست.');
            }

            if ($this->input('type') === 'session' && $this->filled('solar_date') && ! $this->filled('hijri_date') && ! $calendar->supportsHijriConversion($this->string('solar_date')->toString())) {
                $validator->errors()->add('solar_date', 'برای این تاریخ، معادل قمری در بازهٔ پشتیبانی‌شده موجود نیست؛ تاریخ قمری آرشیو را دستی وارد کنید.');
            }

            if ($this->filled('hijri_date') && ! $calendar->isValidHijriDate($this->string('hijri_date')->toString())) {
                $validator->errors()->add('hijri_date', 'تاریخ قمری معتبر نیست.');
            }

            if ($this->boolean('hijri_date_confirmed') && ! $this->filled('hijri_date')) {
                $validator->errors()->add('hijri_date', 'برای تأیید، تاریخ قمری را وارد کنید.');
            }

            if ($validator->errors()->hasAny(['type', 'solar_date', 'hijri_date', 'place_id', 'occasion_id', 'session_number'])) {
                return;
            }

            foreach ([['place_id', Place::class], ['occasion_id', Occasion::class]] as [$field, $model]) {
                $referenceId = $this->integer($field);

                if (! $referenceId) {
                    continue;
                }

                $reference = $model::query()->find($referenceId);
                $currentId = $item?->{$field};

                if ($reference?->archived_at && (int) $currentId !== $referenceId) {
                    $validator->errors()->add($field, 'فقط مکان‌ها و مناسبت‌های فعال برای محتوای تازه قابل انتخاب‌اند.');

                    return;
                }
            }

            if ($validator->errors()->hasAny(['tag_ids.*', 'tag_suggestion_ids.*'])) {
                return;
            }

            if (collect($this->input('tag_suggestion_ids', []))->contains(function ($suggestionId) use ($item): bool {
                $suggestion = TagSuggestion::query()->find($suggestionId);

                return ! $suggestion || ($suggestion->status !== 'pending' && ! ($item?->tagSuggestions()->whereKey($suggestion->id)->exists() ?? false));
            })) {
                $validator->errors()->add('tag_suggestion_ids', 'فقط پیشنهادهای در انتظار بررسی قابل انتخاب‌اند.');

                return;
            }

            $contentTagIds = $item instanceof ContentItem
                ? $item->tags()->pluck('tags.id')->map(static fn ($id): int => (int) $id)->all()
                : [];

            foreach (array_map('intval', (array) $this->input('tag_ids', [])) as $tagId) {
                $tag = Tag::query()->find($tagId);

                if ($tag?->archived_at && ! in_array($tagId, $contentTagIds, true)) {
                    $validator->errors()->add('tag_ids', 'تگ‌های بایگانی‌شده فقط برای حفظ پیوندهای قبلی قابل نگهداری‌اند.');

                    return;
                }
            }

            if ($validator->errors()->hasAny(['parent_id', 'parent_type'])) {
                return;
            }

            $parentId = $this->integer('parent_id');
            $parentType = $this->input('parent_type');

            if ($parentId && $item instanceof ContentItem && $item->id === $parentId) {
                $validator->errors()->add('parent_id', 'یک محتوا نمی‌تواند محتوای مادر خودش باشد.');

                return;
            }

            if ($parentId && ContentItem::query()->whereKey($parentId)->value('type') !== $parentType) {
                $validator->errors()->add('parent_id', 'نوع محتوای مادر با محتوای انتخاب‌شده هم‌خوانی ندارد.');
            }
        }];
    }
}
