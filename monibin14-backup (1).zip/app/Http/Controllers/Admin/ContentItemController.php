<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\ContentItemRequest;
use App\Models\ContentItem;
use App\Models\Occasion;
use App\Models\Place;
use App\Models\Tag;
use App\Models\TagSuggestion;
use App\Support\SessionCalendar;
use Illuminate\Contracts\View\View;
use Illuminate\Database\QueryException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;
use Throwable;

class ContentItemController extends Controller
{
    public function index(Request $request): View
    {
        $items = ContentItem::query()
            ->with('tags')
            ->when($request->query('type'), fn ($query, $type) => $query->where('type', $type))
            ->when($request->query('status'), fn ($query, $status) => $query->where('status', $status))
            ->orderByDesc('updated_at')
            ->paginate(20)
            ->withQueryString();

        return view('admin.content.index', ['items' => $items]);
    }

    public function dashboard(): View
    {
        return view('admin.dashboard', [
            'drafts' => ContentItem::query()->where('status', 'draft')->count(),
            'published' => ContentItem::query()->published()->count(),
            'archived' => ContentItem::query()->where('status', 'archived')->count(),
            'tags' => Tag::query()->active()->count(),
        ]);
    }

    public function create(Request $request): View
    {
        $type = $request->query('type');

        if ($type === null) {
            return view('admin.content.choose', ['types' => config('content.types')]);
        }

        abort_unless(is_string($type) && in_array($type, ContentItem::TYPES, true), 404);

        $selectedTagIds = session()->getOldInput('tag_ids', []);
        $selectedSuggestionIds = session()->getOldInput('tag_suggestion_ids', []);

        return view('admin.content.form', [
            'item' => new ContentItem(['type' => $type]),
            'selectedTags' => Tag::query()->whereKey($selectedTagIds)->orderBy('name')->get(),
            'selectedTagSuggestions' => TagSuggestion::query()->whereKey($selectedSuggestionIds)->where('status', 'pending')->orderBy('name')->get(),
            'parents' => $this->availableParents(),
            'series' => $this->availableSeries(),
            'places' => Place::query()->whereNull('archived_at')->orderBy('name')->get(),
            'occasions' => Occasion::query()->whereNull('archived_at')->orderBy('number')->get(),
            'solarDate' => null,
        ]);
    }

    public function store(ContentItemRequest $request): RedirectResponse
    {
        $item = new ContentItem;
        $this->save($request, $item);

        return to_route('admin.content.edit', $item)->with('status', 'محتوا با موفقیت ذخیره شد.');
    }

    public function edit(ContentItem $content): View
    {
        abort_if($content->status === 'archived', 404);
        $calendar = new SessionCalendar;
        $solarDate = $content->solar_date;

        if ($solarDate === null && $content->occurred_at !== null) {
            $solarDate = $calendar->toSolarDate($content->occurred_at->toDateString());
        }

        $content->load(['tags', 'tagSuggestions']);
        $selectedTagIds = session()->getOldInput('tag_ids', $content->tags->modelKeys());
        $selectedSuggestionIds = session()->getOldInput('tag_suggestion_ids', $content->tagSuggestions->modelKeys());

        return view('admin.content.form', [
            'item' => $content,
            'selectedTags' => Tag::query()->whereKey($selectedTagIds)->orderBy('name')->get(),
            'selectedTagSuggestions' => TagSuggestion::query()->whereKey($selectedSuggestionIds)->where('status', 'pending')->orderBy('name')->get(),
            'parents' => $this->availableParents(),
            'series' => $this->availableSeries(),
            'places' => Place::query()->where(function ($query) use ($content): void {
                $query->whereNull('archived_at')->orWhereKey($content->place_id);
            })->orderBy('name')->get(),
            'occasions' => Occasion::query()->where(function ($query) use ($content): void {
                $query->whereNull('archived_at')->orWhereKey($content->occasion_id);
            })->orderBy('number')->get(),
            'solarDate' => $solarDate,
        ]);
    }

    public function update(ContentItemRequest $request, ContentItem $content): RedirectResponse
    {
        abort_if($content->status === 'archived', 404);
        $this->save($request, $content);

        return to_route('admin.content.edit', $content)->with('status', 'تغییرات با موفقیت ذخیره شد.');
    }

    public function archive(Request $request, ContentItem $content): RedirectResponse
    {
        $content->forceFill(['status' => 'archived', 'archived_at' => now(), 'updated_by' => $request->user()->id])->save();

        return to_route('admin.content.index')->with('status', 'محتوا بایگانی شد؛ پیوندهای آن حفظ شده‌اند.');
    }

    public function restore(Request $request, ContentItem $content): RedirectResponse
    {
        abort_unless($content->status === 'archived', 404);

        $content->forceFill(['status' => 'draft', 'archived_at' => null, 'published_at' => null, 'updated_by' => $request->user()->id])->save();

        return to_route('admin.content.edit', $content)->with('status', 'محتوا به پیش‌نویس بازگردانده شد.');
    }

    private function save(ContentItemRequest $request, ContentItem $item): void
    {
        $validated = $request->validated();
        $attributes = Arr::only($validated, [
            'type', 'title', 'excerpt', 'body', 'author', 'category', 'series_id', 'place_id',
            'occasion_id', 'session_number', 'solar_date', 'hijri_date', 'parent_type', 'parent_id',
        ]);
        $calendar = new SessionCalendar;

        if ($validated['type'] === 'session' && filled($validated['solar_date'] ?? null)) {
            $attributes['occurred_at'] = $calendar->toGregorianDate($validated['solar_date']);
            $requestedHijriDate = $validated['hijri_date'] ?? null;
            $attributes['hijri_date'] = filled($validated['hijri_date'] ?? null)
                ? $validated['hijri_date']
                : $calendar->toHijriDate($attributes['occurred_at']);
            $previousSolarDate = $item->solar_date ?? ($item->occurred_at ? $calendar->toSolarDate($item->occurred_at->toDateString()) : null);
            $calendarDateChanged = $item->exists && ($previousSolarDate !== $validated['solar_date'] || ($requestedHijriDate && $item->hijri_date !== $requestedHijriDate));
            $attributes['hijri_date_confirmed_at'] = $request->boolean('hijri_date_confirmed') && filled($requestedHijriDate)
                ? now()
                : ($calendarDateChanged || ! $request->boolean('hijri_date_confirmed') ? null : $item->hijri_date_confirmed_at);
        }

        if ($validated['type'] === 'session' && filled($validated['occasion_id'] ?? null)) {
            $attributes['category'] = Occasion::query()->whereKey($validated['occasion_id'])->value('name');
        }

        $attributes['slug'] = $item->exists ? $item->slug : $this->contentSlug($validated);
        $previousMedia = $item->media_path;
        $storedMedia = null;

        try {
            for ($attempt = 0; ; $attempt++) {
                try {
                    DB::transaction(function () use ($request, $item, $validated, $attributes, &$storedMedia): void {
                        $item->fill($attributes);
                        $item->created_by ??= $request->user()->id;
                        $item->updated_by = $request->user()->id;
                        $item->status = $validated['status'];
                        $item->published_at = $item->status === 'published' ? ($item->published_at ?? now()) : null;

                        if ($item->type !== 'session') {
                            $item->series_id = null;
                            $item->occasion_id = null;
                            $item->solar_date = null;
                            $item->hijri_date = null;
                            $item->hijri_date_confirmed_at = null;
                            $item->session_number = null;
                        }

                        if (! in_array($item->type, ['note', 'text', 'article'], true)) {
                            $item->parent_type = null;
                            $item->parent_id = null;
                        }

                        $item->save();

                        if ($request->hasFile('media')) {
                            $file = $request->file('media');
                            $filePath = $file->store('content/'.$item->id, 'local');

                            if (! is_string($filePath)) {
                                throw new RuntimeException('ذخیرهٔ فایل رسانه‌ای انجام نشد.');
                            }

                            $storedMedia = $filePath;
                            $item->forceFill([
                                'media_path' => $storedMedia,
                                'media_kind' => $validated['media_kind'],
                                'media_mime' => $file->getMimeType(),
                                'media_alt' => $validated['media_alt'] ?? null,
                            ])->save();
                        } elseif ($request->boolean('remove_media')) {
                            $item->forceFill(['media_path' => null, 'media_kind' => null, 'media_mime' => null, 'media_alt' => null])->save();
                        }

                        if ($request->boolean('tag_ids_present') || array_key_exists('tag_ids', $validated)) {
                            $item->tags()->sync($validated['tag_ids'] ?? []);
                        }

                        if ($request->boolean('tag_suggestions_present') || array_key_exists('tag_suggestion_ids', $validated)) {
                            $item->tagSuggestions()->sync($validated['tag_suggestion_ids'] ?? []);
                        }
                    });

                    break;
                } catch (QueryException $exception) {
                    if ($item->exists || $attempt >= 2 || ! $this->isSlugCollision($exception)) {
                        throw $exception;
                    }

                    $attributes['slug'] = $this->contentSlug($validated);
                }
            }
        } catch (Throwable $exception) {
            if ($storedMedia !== null) {
                Storage::disk('local')->delete($storedMedia);
            }

            throw $exception;
        }

        if ($previousMedia !== null && $previousMedia !== $item->media_path) {
            Storage::disk('local')->delete($previousMedia);
        }
    }

    private function availableParents()
    {
        return ContentItem::query()->whereIn('type', ['session', 'text', 'article'])->where('status', '!=', 'archived')->orderBy('title')->get(['id', 'type', 'title']);
    }

    private function availableSeries()
    {
        return ContentItem::query()->ofType('series')->where('status', '!=', 'archived')->orderBy('title')->get(['id', 'title']);
    }

    /** @param array<string, mixed> $validated */
    private function contentSlug(array $validated): string
    {
        if ($validated['type'] === 'session') {
            $occasion = Occasion::query()->findOrFail($validated['occasion_id']);
            $place = Place::query()->findOrFail($validated['place_id']);
            $base = 'HajRanjbar-'.str_replace('-', '', $validated['solar_date']).'-'.$occasion->code.'-'.$place->code;
        } else {
            $title = (string) $validated['title'];
            $parentTitle = isset($validated['parent_id'])
                ? ContentItem::query()->whereKey($validated['parent_id'])->value('title')
                : null;
            $source = $validated['type'] === 'about'
                ? 'about'
                : trim(($parentTitle ? $parentTitle.' ' : '').$title);
            $base = Str::slug($source);
        }

        if ($base === '') {
            $base = 'content-item';
        }

        $candidate = $base;
        $suffix = 2;

        while (ContentItem::query()->where('slug', $candidate)->exists()) {
            $candidate = $base.'-'.$suffix;
            $suffix++;
        }

        return $candidate;
    }

    private function isSlugCollision(QueryException $exception): bool
    {
        return str_contains($exception->getMessage(), 'content_items.slug')
            || str_contains($exception->getMessage(), 'content_items_slug_unique');
    }
}
