<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\PlaceRequest;
use App\Models\Place;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class PlaceController extends Controller
{
    public function index(): View
    {
        return view('admin.references.index', [
            'kind' => 'place',
            'records' => Place::query()->orderByRaw('archived_at IS NOT NULL')->orderBy('name')->paginate(30),
        ]);
    }

    public function create(): View
    {
        return view('admin.references.form', ['kind' => 'place', 'record' => new Place]);
    }

    public function store(PlaceRequest $request): RedirectResponse
    {
        $place = Place::query()->create($request->safe()->only(['name', 'code']));

        return to_route('admin.places.edit', $place)->with('status', 'مکان تازه ثبت شد.');
    }

    public function quickStore(PlaceRequest $request): JsonResponse
    {
        $place = Place::query()->create($request->safe()->only(['name', 'code']));

        return response()->json(['id' => $place->id, 'name' => $place->name, 'code' => $place->code], 201);
    }

    public function edit(Place $place): View
    {
        return view('admin.references.form', ['kind' => 'place', 'record' => $place]);
    }

    public function update(PlaceRequest $request, Place $place): RedirectResponse
    {
        abort_if($place->archived_at, 404);
        $place->update($request->safe()->only(['name']));

        return to_route('admin.places.edit', $place)->with('status', 'نام مکان ذخیره شد؛ کد ثابت ماند.');
    }

    public function archive(Request $request, Place $place): RedirectResponse
    {
        $place->forceFill(['archived_at' => now()])->save();

        return to_route('admin.places.index')->with('status', 'مکان بایگانی شد؛ پیوند جلسه‌ها حفظ شده است.');
    }

    public function restore(Place $place): RedirectResponse
    {
        abort_unless($place->archived_at, 404);
        $place->forceFill(['archived_at' => null])->save();

        return to_route('admin.places.edit', $place)->with('status', 'مکان بازیابی شد.');
    }
}
