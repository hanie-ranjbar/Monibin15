<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\TagSuggestionRequest;
use App\Models\Tag;
use App\Models\TagSuggestion;
use App\Support\TagNameNormalizer;
use Illuminate\Contracts\View\View;
use Illuminate\Database\QueryException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class TagSuggestionController extends Controller
{
    public function store(TagSuggestionRequest $request): JsonResponse
    {
        $name = trim($request->string('name')->toString());
        $normalizedName = TagNameNormalizer::normalize($name);
        $existingTag = Tag::query()->where('normalized_name', $normalizedName)->first();

        if ($existingTag) {
            return response()->json([
                'message' => 'این تگ از قبل وجود دارد؛ از پیشنهادهای موجود انتخابش کنید.',
                'tag' => ['id' => $existingTag->id, 'name' => $existingTag->name],
            ], 422);
        }

        try {
            $suggestion = DB::transaction(function () use ($request, $name, $normalizedName): TagSuggestion {
                $suggestion = TagSuggestion::query()->where('normalized_name', $normalizedName)->lockForUpdate()->firstOrNew();

                if ($suggestion->exists && $suggestion->status !== 'rejected') {
                    return $suggestion;
                }

                $suggestion->fill([
                    'name' => $name,
                    'normalized_name' => $normalizedName,
                    'status' => 'pending',
                    'suggested_by' => $request->user()->id,
                    'reviewed_by' => null,
                    'reviewed_at' => null,
                    'resolved_tag_id' => null,
                ])->save();

                return $suggestion;
            });
        } catch (QueryException $exception) {
            if (! str_contains($exception->getMessage(), 'tag_suggestions.normalized_name')) {
                throw $exception;
            }

            $suggestion = TagSuggestion::query()->where('normalized_name', $normalizedName)->firstOrFail();
        }

        return response()->json([
            'id' => $suggestion->id,
            'name' => $suggestion->name,
            'status' => $suggestion->status,
            'message' => 'پیشنهاد برای بررسی مالک ثبت شد و هنوز تگ عمومی نیست.',
        ], 202);
    }

    public function index(): View
    {
        return view('admin.tags.suggestions', [
            'suggestions' => TagSuggestion::query()->with(['suggester', 'resolvedTag'])->withCount('contentItems')->orderByRaw("CASE WHEN status = 'pending' THEN 0 ELSE 1 END")->latest()->paginate(30),
            'tags' => Tag::query()->active()->orderBy('name')->get(['id', 'name']),
        ]);
    }

    public function update(Request $request, TagSuggestion $tagSuggestion): RedirectResponse
    {
        abort_unless($tagSuggestion->status === 'pending', 404);
        $validated = $request->validate(['name' => ['required', 'string', 'max:120']]);
        $normalizedName = TagNameNormalizer::normalize($validated['name']);

        if (Tag::query()->active()->where('normalized_name', $normalizedName)->exists()) {
            throw ValidationException::withMessages(['name' => 'تگی با این نام نرمال‌شده از قبل وجود دارد؛ پیشنهاد را ادغام کنید.']);
        }

        $conflictingSuggestion = TagSuggestion::query()->where('normalized_name', $normalizedName)->whereKeyNot($tagSuggestion->id)->exists();
        if ($conflictingSuggestion) {
            throw ValidationException::withMessages(['name' => 'پیشنهاد دیگری با همین نام وجود دارد.']);
        }

        $tagSuggestion->update(['name' => $validated['name'], 'normalized_name' => $normalizedName]);

        return to_route('admin.tag-suggestions.index')->with('status', 'پیشنهاد ویرایش شد.');
    }

    public function approve(Request $request, TagSuggestion $tagSuggestion): RedirectResponse
    {
        abort_unless($tagSuggestion->status === 'pending', 404);

        DB::transaction(function () use ($request, $tagSuggestion): void {
            if (Tag::query()->where('normalized_name', $tagSuggestion->normalized_name)->exists()) {
                throw ValidationException::withMessages(['suggestion' => 'تگ مشابهی اضافه شده است؛ پیشنهاد را با همان تگ ادغام کنید.']);
            }

            $base = Str::slug($tagSuggestion->name) ?: 'tag';
            $slug = $base;
            $suffix = 2;
            while (Tag::query()->where('slug', $slug)->exists()) {
                $slug = $base.'-'.$suffix;
                $suffix++;
            }

            $tag = Tag::query()->create(['name' => $tagSuggestion->name, 'slug' => $slug]);
            $contentIds = $tagSuggestion->contentItems()->pluck('content_items.id')->all();
            $tag->contentItems()->syncWithoutDetaching($contentIds);
            $tagSuggestion->contentItems()->detach();
            $tagSuggestion->forceFill([
                'status' => 'approved',
                'resolved_tag_id' => $tag->id,
                'reviewed_by' => $request->user()->id,
                'reviewed_at' => now(),
            ])->save();
        });

        return to_route('admin.tag-suggestions.index')->with('status', 'تگ تأیید و به فهرست عمومی اضافه شد.');
    }

    public function merge(Request $request, TagSuggestion $tagSuggestion): RedirectResponse
    {
        abort_unless($tagSuggestion->status === 'pending', 404);
        $validated = $request->validate(['target_tag_id' => ['required', 'integer', 'exists:tags,id']]);
        $target = Tag::query()->active()->findOrFail($validated['target_tag_id']);

        DB::transaction(function () use ($request, $tagSuggestion, $target): void {
            $contentIds = $tagSuggestion->contentItems()->pluck('content_items.id')->all();
            $target->contentItems()->syncWithoutDetaching($contentIds);
            $tagSuggestion->contentItems()->detach();
            $tagSuggestion->forceFill([
                'status' => 'merged',
                'resolved_tag_id' => $target->id,
                'reviewed_by' => $request->user()->id,
                'reviewed_at' => now(),
            ])->save();
        });

        return to_route('admin.tag-suggestions.index')->with('status', 'پیشنهاد به تگ موجود پیوند خورد.');
    }

    public function destroy(TagSuggestion $tagSuggestion): RedirectResponse
    {
        if ($tagSuggestion->contentItems()->exists()) {
            throw ValidationException::withMessages(['suggestion' => 'این پیشنهاد به محتوا پیوند دارد؛ ابتدا آن را تأیید یا ادغام کنید.']);
        }

        $tagSuggestion->delete();

        return to_route('admin.tag-suggestions.index')->with('status', 'پیشنهاد حذف شد.');
    }
}
