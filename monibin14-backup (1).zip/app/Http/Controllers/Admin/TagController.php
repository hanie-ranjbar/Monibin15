<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\TagRequest;
use App\Models\Tag;
use App\Support\TagNameNormalizer;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;
use Illuminate\Validation\ValidationException;

class TagController extends Controller
{
    public function index(): View
    {
        $tags = Tag::query()
            ->with(['parents', 'children'])
            ->withCount(['contentItems' => fn ($query) => $query->published()])
            ->orderByRaw('archived_at IS NOT NULL')
            ->orderBy('name')
            ->paginate(30);

        return view('admin.tags.index', [
            'tags' => $tags,
            'activeTags' => Gate::allows('manage-tag-suggestions') ? Tag::query()->active()->orderBy('name')->get(['id', 'name']) : collect(),
        ]);
    }

    public function search(Request $request): JsonResponse
    {
        $query = $request->query('q');

        if (! is_string($query) || mb_strlen(trim($query)) < 1 || mb_strlen($query) > 120) {
            return response()->json(['tags' => [], 'can_suggest' => false]);
        }

        $normalizedName = TagNameNormalizer::normalize($query);
        $tags = Tag::query()
            ->active()
            ->where('normalized_name', 'like', $normalizedName.'%')
            ->orderBy('name')
            ->limit(12)
            ->get(['id', 'name', 'slug', 'normalized_name']);
        $exactTagExists = Tag::query()->where('normalized_name', $normalizedName)->exists();

        return response()->json([
            'tags' => $tags->map(static fn (Tag $tag): array => [
                'id' => $tag->id,
                'name' => $tag->name,
                'exact' => $tag->normalized_name === $normalizedName,
            ]),
            'can_suggest' => ! $exactTagExists,
            'message' => $exactTagExists && ! $tags->contains('normalized_name', $normalizedName)
                ? 'تگی با این نام بایگانی شده است؛ از مالک بخواهید آن را بازیابی کند.'
                : null,
        ]);
    }

    public function create(): View
    {
        return view('admin.tags.form', ['tag' => new Tag, 'availableTags' => Tag::query()->active()->orderBy('name')->get()]);
    }

    public function store(TagRequest $request): RedirectResponse
    {
        $tag = Tag::query()->create($request->safe()->only(['name', 'slug', 'description']));
        $tag->parents()->sync($request->validated('parent_ids', []));

        return to_route('admin.tags.edit', $tag)->with('status', 'برچسب ساخته شد.');
    }

    public function edit(Tag $tag): View
    {
        return view('admin.tags.form', [
            'tag' => $tag->load('parents'),
            'availableTags' => Tag::query()->active()->whereKeyNot($tag->id)->orderBy('name')->get(),
        ]);
    }

    public function update(TagRequest $request, Tag $tag): RedirectResponse
    {
        abort_if($tag->archived_at, 404);

        $tag->update($request->safe()->only(['name', 'slug', 'description']));
        $tag->parents()->sync($request->validated('parent_ids', []));

        return to_route('admin.tags.edit', $tag)->with('status', 'تغییرات برچسب ذخیره شد.');
    }

    public function archive(Request $request, Tag $tag): RedirectResponse
    {
        $tag->forceFill(['archived_at' => now()])->save();

        return to_route('admin.tags.index')->with('status', 'برچسب بایگانی شد؛ محتواها و پیوندهایش حفظ شده‌اند.');
    }

    public function restore(Tag $tag): RedirectResponse
    {
        abort_unless($tag->archived_at, 404);

        $tag->forceFill(['archived_at' => null])->save();

        return to_route('admin.tags.edit', $tag)->with('status', 'برچسب بازیابی شد.');
    }

    public function merge(Request $request): RedirectResponse
    {
        Gate::authorize('manage-tag-suggestions');

        $validated = $request->validate([
            'source_tag_id' => ['required', 'integer', 'exists:tags,id'],
            'target_tag_id' => ['required', 'integer', 'different:source_tag_id', 'exists:tags,id'],
        ]);
        $source = Tag::query()->active()->findOrFail($validated['source_tag_id']);
        $target = Tag::query()->active()->findOrFail($validated['target_tag_id']);

        DB::transaction(function () use ($source, $target): void {
            $contentIds = $source->contentItems()->pluck('content_items.id')->all();
            $target->contentItems()->syncWithoutDetaching($contentIds);
            $source->contentItems()->detach();

            $sourceParents = DB::table('tag_hierarchies')->where('child_id', $source->id)->pluck('parent_id')->map(static fn ($id): int => (int) $id)->all();
            $sourceChildren = DB::table('tag_hierarchies')->where('parent_id', $source->id)->pluck('child_id')->map(static fn ($id): int => (int) $id)->all();
            $edges = DB::table('tag_hierarchies')->where('parent_id', '!=', $source->id)->where('child_id', '!=', $source->id)->get(['parent_id', 'child_id']);
            $adjacency = [];

            foreach ($edges as $edge) {
                $adjacency[(int) $edge->parent_id][] = (int) $edge->child_id;
            }

            $replacementEdges = [];

            foreach ($sourceParents as $parentId) {
                if ($parentId !== $source->id && $parentId !== $target->id) {
                    $replacementEdges[] = [$parentId, $target->id];
                }
            }

            foreach ($sourceChildren as $childId) {
                if ($childId !== $source->id && $childId !== $target->id) {
                    $replacementEdges[] = [$target->id, $childId];
                }
            }

            foreach ($replacementEdges as [$parentId, $childId]) {
                if ($this->hasPath($adjacency, $childId, $parentId)) {
                    throw ValidationException::withMessages(['target_tag_id' => 'این ادغام ساختار والد و فرزند را دوری می‌کند.']);
                }

                $adjacency[$parentId][] = $childId;
            }

            DB::table('tag_hierarchies')->where('parent_id', $source->id)->orWhere('child_id', $source->id)->delete();

            foreach ($replacementEdges as [$parentId, $childId]) {
                DB::table('tag_hierarchies')->insertOrIgnore(['parent_id' => $parentId, 'child_id' => $childId]);
            }

            Tag::query()->where('id', $source->id)->update(['archived_at' => now(), 'updated_at' => now()]);
            DB::table('tag_suggestions')->where('resolved_tag_id', $source->id)->update(['resolved_tag_id' => $target->id]);
        });

        return to_route('admin.tags.index')->with('status', 'روابط محتوا و ساختار تگ به مقصد منتقل شد؛ تگ مبدأ برای حفظ نشانی بایگانی شد.');
    }

    private function hasPath(array $adjacency, int $start, int $target): bool
    {
        $frontier = [$start];
        $visited = [];

        while ($frontier !== []) {
            $current = array_pop($frontier);

            if ($current === $target) {
                return true;
            }

            if (isset($visited[$current])) {
                continue;
            }

            $visited[$current] = true;
            foreach ($adjacency[$current] ?? [] as $childId) {
                $frontier[] = $childId;
            }
        }

        return false;
    }
}
