<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\OccasionRequest;
use App\Models\Occasion;
use Illuminate\Contracts\View\View;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class OccasionController extends Controller
{
    public function index(): View
    {
        return view('admin.references.index', [
            'kind' => 'occasion',
            'records' => Occasion::query()->orderByRaw('archived_at IS NOT NULL')->orderBy('name')->paginate(30),
        ]);
    }

    public function create(): View
    {
        return view('admin.references.form', ['kind' => 'occasion', 'record' => new Occasion]);
    }

    public function store(OccasionRequest $request): RedirectResponse
    {
        $attributes = $request->safe()->only(['name', 'code']);
        $attributes['code'] = $this->uniqueCode($attributes['name'], $attributes['code'] ?? null);
        $occasion = Occasion::query()->create($attributes);

        return to_route('admin.occasions.edit', $occasion)->with('status', 'مناسبت تازه ثبت شد.');
    }

    public function quickStore(OccasionRequest $request): JsonResponse
    {
        $attributes = $request->safe()->only(['name', 'code']);
        $attributes['code'] = $this->uniqueCode($attributes['name'], $attributes['code'] ?? null);
        $occasion = Occasion::query()->create($attributes);

        return response()->json(['id' => $occasion->id, 'name' => $occasion->name, 'code' => $occasion->code], 201);
    }

    public function edit(Occasion $occasion): View
    {
        return view('admin.references.form', ['kind' => 'occasion', 'record' => $occasion]);
    }

    public function update(OccasionRequest $request, Occasion $occasion): RedirectResponse
    {
        abort_if($occasion->archived_at, 404);
        $occasion->update($request->safe()->only(['name']));

        return to_route('admin.occasions.edit', $occasion)->with('status', 'نام مناسبت ذخیره شد؛ کد ثابت ماند.');
    }

    public function archive(Request $request, Occasion $occasion): RedirectResponse
    {
        $occasion->forceFill(['archived_at' => now()])->save();

        return to_route('admin.occasions.index')->with('status', 'مناسبت بایگانی شد؛ اطلاعات جلسه‌ها حفظ شده است.');
    }

    public function restore(Occasion $occasion): RedirectResponse
    {
        abort_unless($occasion->archived_at, 404);
        $occasion->forceFill(['archived_at' => null])->save();

        return to_route('admin.occasions.edit', $occasion)->with('status', 'مناسبت بازیابی شد.');
    }

    private function uniqueCode(string $name, ?string $requestedCode): string
    {
        $base = Str::lower($requestedCode ?: Str::slug($name));
        $base = $base !== '' ? $base : 'occasion';
        $candidate = $base;
        $suffix = 2;

        while (Occasion::query()->where('code', $candidate)->exists()) {
            $candidate = $base.'-'.$suffix;
            $suffix++;
        }

        return $candidate;
    }
}
