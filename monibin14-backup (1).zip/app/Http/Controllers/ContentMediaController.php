<?php

namespace App\Http\Controllers;

use App\Models\ContentItem;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class ContentMediaController extends Controller
{
    public function __invoke(ContentItem $contentItem): BinaryFileResponse
    {
        $isPublic = $contentItem->status === 'published'
            && $contentItem->archived_at === null
            && $contentItem->published_at !== null
            && $contentItem->published_at->isPast();

        abort_unless($isPublic || Gate::allows('manage-content'), 404);
        abort_unless($contentItem->media_path && $contentItem->media_mime, 404);

        $allowedMimeTypes = [
            'image/jpeg', 'image/png', 'image/webp',
            'audio/mpeg', 'audio/wav', 'audio/x-wav', 'audio/mp4', 'audio/x-m4a',
        ];

        abort_unless(in_array($contentItem->media_mime, $allowedMimeTypes, true), 404);

        $path = Storage::disk('local')->path($contentItem->media_path);
        abort_unless(is_file($path), 404);

        return response()->file($path, [
            'Content-Type' => $contentItem->media_mime,
            'X-Content-Type-Options' => 'nosniff',
        ]);
    }
}
