<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;

#[Signature('content:make-admin {email} {name?} {--promote}')]
#[Description('Create an admin account or explicitly promote an existing account')]
class MakeAdminUser extends Command
{
    public function handle(): int
    {
        $email = (string) $this->argument('email');
        $existingUser = User::query()->where('email', $email)->first();

        if ($existingUser) {
            if (! $this->option('promote') || ! $this->confirm("Promote {$existingUser->email} to content admin?", false)) {
                $this->error('حساب از قبل وجود دارد. برای ارتقای صریح، --promote را به کار ببرید و تأیید کنید.');

                return self::FAILURE;
            }

            $existingUser->forceFill(['role' => 'admin'])->save();
            $this->info('سطح دسترسی مدیر محتوا برای حساب موجود فعال شد.');

            return self::SUCCESS;
        }

        $name = (string) ($this->argument('name') ?: $this->ask('نام مدیر'));
        $password = $this->secret('گذرواژهٔ مدیر (حداقل ۱۲ نویسه)');
        $passwordConfirmation = $this->secret('تکرار گذرواژه');
        $validator = Validator::make([
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'password_confirmation' => $passwordConfirmation,
        ], [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'unique:users,email'],
            'password' => ['required', 'confirmed', Password::min(12)],
        ]);

        if ($validator->fails()) {
            $this->error($validator->errors()->first());

            return self::FAILURE;
        }

        User::query()->create([
            'name' => $name,
            'email' => $email,
            'password' => $password,
            'role' => 'admin',
        ]);

        $this->info('حساب مدیر محتوا با موفقیت ساخته شد.');

        return self::SUCCESS;
    }
}
