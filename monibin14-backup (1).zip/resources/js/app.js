import '@majidh1/jalalidatepicker/dist/jalalidatepicker.min.js';

const drawer = document.querySelector('#site-drawer');
const drawerTrigger = document.querySelector('[data-drawer-open]');
const drawerClose = document.querySelector('[data-drawer-close]');

if (drawer instanceof HTMLDialogElement && drawerTrigger instanceof HTMLButtonElement) {
	drawerTrigger.addEventListener('click', () => {
		if (!drawer.open) {
			drawer.showModal();
			drawerTrigger.setAttribute('aria-expanded', 'true');
			drawerClose?.focus();
		}
	});

	drawerClose?.addEventListener('click', () => drawer.close());
	drawer.addEventListener('click', (event) => {
		if (event.target === drawer) {
			drawer.close();
		}
	});
	drawer.addEventListener('close', () => {
		drawerTrigger.setAttribute('aria-expanded', 'false');
		drawerTrigger.focus();
	});
}

const lightbox = document.querySelector('#image-lightbox');
const lightboxImage = lightbox?.querySelector('img');
const lightboxCaption = lightbox?.querySelector('.lightbox-caption');

if (lightbox instanceof HTMLDialogElement && lightboxImage instanceof HTMLImageElement) {
	document.querySelectorAll('[data-lightbox-open]').forEach((trigger) => {
		trigger.addEventListener('click', () => {
			if (!(trigger instanceof HTMLButtonElement)) {
				return;
			}

			lightboxImage.src = trigger.dataset.image ?? '';
			lightboxImage.alt = trigger.querySelector('img')?.alt ?? '';

			if (lightboxCaption) {
				lightboxCaption.textContent = trigger.dataset.caption ?? '';
			}

			lightbox.showModal();
		});
	});

	lightbox.querySelector('[data-lightbox-close]')?.addEventListener('click', () => lightbox.close());
	lightbox.addEventListener('click', (event) => {
		if (event.target === lightbox) {
			lightbox.close();
		}
	});
}

const backToTop = document.querySelector('[data-back-to-top]');

if (backToTop instanceof HTMLButtonElement) {
	const updateVisibility = () => {
		backToTop.hidden = window.scrollY < 480;
	};

	window.addEventListener('scroll', updateVisibility, { passive: true });
	updateVisibility();
	backToTop.addEventListener('click', () => {
		window.scrollTo({
			top: 0,
			behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth',
		});
	});
}

if (document.querySelector('[data-jdp]') && window.jalaliDatepicker) {
	window.jalaliDatepicker.startWatch();
}

document.querySelectorAll('[data-reference-open]').forEach((trigger) => {
	if (!(trigger instanceof HTMLButtonElement)) {
		return;
	}

	const dialog = document.querySelector(`[data-reference-dialog="${trigger.dataset.referenceOpen}"]`);

	if (!(dialog instanceof HTMLDialogElement)) {
		return;
	}

	trigger.addEventListener('click', () => dialog.showModal());
	dialog.querySelectorAll('[data-reference-close]').forEach((closeButton) => {
		closeButton.addEventListener('click', () => dialog.close());
	});
	dialog.addEventListener('click', (event) => {
		if (event.target === dialog) {
			dialog.close();
		}
	});
	dialog.addEventListener('close', () => trigger.focus());

	const form = dialog.querySelector('[data-reference-form]');
	const errorSummary = dialog.querySelector('[data-reference-error]');

	if (!(form instanceof HTMLFormElement) || !(errorSummary instanceof HTMLElement)) {
		return;
	}

	form.addEventListener('submit', async (event) => {
		event.preventDefault();
		errorSummary.hidden = true;
		errorSummary.textContent = '';
		dialog.querySelectorAll('[data-reference-field-error]').forEach((fieldError) => {
			fieldError.hidden = true;
			fieldError.textContent = '';
		});

		const submitButton = form.querySelector('button[type="submit"]');
		if (submitButton instanceof HTMLButtonElement) {
			submitButton.disabled = true;
		}

		try {
			const response = await fetch(form.action, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
				body: new FormData(form),
			});
			const payload = await response.json();

			if (response.status === 422 && payload.errors) {
				Object.entries(payload.errors).forEach(([field, messages]) => {
					const fieldError = dialog.querySelector(`[data-reference-field-error="${field}"]`);
					if (fieldError instanceof HTMLElement) {
						fieldError.textContent = Array.isArray(messages) ? messages.join('، ') : String(messages);
						fieldError.hidden = false;
					}
				});
			} else if (!response.ok || !payload.id) {
				errorSummary.textContent = payload.message ?? 'ثبت مورد انجام نشد. دوباره تلاش کنید.';
				errorSummary.hidden = false;
			} else {
				const kind = dialog.dataset.referenceDialog;
				const select = document.querySelector(`[data-reference-select="${kind}"]`);
				if (select instanceof HTMLSelectElement) {
					const label = kind === 'place' ? `${payload.name} (${payload.code})` : `${payload.name} · ${payload.code}`;
					select.add(new Option(label, payload.id, true, true));
					select.dispatchEvent(new Event('change', { bubbles: true }));
				}
				form.reset();
				dialog.close();
			}
		} catch {
			errorSummary.textContent = 'ارتباط برقرار نشد؛ اطلاعات فرم اصلی حفظ شده است.';
			errorSummary.hidden = false;
		} finally {
			if (submitButton instanceof HTMLButtonElement) {
				submitButton.disabled = false;
			}
		}
	});
});

document.querySelectorAll('[data-tag-picker]').forEach((picker) => {
	if (!(picker instanceof HTMLElement)) {
		return;
	}

	const queryInput = picker.querySelector('[data-tag-query]');
	const resultList = picker.querySelector('[data-tag-results]');
	const selectedTags = picker.querySelector('[data-tag-selected]');
	const message = picker.querySelector('[data-tag-message]');

	if (!(queryInput instanceof HTMLInputElement) || !(resultList instanceof HTMLElement) || !(selectedTags instanceof HTMLElement) || !(message instanceof HTMLElement)) {
		return;
	}

	let searchTimer;
	let activeSearch;

	const showMessage = (text, isError = false) => {
		message.textContent = text;
		message.dataset.state = isError ? 'error' : 'info';
	};

	const selectTag = (tag, suggestion = false) => {
		const selector = suggestion ? `[data-suggestion-id="${tag.id}"]` : `[data-tag-id="${tag.id}"]`;
		if (selectedTags.querySelector(selector)) {
			return;
		}

		const chip = document.createElement('span');
		chip.className = suggestion ? 'tag-picker-chip tag-picker-chip--pending' : 'tag-picker-chip';
		chip.dataset.selectedTag = '';
		if (suggestion) {
			chip.dataset.suggestionId = String(tag.id);
		} else {
			chip.dataset.tagId = String(tag.id);
		}
		const hidden = document.createElement('input');
		hidden.type = 'hidden';
		hidden.name = suggestion ? 'tag_suggestion_ids[]' : 'tag_ids[]';
		hidden.value = String(tag.id);
		const name = document.createElement('span');
		name.textContent = suggestion ? `${tag.name} · در انتظار تأیید` : tag.name;
		const remove = document.createElement('button');
		remove.type = 'button';
		remove.dataset.tagRemove = '';
		remove.setAttribute('aria-label', `حذف ${tag.name}`);
		remove.textContent = '×';
		chip.append(hidden, name, remove);
		selectedTags.append(chip);
	};

	selectedTags.addEventListener('click', (event) => {
		if (event.target instanceof HTMLButtonElement && event.target.matches('[data-tag-remove]')) {
			event.target.closest('[data-selected-tag]')?.remove();
		}
	});

	queryInput.addEventListener('input', () => {
		window.clearTimeout(searchTimer);
		activeSearch?.abort();
		const query = queryInput.value.trim();
		resultList.replaceChildren();
		resultList.hidden = true;
		message.textContent = '';

		if (query.length < 1) {
			return;
		}

		searchTimer = window.setTimeout(async () => {
			activeSearch = new AbortController();
			try {
				const url = new URL(picker.dataset.searchUrl ?? '', window.location.origin);
				url.searchParams.set('q', query);
				const response = await fetch(url, { headers: { Accept: 'application/json' }, signal: activeSearch.signal });
				if (!response.ok) {
					throw new Error('tag-search-failed');
				}
				const payload = await response.json();
				payload.tags.forEach((tag) => {
					const option = document.createElement('button');
					option.type = 'button';
					option.className = 'tag-picker-option';
					option.role = 'option';
					option.textContent = tag.exact ? `${tag.name} · موجود` : tag.name;
					option.addEventListener('click', () => {
						selectTag(tag);
						queryInput.value = '';
						resultList.hidden = true;
						resultList.replaceChildren();
					});
					resultList.append(option);
				});

				if (payload.can_suggest && payload.tags.length === 0) {
					const suggest = document.createElement('button');
					suggest.type = 'button';
					suggest.className = 'tag-picker-option tag-picker-suggest';
					suggest.textContent = `پیشنهاد تگ جدید: ${query}`;
					suggest.addEventListener('click', async () => {
						try {
							const suggestionResponse = await fetch(picker.dataset.suggestionUrl ?? '', {
								method: 'POST',
								credentials: 'same-origin',
								headers: { Accept: 'application/json', 'Content-Type': 'application/json', 'X-CSRF-TOKEN': picker.dataset.csrf ?? '' },
								body: JSON.stringify({ name: query }),
							});
							const suggestion = await suggestionResponse.json();
							if (!suggestionResponse.ok) {
								showMessage(suggestion.message ?? 'پیشنهاد تگ ثبت نشد.', true);
								return;
							}
							if (suggestion.status === 'pending' && suggestion.id) {
								selectTag(suggestion, true);
							}
							showMessage(suggestion.message ?? 'پیشنهاد برای بررسی مالک ثبت شد.');
							queryInput.value = '';
							resultList.hidden = true;
							resultList.replaceChildren();
						} catch {
							showMessage('پیشنهاد تگ ارسال نشد؛ دوباره تلاش کنید.', true);
						}
					});
					resultList.append(suggest);
				}

				resultList.hidden = resultList.childElementCount === 0;
				if (resultList.hidden) {
					showMessage(payload.message ?? 'تگی پیدا نشد.');
				}
			} catch (error) {
				if (!(error instanceof DOMException && error.name === 'AbortError')) {
					showMessage('جست‌وجوی تگ انجام نشد.', true);
				}
			}
		}, 220);
	});

	queryInput.addEventListener('keydown', (event) => {
		if (event.key === 'ArrowDown') {
			const firstOption = resultList.querySelector('button');
			if (firstOption instanceof HTMLButtonElement) {
				event.preventDefault();
				firstOption.focus();
			}
		} else if (event.key === 'Escape') {
			resultList.hidden = true;
		}
	});

	resultList.addEventListener('keydown', (event) => {
		if (event.key === 'Escape') {
			event.preventDefault();
			resultList.hidden = true;
			queryInput.focus();
			return;
		}

		if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') {
			return;
		}

		const options = [...resultList.querySelectorAll('button')];
		const currentIndex = options.indexOf(document.activeElement);
		const nextIndex = event.key === 'ArrowDown'
			? Math.min(currentIndex + 1, options.length - 1)
			: Math.max(currentIndex - 1, 0);

		if (options[nextIndex] instanceof HTMLButtonElement) {
			event.preventDefault();
			options[nextIndex].focus();
		}
	});
});
