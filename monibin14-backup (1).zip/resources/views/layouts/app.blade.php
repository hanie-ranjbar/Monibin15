<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#f7f6f2">
    <meta name="description" content="{{ $description ?? config('site.tagline') }}">
    <title>{{ $title ?? config('site.name') }} | {{ config('site.full_name') }}</title>
    @vite(['resources/css/app.css', 'resources/css/site.css', 'resources/js/app.js'])
</head>
<body>
    <a class="skip-link" href="#main-content">رفتن به محتوای اصلی</a>

    <header class="masthead">
        <div class="container masthead-inner">
            <a class="masthead-brand" href="{{ route('home') }}" aria-label="{{ config('site.name') }}، صفحهٔ اصلی">
                @if (filled(config('site.logo_path')))
                    <img class="brand-image" src="{{ asset(config('site.logo_path')) }}" alt="">
                @else
                    <span class="brand-mark" aria-hidden="true">{{ config('site.logo_mark') }}</span>
                @endif
                <span class="masthead-brand-copy">
                    <strong>{{ config('site.name') }}</strong>
                    <span>{{ config('site.full_name') }}</span>
                </span>
            </a>

            <nav class="masthead-links" aria-label="دسترسی سریع">
                <a href="{{ route('announcements.index') }}">اعلانات</a>
                <a href="{{ route('sessions.index') }}">جلسات</a>
                <a href="{{ route('notes.index') }}">فیش‌ها</a>
                <a href="{{ route('texts.index') }}">متن‌ها</a>
            </nav>

            <div class="masthead-actions">
                <a class="header-search" href="{{ route('search') }}" aria-label="جست‌وجو در پایگاه" title="جست‌وجو">
                    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><circle cx="10.8" cy="10.8" r="6.8" stroke="currentColor" stroke-width="1.7"/><path d="m16 16 4.4 4.4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
                </a>
                @auth
                    <a class="account-link" href="{{ route('account') }}">حساب کاربری</a>
                    @can('manage-content')<a class="account-link" href="{{ route('admin.dashboard') }}">مدیریت</a>@endcan
                @else
                    <a class="account-link" href="{{ route('login') }}">ورود</a>
                @endauth
            </div>

            <button class="icon-button menu-trigger" type="button" data-drawer-open aria-controls="site-drawer" aria-expanded="false" aria-label="باز کردن فهرست">
                <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
            </button>
        </div>
    </header>

    @if (config('site.demo_content_enabled'))
        <div class="demo-banner" role="status">
            <span class="demo-banner-mark" aria-hidden="true">◇</span>
            این محتوا فقط برای نمایش طراحی است و جزو آرشیو واقعی نیست.
        </div>
    @endif

    <main id="main-content">
        @yield('content')
    </main>

    <footer class="site-footer">
        <div class="container footer-grid">
            <div>
                <a class="footer-brand" href="{{ route('home') }}">{{ config('site.name') }}</a>
                <p class="footer-tagline">{{ config('site.tagline') }}</p>
            </div>
            <nav class="footer-navigation" aria-label="پیوندهای پایین صفحه">
                @foreach (config('site.navigation') as $item)
                    <a href="{{ route($item['route']) }}">{{ $item['label'] }}</a>
                @endforeach
            </nav>
            <span class="footer-note">منبع و محتوای آرشیو پس از بررسی منتشر می‌شود.</span>
        </div>
    </footer>

    <dialog class="site-drawer" id="site-drawer" aria-labelledby="drawer-heading">
        <div class="drawer-heading">
            <div>
                <span class="drawer-kicker">فهرست منیبین</span>
                <h2 id="drawer-heading">بخش‌های پایگاه</h2>
            </div>
            <button class="icon-button drawer-close" type="button" data-drawer-close aria-label="بستن فهرست">
                <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
            </button>
        </div>
        <nav class="drawer-navigation" aria-label="ناوبری اصلی">
            @include('partials.navigation')
        </nav>
        <div class="drawer-bottom">
            <a href="{{ route('search') }}">جست‌وجو در پایگاه <span aria-hidden="true">←</span></a>
            <span>{{ config('site.tagline') }}</span>
        </div>
    </dialog>

    <dialog class="image-lightbox" id="image-lightbox" aria-label="نمایش بزرگ تصویر">
        <button class="icon-button lightbox-close" type="button" data-lightbox-close aria-label="بستن تصویر">
            <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="m6 6 12 12M18 6 6 18" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
        </button>
        <img src="" alt="">
        <p class="lightbox-caption"></p>
    </dialog>

    <button class="back-to-top" type="button" data-back-to-top aria-label="بازگشت به بالای صفحه" hidden>
        <svg aria-hidden="true" viewBox="0 0 24 24" fill="none"><path d="m6 14 6-6 6 6M12 8v12" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
    </button>
</body>
</html>