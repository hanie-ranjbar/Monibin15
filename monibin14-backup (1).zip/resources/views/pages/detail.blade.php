@extends('layouts.app', ['title' => $item['title'], 'description' => $item['excerpt'] ?? config('site.tagline')])

@section('content')
    <header class="archive-heading">
        <div class="container archive-heading-inner">
            <div>
                <p class="eyebrow"><a href="{{ route($section.'.index') }}">{{ $page['title'] }}</a> <span aria-hidden="true">/</span> {{ ($item['is_demo'] ?? false) ? 'نمونهٔ نمایشی' : 'محتوای منتشرشده' }}</p>
                <h1>{{ $item['title'] }}</h1>
                <p class="archive-description">{{ $item['excerpt'] ?? '' }}</p>
            </div>
            @if (isset($item['date']) && $item['date'])<time class="detail-date" @if (! empty($item['occurred_at']))datetime="{{ $item['occurred_at'] }}"@endif>{{ $item['date'] }}</time>@endif
        </div>
    </header>

    <article class="container detail-layout">
        <div class="detail-main">
            @if (isset($item['image']))
                <figure class="detail-image"><img src="{{ asset($item['image']) }}" alt="{{ $item['image_alt'] }}" width="1200" height="1600"><figcaption>تصویر نمایشی · {{ $item['image_alt'] }}</figcaption></figure>
            @endif

            @if (($item['section'] ?? null) === 'sessions' && ! empty($item['audio']))
                <section class="detail-audio" aria-label="پخش صوت جلسه">
                    <h2>شنیدن جلسه</h2>
                    <audio controls preload="none" aria-label="پخش صوت {{ $item['title'] }}"><source src="{{ $item['audio'] }}" type="{{ $item['media_mime'] ?? 'audio/mpeg' }}">مرورگر شما از پخش صوت پشتیبانی نمی‌کند.</audio>
                </section>
            @endif

            @if (isset($item['body']))
                <div class="reading-copy">
                    @foreach ($item['body'] as $paragraph)<p>{{ $paragraph }}</p>@endforeach
                </div>
            @elseif (isset($item['series_sessions']) && count($item['series_sessions']))
                <ol class="series-session-list">
                    @foreach ($item['series_sessions'] as $session)
                        <li><a href="{{ route('sessions.show', $session['slug']) }}"><span>{{ \App\Support\PersianDigits::localize($loop->iteration) }}</span><span><strong>{{ $session['title'] }}</strong><small>{{ $session['date'] ?? '' }} · {{ $session['category_label'] ?? '' }}</small></span><span aria-hidden="true">←</span></a></li>
                    @endforeach
                </ol>
            @elseif (isset($item['session_slugs']))
                @php($sessionsBySlug = collect($content['sessions'])->keyBy('slug'))
                <ol class="series-session-list">
                    @foreach ($item['session_slugs'] as $sessionSlug)
                        @if ($sessionsBySlug->has($sessionSlug))
                            @php($session = $sessionsBySlug->get($sessionSlug))
                            <li><a href="{{ route('sessions.show', $sessionSlug) }}"><span>{{ \App\Support\PersianDigits::localize($loop->iteration) }}</span><span><strong>{{ $session['title'] }}</strong><small>{{ $session['date'] }} · {{ $session['category_label'] }}</small></span><span aria-hidden="true">←</span></a></li>
                        @endif
                    @endforeach
                </ol>
            @else
                <div class="editorial-empty detail-summary"><span class="editorial-empty-number">{{ $page['title'] }}</span><p>{{ $item['excerpt'] ?? '' }}</p></div>
            @endif
        </div>

        <aside class="detail-sidebar">
            @if ($item['is_demo'] ?? false)<span class="demo-label demo-label--solid">محتوای نمایشی</span>@endif
            @if (isset($item['author']) && $item['author'])
                <p class="detail-side-meta"><span>نویسنده</span><strong>{{ $item['author'] }}</strong></p>
            @endif
            @if (isset($item['category_label']))
                <p class="detail-side-meta"><span>موضوع</span><strong>{{ $item['category_label'] }}</strong></p>
            @endif
            @if (! empty($item['hijri_date']))<p class="detail-side-meta"><span>تاریخ قمری تأییدشده</span><strong>{{ $item['hijri_date'] }}</strong></p>@endif
            @if (! empty($item['place_name']))<p class="detail-side-meta"><span>مکان برگزاری</span><strong>{{ $item['place_name'] }}</strong></p>@endif
            @if (isset($item['series_url']) && $item['series_url'])
                <p class="detail-side-meta"><span>سلسله‌جلسه</span><strong><a href="{{ $item['series_url'] }}">{{ $item['series_title'] }}</a></strong></p>
            @elseif (isset($item['series_slug']))
                @php($series = collect($content['series'])->firstWhere('slug', $item['series_slug']))
                @if ($series)<p class="detail-side-meta"><span>سلسله‌جلسه</span><strong><a href="{{ route('series.show', $series['slug']) }}">{{ $series['title'] }}</a></strong></p>@endif
            @endif
            @if (($item['is_demo'] ?? false) && isset($item['note_slugs']) && count($item['note_slugs']))
                <div class="detail-related"><span>فیش‌های مرتبط · دمو</span>
                    @foreach ($item['note_slugs'] as $noteSlug)
                        @php($note = collect($content['notes'])->firstWhere('slug', $noteSlug))
                        @if ($note)<a href="{{ route('notes.show', $noteSlug) }}">{{ $note['title'] }} <span aria-hidden="true">←</span></a>@endif
                    @endforeach
                </div>
            @endif
            @if (isset($item['related_items']) && count($item['related_items']))
                <div class="detail-related"><span>محتوای مرتبط</span>@foreach ($item['related_items'] as $related)<a href="{{ $related['url'] }}">{{ $related['title'] }} <span aria-hidden="true">←</span></a>@endforeach</div>
            @endif
            @if (isset($item['parent_url']) && $item['parent_url'])<p class="detail-side-meta"><span>محتوای مادر</span><strong><a href="{{ $item['parent_url'] }}">{{ $item['parent_title'] }}</a></strong></p>@endif
            @if (isset($item['tags']) && count($item['tags']))<div class="detail-related"><span>برچسب‌ها</span>@foreach ($item['tags'] as $tag)<a href="{{ ($item['is_demo'] ?? false) ? route('search', ['q' => $tag['title']]) : route('tags.show', $tag['slug']) }}">{{ $tag['title'] }}</a>@endforeach</div>@endif
            <a class="text-link detail-back" href="{{ route($section.'.index') }}">بازگشت به {{ $page['title'] }} <span aria-hidden="true">←</span></a>
        </aside>
    </article>
@endsection