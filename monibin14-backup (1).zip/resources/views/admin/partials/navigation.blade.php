<nav class="admin-navigation" aria-label="مدیریت محتوا">
    <a href="{{ route('admin.dashboard') }}">نمای کلی</a>
    <a href="{{ route('admin.content.index') }}">محتوا</a>
    <a href="{{ route('admin.tags.index') }}">برچسب‌ها</a>
    @can('manage-tag-suggestions')<a href="{{ route('admin.tag-suggestions.index') }}">پیشنهادهای تگ</a>@endcan
    <a href="{{ route('admin.places.index') }}">مکان‌ها</a>
    <a href="{{ route('admin.occasions.index') }}">مناسبت‌ها</a>
    <a href="{{ route('home') }}">مشاهدهٔ پایگاه</a>
</nav>