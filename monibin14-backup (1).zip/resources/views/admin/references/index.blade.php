@php
    $isPlace = $kind === 'place';
    $title = $isPlace ? 'مکان‌ها' : 'مناسبت‌ها';
    $singular = $isPlace ? 'مکان' : 'مناسبت';
    $routePrefix = 'admin.'.$kind.'s';
@endphp

@extends('layouts.app', ['title' => 'مدیریت '.$title])

@section('content')
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">فضای خصوصی / مدیریت</p><h1>{{ $title }}</h1><p class="archive-description">کدهای ثبت‌شده در شناسهٔ جلسه ثابت می‌مانند؛ فقط نام را ویرایش کنید.</p></div><a class="button button-primary" href="{{ route($routePrefix.'.create') }}">{{ $singular }} تازه</a></div></header>
    <section class="container admin-page">
        @include('admin.partials.navigation')
        @include('admin.partials.flash')
        <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>نام</th><th>کد</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>
            @forelse ($records as $record)
                <tr><td><a href="{{ route($routePrefix.'.edit', $record) }}">{{ $record->name }}</a></td><td dir="ltr">{{ $record->code }}</td><td>{{ $record->archived_at ? 'بایگانی‌شده' : 'فعال' }}</td><td class="admin-row-actions">@if ($record->archived_at)<form method="POST" action="{{ route($routePrefix.'.restore', $record) }}">@csrf<button class="text-link-button" type="submit">بازیابی</button></form>@else<a href="{{ route($routePrefix.'.edit', $record) }}">ویرایش نام</a><form method="POST" action="{{ route($routePrefix.'.archive', $record) }}">@csrf<button class="text-link-button" type="submit">بایگانی</button></form>@endif</td></tr>
            @empty
                <tr><td colspan="4">{{ $title }} ثبت نشده است.</td></tr>
            @endforelse
        </tbody></table></div>
        {{ $records->links() }}
    </section>
@endsection