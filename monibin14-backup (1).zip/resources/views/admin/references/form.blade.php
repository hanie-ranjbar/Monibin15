@php
    $isPlace = $kind === 'place';
    $singular = $isPlace ? 'مکان' : 'مناسبت';
    $routePrefix = 'admin.'.$kind.'s';
@endphp

@extends('layouts.app', ['title' => ($record->exists ? 'ویرایش ' : 'ساخت ').$singular])

@section('content')
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">مدیریت / <a href="{{ route($routePrefix.'.index') }}">{{ $isPlace ? 'مکان‌ها' : 'مناسبت‌ها' }}</a></p><h1>{{ $record->exists ? 'ویرایش '.$singular : 'ساخت '.$singular.' تازه' }}</h1><p class="archive-description">کد انگلیسی پس از ایجاد ثابت می‌ماند؛ مناسبت جدید بدون کد عددی ثبت می‌شود.</p></div></div></header>
    <section class="container admin-page admin-form-page">
        @include('admin.partials.navigation')
        @include('admin.partials.flash')
        <form class="admin-form" method="POST" action="{{ $record->exists ? route($routePrefix.'.update', $record) : route($routePrefix.'.store') }}">
            @csrf
            @if ($record->exists) @method('PUT') @endif
            <div class="admin-field"><label for="name">نام فارسی</label><input id="name" name="name" value="{{ old('name', $record->name) }}" required maxlength="255">@error('name')<small class="field-error">{{ $message }}</small>@enderror</div>
            <div class="admin-field"><label for="code">کد انگلیسی{{ $isPlace ? ' مکان' : ' مناسبت' }}</label><input id="code" name="code" value="{{ old('code', $record->code) }}" dir="ltr" @readonly($record->exists) @required($isPlace) maxlength="40" pattern="[a-z0-9]+(-[a-z0-9]+)*" placeholder="{{ $isPlace ? 'ans' : 'moharram' }}">@error('code')<small class="field-error">{{ $message }}</small>@enderror@if (! $isPlace && ! $record->exists)<small>اختیاری است؛ اگر خالی باشد از نام مناسبت ساخته می‌شود.</small>@endif</div>
            <div class="admin-form-actions"><button class="button button-primary" type="submit">ذخیرهٔ {{ $singular }}</button><a class="button button-secondary" href="{{ route($routePrefix.'.index') }}">بازگشت</a></div>
        </form>
    </section>
@endsection