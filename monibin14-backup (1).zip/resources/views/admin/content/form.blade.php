@php
    $type = $item->exists ? $item->type : old('type', $item->type);
    $typeLabel = config('content.types.'.$type);
    $hasExcerpt = in_array($type, ['session', 'series', 'text', 'article', 'announcement'], true);
    $hasBody = in_array($type, ['note', 'text', 'article', 'announcement', 'about'], true);
    $hasMedia = in_array($type, ['session', 'gallery', 'text', 'article', 'announcement'], true) || filled($item->media_path);
    $mediaKind = $type === 'session' ? 'audio' : ($type === 'gallery' ? 'image' : $item->media_kind);
@endphp

@extends('layouts.app', ['title' => ($item->exists ? 'ویرایش ' : 'ثبت ').$typeLabel])

@section('content')
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">مدیریت / <a href="{{ route('admin.content.index') }}">محتوا</a></p><h1>{{ $item->exists ? 'ویرایش '.$typeLabel : 'ثبت '.$typeLabel.' تازه' }}</h1><p class="archive-description">نشانی محتوا هنگام ذخیره ساخته می‌شود و در ویرایش ثابت می‌ماند.</p></div></div></header>
    <section class="container admin-page admin-form-page">
        @include('admin.partials.navigation')
        @include('admin.partials.flash')
        <form class="admin-form" method="POST" action="{{ $item->exists ? route('admin.content.update', $item) : route('admin.content.store') }}" enctype="multipart/form-data">
            @csrf
            @if ($item->exists) @method('PUT') @endif
            <input type="hidden" name="type" value="{{ $type }}">
            <div class="admin-field"><span class="admin-field-label">نوع محتوا</span><strong>{{ $typeLabel }}</strong>@error('type')<small class="field-error">{{ $message }}</small>@enderror</div>
            <div class="admin-field"><label for="title">عنوان</label><input id="title" name="title" value="{{ old('title', $item->title) }}" required maxlength="255">@error('title')<small class="field-error">{{ $message }}</small>@enderror</div>
            @if ($item->exists)<p class="admin-field admin-field--wide"><span class="admin-field-label">نشانی ثابت</span><code dir="ltr">{{ $item->slug }}</code></p>@endif

            @if ($type === 'session')
                <div class="admin-field"><label for="solar_date">تاریخ برگزاری شمسی</label><input id="solar_date" name="solar_date" data-jdp autocomplete="off" dir="ltr" placeholder="۱۴۰۵/۰۷/۲۰" value="{{ str_replace('-', '/', old('solar_date', $solarDate ?? '')) }}" required>@error('solar_date')<small class="field-error">{{ $message }}</small>@enderror</div>
                <div class="admin-field"><label for="hijri_date">تاریخ قمری (قابل اصلاح)</label><input id="hijri_date" name="hijri_date" dir="ltr" inputmode="numeric" placeholder="۱۴۴۸-۰۵-۰۱" value="{{ old('hijri_date', $item->hijri_date) }}">
                    @error('hijri_date')<small class="field-error">{{ $message }}</small>@enderror
                    @if ($item->hijri_date && ! $item->hijri_date_confirmed_at)<small>تاریخ فعلی محاسبه‌شده است و هنوز تأیید نشده.</small>@endif
                </div>
                <div class="admin-field"><label for="place_id">مکان برگزاری</label><div class="admin-reference-control"><select id="place_id" name="place_id" data-reference-select="place" required><option value="">انتخاب مکان</option>@foreach ($places as $place)<option value="{{ $place->id }}" @selected((string) old('place_id', $item->place_id) === (string) $place->id)>{{ $place->name }} ({{ $place->code }})</option>@endforeach</select><button class="button button-secondary" type="button" data-reference-open="place">مکان جدید</button></div>@error('place_id')<small class="field-error">{{ $message }}</small>@enderror</div>
                <div class="admin-field"><label for="occasion_id">مناسبت</label><div class="admin-reference-control"><select id="occasion_id" name="occasion_id" data-reference-select="occasion" required><option value="">انتخاب مناسبت</option>@foreach ($occasions as $occasion)<option value="{{ $occasion->id }}" @selected((string) old('occasion_id', $item->occasion_id) === (string) $occasion->id)>{{ $occasion->name }} · {{ $occasion->code }}</option>@endforeach</select><button class="button button-secondary" type="button" data-reference-open="occasion">مناسبت جدید</button></div>@error('occasion_id')<small class="field-error">{{ $message }}</small>@enderror</div>
                <div class="admin-field"><label for="session_number">شمارهٔ جلسه در آرشیو (اختیاری)</label><input id="session_number" name="session_number" type="number" min="1" max="65535" value="{{ old('session_number', $item->session_number) }}">@error('session_number')<small class="field-error">{{ $message }}</small>@enderror</div>
                <div class="admin-field"><label for="series_id">سلسله‌جلسه (اختیاری)</label><select id="series_id" name="series_id"><option value="">بدون سلسله‌جلسه</option>@foreach ($series as $entry)<option value="{{ $entry->id }}" @selected((string) old('series_id', $item->series_id) === (string) $entry->id)>{{ $entry->title }}</option>@endforeach</select>@error('series_id')<small class="field-error">{{ $message }}</small>@enderror</div>
                <div class="admin-field admin-field--wide"><input type="hidden" name="hijri_date_confirmed" value="0"><label><input type="checkbox" name="hijri_date_confirmed" value="1" @checked((bool) old('hijri_date_confirmed', $item->hijri_date_confirmed_at))> تاریخ قمری را با منبع آرشیو تطبیق داده‌ام.</label></div>
            @elseif ($type === 'series')
                <div class="admin-field"><label for="place_id">مکان غالب (اختیاری)</label><div class="admin-reference-control"><select id="place_id" name="place_id" data-reference-select="place"><option value="">بدون مکان مشخص</option>@foreach ($places as $place)<option value="{{ $place->id }}" @selected((string) old('place_id', $item->place_id) === (string) $place->id)>{{ $place->name }} ({{ $place->code }})</option>@endforeach</select><button class="button button-secondary" type="button" data-reference-open="place">مکان جدید</button></div>@error('place_id')<small class="field-error">{{ $message }}</small>@enderror</div>
            @elseif (in_array($type, ['note', 'text', 'article'], true))
                <div class="admin-field"><label for="parent_type">نوع محتوای مادر (اختیاری)</label><select id="parent_type" name="parent_type"><option value="">بدون محتوای مادر</option><option value="session" @selected(old('parent_type', $item->parent_type) === 'session')>جلسه</option><option value="text" @selected(old('parent_type', $item->parent_type) === 'text')>متن جلسه</option><option value="article" @selected(old('parent_type', $item->parent_type) === 'article')>مقاله</option></select>@error('parent_type')<small class="field-error">{{ $message }}</small>@enderror</div>
                <div class="admin-field"><label for="parent_id">محتوای مادر</label><select id="parent_id" name="parent_id"><option value="">انتخاب محتوا</option>@foreach ($parents as $parent)<option value="{{ $parent->id }}" @selected((string) old('parent_id', $item->parent_id) === (string) $parent->id)>{{ config('content.types.'.$parent->type) }}: {{ $parent->title }}</option>@endforeach</select>@error('parent_id')<small class="field-error">{{ $message }}</small>@enderror</div>
            @endif

            @if ($hasExcerpt)
                <div class="admin-field admin-field--wide"><label for="excerpt">{{ $type === 'series' ? 'معرفی سلسله‌جلسات' : 'خلاصه' }}</label><textarea id="excerpt" name="excerpt" rows="3">{{ old('excerpt', $item->excerpt) }}</textarea>@error('excerpt')<small class="field-error">{{ $message }}</small>@enderror</div>
            @endif
            @if ($hasBody)
                <div class="admin-field admin-field--wide"><label for="body">{{ $type === 'note' ? 'متن فیش (یادداشت علمی)' : ($type === 'text' ? 'متن کامل جلسه' : 'متن') }}</label><textarea id="body" name="body" rows="12" required>{{ old('body', $item->body) }}</textarea>@error('body')<small class="field-error">{{ $message }}</small>@enderror</div>
            @endif
            @if (in_array($type, ['text', 'article'], true))
                <div class="admin-field"><label for="author">نویسنده</label><input id="author" name="author" maxlength="255" value="{{ old('author', $item->author) }}">@error('author')<small class="field-error">{{ $message }}</small>@enderror</div>
            @endif
            @if (in_array($type, ['series', 'article'], true))
                <div class="admin-field"><label for="category">دسته‌بندی</label><input id="category" name="category" maxlength="120" value="{{ old('category', $item->category) }}">@error('category')<small class="field-error">{{ $message }}</small>@enderror</div>
            @endif

            <fieldset class="admin-field admin-field--wide"><legend>برچسب‌ها</legend>
                <div class="tag-picker" data-tag-picker data-search-url="{{ route('admin.tags.search') }}" data-suggestion-url="{{ route('admin.tag-suggestions.store') }}" data-csrf="{{ csrf_token() }}">
                    <label for="tag-search">جست‌وجوی تگ</label>
                    <input id="tag-search" type="search" data-tag-query autocomplete="off" aria-controls="tag-search-results" aria-autocomplete="list" placeholder="نام تگ را تایپ کنید">
                    <div class="tag-picker-results" id="tag-search-results" data-tag-results role="listbox" hidden></div>
                    <div class="admin-tag-options tag-picker-selected" data-tag-selected aria-label="تگ‌های انتخاب‌شده">
                        @foreach ($selectedTags as $tag)
                            <span class="tag-picker-chip" data-selected-tag data-tag-id="{{ $tag->id }}"><input type="hidden" name="tag_ids[]" value="{{ $tag->id }}"><span>{{ $tag->name }}</span><button type="button" data-tag-remove aria-label="حذف {{ $tag->name }}">×</button></span>
                        @endforeach
                        @foreach ($selectedTagSuggestions as $suggestion)
                            <span class="tag-picker-chip tag-picker-chip--pending" data-selected-tag data-suggestion-id="{{ $suggestion->id }}"><input type="hidden" name="tag_suggestion_ids[]" value="{{ $suggestion->id }}"><span>{{ $suggestion->name }} · در انتظار تأیید</span><button type="button" data-tag-remove aria-label="حذف پیشنهاد {{ $suggestion->name }}">×</button></span>
                        @endforeach
                    </div>
                    <p class="tag-picker-message" data-tag-message aria-live="polite"></p>
                    <input type="hidden" name="tag_ids_present" value="1">
                    <input type="hidden" name="tag_suggestions_present" value="1">
                    <a href="{{ route('admin.tags.create') }}" target="_blank" rel="noopener">ساخت تگ تأییدشده</a>
                </div>
                @error('tag_ids')<small class="field-error">{{ $message }}</small>@enderror
            </fieldset>

            @if ($hasMedia)
                <fieldset class="admin-field admin-field--wide"><legend>{{ $type === 'session' ? 'فایل صوتی جلسه' : ($type === 'gallery' ? 'تصویر نگارخانه' : 'رسانهٔ مطلب (اختیاری)') }}</legend>
                    @if ($item->media_path)<p>فایل فعلی: <a href="{{ route('media.show', $item) }}">مشاهدهٔ فایل</a></p><label><input type="checkbox" name="remove_media" value="1"> حذف فایل فعلی</label>@endif
                    @if (in_array($type, ['session', 'gallery'], true))
                        <input type="hidden" name="media_kind" value="{{ $mediaKind }}">
                    @else
                        <label for="media_kind">نوع رسانه</label><select id="media_kind" name="media_kind"><option value="">انتخاب نوع</option><option value="image" @selected(old('media_kind', $mediaKind) === 'image')>تصویر</option><option value="audio" @selected(old('media_kind', $mediaKind) === 'audio')>صوت</option></select>@error('media_kind')<small class="field-error">{{ $message }}</small>@enderror
                    @endif
                    <label for="media">{{ $mediaKind === 'audio' ? 'فایل صوتی (حداکثر ۵۰ مگابایت)' : 'فایل تصویر یا صوت (تصویر حداکثر ۵ مگابایت؛ صوت حداکثر ۵۰ مگابایت)' }}</label>
                    <input id="media" name="media" type="file" accept="{{ $mediaKind === 'audio' ? 'audio/mpeg,audio/wav,audio/mp4' : ($mediaKind === 'image' ? 'image/jpeg,image/png,image/webp' : 'image/jpeg,image/png,image/webp,audio/mpeg,audio/wav,audio/mp4') }}">
                    @error('media')<small class="field-error">{{ $message }}</small>@enderror
                    @if ($type === 'gallery' || $item->media_kind === 'image')
                        <label for="media_alt">توضیح تصویر</label><input id="media_alt" name="media_alt" maxlength="255" value="{{ old('media_alt', $item->media_alt) }}">@error('media_alt')<small class="field-error">{{ $message }}</small>@enderror
                    @endif
                </fieldset>
            @endif

            <div class="admin-field"><label for="status">وضعیت انتشار</label><select id="status" name="status" required><option value="draft" @selected(old('status', $item->status ?: 'draft') === 'draft')>پیش‌نویس</option><option value="published" @selected(old('status', $item->status) === 'published')>انتشار</option></select>@error('status')<small class="field-error">{{ $message }}</small>@enderror</div>
            <div class="admin-form-actions"><button class="button button-primary" type="submit">ذخیرهٔ {{ $typeLabel }}</button><a class="button button-secondary" href="{{ route('admin.content.index') }}">بازگشت</a></div>
        </form>
        @if (in_array($type, ['session', 'series'], true))
            <dialog class="admin-modal" data-reference-dialog="place" aria-labelledby="place-dialog-title">
                <div class="admin-modal-content"><div class="admin-modal-heading"><h2 id="place-dialog-title">ثبت مکان جدید</h2><button class="button button-secondary" type="button" data-reference-close aria-label="بستن">بستن</button></div>
                    <form method="POST" action="{{ route('admin.places.quick-store') }}" data-reference-form>
                        @csrf
                        <div class="admin-field"><label for="quick-place-name">نام فارسی</label><input id="quick-place-name" name="name" required maxlength="255" autocomplete="off"><small data-reference-field-error="name" class="field-error" hidden></small></div>
                        <div class="admin-field"><label for="quick-place-code">کد انگلیسی کوتاه</label><input id="quick-place-code" name="code" dir="ltr" required maxlength="40" pattern="[a-z0-9]+(-[a-z0-9]+)*" placeholder="ans"><small data-reference-field-error="code" class="field-error" hidden></small></div>
                        <p class="admin-modal-error" data-reference-error role="alert" hidden></p>
                        <button class="button button-primary" type="submit">ذخیره و انتخاب مکان</button>
                    </form>
                </div>
            </dialog>
        @endif
        @if ($type === 'session')
            <dialog class="admin-modal" data-reference-dialog="occasion" aria-labelledby="occasion-dialog-title">
                <div class="admin-modal-content"><div class="admin-modal-heading"><h2 id="occasion-dialog-title">ثبت مناسبت جدید</h2><button class="button button-secondary" type="button" data-reference-close aria-label="بستن">بستن</button></div>
                    <form method="POST" action="{{ route('admin.occasions.quick-store') }}" data-reference-form>
                        @csrf
                        <div class="admin-field"><label for="quick-occasion-name">نام فارسی مناسبت</label><input id="quick-occasion-name" name="name" required maxlength="255" autocomplete="off"><small data-reference-field-error="name" class="field-error" hidden></small></div>
                        <div class="admin-field"><label for="quick-occasion-code">کد انگلیسی (اختیاری)</label><input id="quick-occasion-code" name="code" dir="ltr" maxlength="40" pattern="[a-z0-9]+(-[a-z0-9]+)*" placeholder="moharram"><small data-reference-field-error="code" class="field-error" hidden></small><small>اگر خالی باشد از نام مناسبت ساخته می‌شود.</small></div>
                        <p class="admin-modal-error" data-reference-error role="alert" hidden></p>
                        <button class="button button-primary" type="submit">ذخیره و انتخاب مناسبت</button>
                    </form>
                </div>
            </dialog>
        @endif
    </section>
@endsection