@extends('layouts.app', ['title' => 'مدیریت محتوا'])

@section('content')
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">فضای خصوصی / مدیریت</p><h1>محتوا</h1><p class="archive-description">پیش‌نویس‌ها، موارد منتشرشده و بایگانی؛ حذف دائمی در این پنل انجام نمی‌شود.</p></div><a class="button button-primary" href="{{ route('admin.content.create') }}">محتوای تازه</a></div></header>
    <section class="container admin-page">
        @include('admin.partials.navigation')
        @include('admin.partials.flash')
        <nav class="admin-actions" aria-label="ایجاد محتوای جدید">
            @foreach (config('content.types') as $type => $label)
                <a class="button button-secondary" href="{{ route('admin.content.create', ['type' => $type]) }}">ایجاد {{ $label }} جدید</a>
            @endforeach
        </nav>
        <form class="admin-filters" method="GET">
            <label>نوع محتوا<select name="type"><option value="">همهٔ انواع</option>@foreach (config('content.types') as $value => $label)<option value="{{ $value }}" @selected(request('type') === $value)>{{ $label }}</option>@endforeach</select></label>
            <label>وضعیت<select name="status"><option value="">همهٔ وضعیت‌ها</option>@foreach (config('content.statuses') as $value => $label)<option value="{{ $value }}" @selected(request('status') === $value)>{{ $label }}</option>@endforeach</select></label>
            <button class="button button-secondary" type="submit">اعمال</button>
        </form>
        <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>عنوان</th><th>نوع</th><th>وضعیت</th><th>برچسب‌ها</th><th>تغییر</th><th>عملیات</th></tr></thead><tbody>
            @forelse ($items as $item)
                <tr>
                    <td><a href="{{ route('admin.content.edit', $item) }}">{{ $item->title }}</a><small dir="ltr">{{ $item->slug }}</small></td>
                    <td>{{ config('content.types.'.$item->type) }}</td>
                    <td><span class="admin-status admin-status--{{ $item->status }}">{{ config('content.statuses.'.$item->status) }}</span></td>
                    <td>{{ $item->tags->pluck('name')->join('، ') ?: '—' }}</td>
                    <td>{{ $item->updated_at->format('Y-m-d') }}</td>
                    <td class="admin-row-actions">
                        @if ($item->status === 'archived')
                            <form method="POST" action="{{ route('admin.content.restore', $item) }}">@csrf<button class="text-link-button" type="submit">بازگردانی به پیش‌نویس</button></form>
                        @else
                            <a href="{{ route('admin.content.edit', $item) }}">ویرایش</a>
                            <form method="POST" action="{{ route('admin.content.archive', $item) }}">@csrf<button class="text-link-button" type="submit">بایگانی</button></form>
                        @endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="6">محتوایی ثبت نشده است.</td></tr>
            @endforelse
        </tbody></table></div>
        {{ $items->links() }}
    </section>
@endsection