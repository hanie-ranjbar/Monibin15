@extends('layouts.app', ['title' => 'انتخاب نوع محتوا'])

@section('content')
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">مدیریت / محتوا</p><h1>انتخاب نوع محتوا</h1><p class="archive-description">نوع محتوا را انتخاب کنید تا فرم متناسب باز شود.</p></div></div></header>
    <section class="container admin-page">
        @include('admin.partials.navigation')
        <nav class="admin-content-type-grid" aria-label="انواع محتوا">
            @foreach ($types as $type => $label)
                <a class="admin-content-type-link" href="{{ route('admin.content.create', ['type' => $type]) }}">
                    <span>{{ $label }}</span>
                    <span aria-hidden="true">←</span>
                </a>
            @endforeach
        </nav>
    </section>
@endsection