@extends('layouts.app', ['title' => 'مدیریت برچسب‌ها'])

@section('content')
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">فضای خصوصی / مدیریت</p><h1>برچسب‌ها</h1><p class="archive-description">برچسب‌ها را بایگانی کنید؛ پیوندهای محتوایی حذف نمی‌شوند.</p></div><div class="admin-actions">@can('manage-tag-suggestions')<a class="button button-secondary" href="{{ route('admin.tag-suggestions.index') }}">پیشنهادهای تگ</a>@endcan<a class="button button-primary" href="{{ route('admin.tags.create') }}">برچسب تازه</a></div></div></header>
    <section class="container admin-page">
        @include('admin.partials.navigation')
        @include('admin.partials.flash')
        @can('manage-tag-suggestions')
            @if ($activeTags->count() > 1)
                <form class="admin-filters" method="POST" action="{{ route('admin.tags.merge') }}">
                    @csrf
                    <label>ادغام مبدأ<select name="source_tag_id" required><option value="">انتخاب تگ</option>@foreach ($activeTags as $tagOption)<option value="{{ $tagOption->id }}">{{ $tagOption->name }}</option>@endforeach</select></label>
                    <label>تگ مقصد<select name="target_tag_id" required><option value="">انتخاب تگ مقصد</option>@foreach ($activeTags as $tagOption)<option value="{{ $tagOption->id }}">{{ $tagOption->name }}</option>@endforeach</select></label>
                    <button class="button button-secondary" type="submit">انتقال روابط و بایگانی مبدأ</button>
                    @error('target_tag_id')<small class="field-error">{{ $message }}</small>@enderror
                </form>
            @endif
        @endcan
        <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>نام</th><th>والدها</th><th>محتوای منتشرشده</th><th>وضعیت</th><th>عملیات</th></tr></thead><tbody>
            @forelse ($tags as $tag)
                <tr><td><a href="{{ route('admin.tags.edit', $tag) }}">{{ $tag->name }}</a><small dir="ltr">{{ $tag->slug }}</small></td><td>{{ $tag->parents->pluck('name')->join('، ') ?: '—' }}</td><td>{{ $tag->content_items_count }}</td><td>{{ $tag->archived_at ? 'بایگانی‌شده' : 'فعال' }}</td><td class="admin-row-actions">@if ($tag->archived_at)<form method="POST" action="{{ route('admin.tags.restore', $tag) }}">@csrf<button class="text-link-button" type="submit">بازیابی</button></form>@else<a href="{{ route('admin.tags.edit', $tag) }}">ویرایش</a><form method="POST" action="{{ route('admin.tags.archive', $tag) }}">@csrf<button class="text-link-button" type="submit">بایگانی</button></form>@endif</td></tr>
            @empty
                <tr><td colspan="5">برچسبی ثبت نشده است.</td></tr>
            @endforelse
        </tbody></table></div>
        {{ $tags->links() }}
    </section>
@endsection