@extends('layouts.app', ['title' => 'پیشنهادهای تگ'])

@section('content')
    <header class="archive-heading"><div class="container archive-heading-inner"><div><p class="eyebrow">مدیریت / تگ‌ها</p><h1>پیشنهادهای تگ</h1><p class="archive-description">پیشنهادها تا تأیید مالک در تگ‌های عمومی دیده نمی‌شوند.</p></div></div></header>
    <section class="container admin-page">
        @include('admin.partials.navigation')
        @include('admin.partials.flash')
        <div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>پیشنهاد</th><th>پیشنهاددهنده</th><th>وضعیت</th><th>بررسی</th></tr></thead><tbody>
            @forelse ($suggestions as $suggestion)
                <tr>
                    <td>
                        <form class="tag-suggestion-edit" method="POST" action="{{ route('admin.tag-suggestions.update', $suggestion) }}">
                            @csrf @method('PATCH')
                            <input name="name" value="{{ $suggestion->name }}" maxlength="120" required aria-label="نام تگ پیشنهادی">
                            <button class="text-link-button" type="submit">ذخیرهٔ ویرایش</button>
                        </form>
                    </td>
                    <td>{{ $suggestion->suggester?->name ?? 'حساب حذف‌شده' }}<small>{{ $suggestion->created_at->format('Y-m-d H:i') }}</small></td>
                    <td>{{ ['pending' => 'در انتظار بررسی', 'approved' => 'تأییدشده', 'merged' => 'ادغام‌شده', 'rejected' => 'ردشده'][$suggestion->status] ?? $suggestion->status }}<small>{{ $suggestion->content_items_count }} محتوای پیوندخورده</small></td>
                    <td class="admin-row-actions">
                        @if ($suggestion->status === 'pending')
                            <form method="POST" action="{{ route('admin.tag-suggestions.approve', $suggestion) }}">@csrf<button class="text-link-button" type="submit">تأیید</button></form>
                            <form method="POST" action="{{ route('admin.tag-suggestions.merge', $suggestion) }}">@csrf<label class="visually-hidden" for="merge-tag-{{ $suggestion->id }}">ادغام در تگ</label><select id="merge-tag-{{ $suggestion->id }}" name="target_tag_id" required><option value="">ادغام در تگ موجود</option>@foreach ($tags as $tag)<option value="{{ $tag->id }}">{{ $tag->name }}</option>@endforeach</select><button class="text-link-button" type="submit">ادغام</button></form>
                        @elseif ($suggestion->resolvedTag)
                            <span>تگ مقصد: {{ $suggestion->resolvedTag->name }}</span>
                        @endif
                        @if ($suggestion->content_items_count === 0)<form method="POST" action="{{ route('admin.tag-suggestions.destroy', $suggestion) }}">@csrf @method('DELETE')<button class="text-link-button" type="submit">حذف پیشنهاد</button></form>@else<span>برای حفظ پیوندها ابتدا تأیید یا ادغام کنید.</span>@endif
                    </td>
                </tr>
            @empty
                <tr><td colspan="4">پیشنهادی ثبت نشده است.</td></tr>
            @endforelse
        </tbody></table></div>
        {{ $suggestions->links() }}
    </section>
@endsection