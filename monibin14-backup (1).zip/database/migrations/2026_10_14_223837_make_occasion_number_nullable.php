<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('occasions', function (Blueprint $table) {
            $table->dropUnique('occasions_number_unique');
            $table->string('number', 10)->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (DB::table('occasions')->whereNull('number')->exists()) {
            throw new RuntimeException('Cannot make occasion numbers required while numberless occasions exist.');
        }

        Schema::table('occasions', function (Blueprint $table) {
            $table->string('number', 10)->nullable(false)->change();
            $table->unique('number');
        });
    }
};
