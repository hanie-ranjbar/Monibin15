<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('content_item_tag_suggestion', function (Blueprint $table) {
            $table->foreignId('content_item_id')->constrained()->cascadeOnDelete();
            $table->foreignId('tag_suggestion_id')->constrained()->cascadeOnDelete();
            $table->primary(['content_item_id', 'tag_suggestion_id']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (Schema::hasTable('content_item_tag_suggestion') && DB::table('content_item_tag_suggestion')->exists()) {
            throw new RuntimeException('Cannot roll back while tag suggestions are linked to content.');
        }

        Schema::dropIfExists('content_item_tag_suggestion');
    }
};
