<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('content_items', function (Blueprint $table) {
            $table->string('solar_date', 10)->nullable()->after('occurred_at');
            $table->string('hijri_date', 10)->nullable()->after('solar_date');
            $table->unsignedSmallInteger('session_number')->nullable()->after('hijri_date');
            $table->foreignId('place_id')->nullable()->after('session_number')->constrained()->nullOnDelete();
            $table->foreignId('occasion_id')->nullable()->after('place_id')->constrained()->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('content_items', function (Blueprint $table) {
            $table->dropConstrainedForeignId('occasion_id');
            $table->dropConstrainedForeignId('place_id');
            $table->dropColumn(['solar_date', 'hijri_date', 'session_number']);
        });
    }
};
