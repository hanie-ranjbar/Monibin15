<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tags', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->timestamp('archived_at')->nullable();
            $table->timestamps();
        });

        Schema::create('content_item_tag', function (Blueprint $table) {
            $table->foreignId('content_item_id')->constrained()->cascadeOnDelete();
            $table->foreignId('tag_id')->constrained()->cascadeOnDelete();
            $table->primary(['content_item_id', 'tag_id']);
            $table->timestamps();
        });

        Schema::create('tag_hierarchies', function (Blueprint $table) {
            $table->foreignId('parent_id')->constrained('tags')->cascadeOnDelete();
            $table->foreignId('child_id')->constrained('tags')->cascadeOnDelete();
            $table->primary(['parent_id', 'child_id']);
            $table->index('child_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tag_hierarchies');
        Schema::dropIfExists('content_item_tag');
        Schema::dropIfExists('tags');
    }
};
