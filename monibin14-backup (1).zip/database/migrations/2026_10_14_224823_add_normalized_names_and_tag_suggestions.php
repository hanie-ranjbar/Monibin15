<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        $seenNames = [];
        $hasDuplicate = false;

        DB::table('tags')->select(['id', 'name'])->orderBy('id')->chunkById(500, function ($tags) use (&$seenNames, &$hasDuplicate): void {
            foreach ($tags as $tag) {
                $normalizedName = $this->normalizeName($tag->name);
                if (isset($seenNames[$normalizedName])) {
                    $hasDuplicate = true;

                    return;
                }

                $seenNames[$normalizedName] = true;
            }
        });

        if ($hasDuplicate) {
            throw new RuntimeException('Cannot add unique normalized tag names while equivalent tags exist; merge them first.');
        }

        Schema::table('tags', function (Blueprint $table): void {
            $table->string('normalized_name', 180)->nullable()->after('name');
        });

        DB::table('tags')->select(['id', 'name'])->orderBy('id')->chunkById(500, function ($tags): void {
            foreach ($tags as $tag) {
                DB::table('tags')->where('id', $tag->id)->update([
                    'normalized_name' => $this->normalizeName($tag->name),
                ]);
            }
        });

        Schema::table('tags', function (Blueprint $table): void {
            $table->string('normalized_name', 180)->nullable(false)->change();
            $table->unique('normalized_name');
        });
    }

    public function down(): void
    {
        if (DB::table('tag_suggestions')->exists()) {
            throw new RuntimeException('Cannot roll back while tag suggestions exist.');
        }

        Schema::table('tags', function (Blueprint $table): void {
            $table->dropUnique('tags_normalized_name_unique');
            $table->dropColumn('normalized_name');
        });
    }

    private function normalizeName(string $name): string
    {
        $name = strtr($name, ['ي' => 'ی', 'ى' => 'ی', 'ك' => 'ک', 'ـ' => '', '‌' => ' ']);
        $name = mb_strtolower($name, 'UTF-8');
        $name = preg_replace('/[\p{Mn}\p{Me}]+/u', '', $name) ?? $name;
        $name = preg_replace('/\s+/u', ' ', $name) ?? $name;

        return trim($name);
    }
};
