<?php

namespace Database\Factories;

use App\Models\TagSuggestion;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<TagSuggestion>
 */
class TagSuggestionFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => fake()->unique()->word(),
            'normalized_name' => fake()->unique()->word(),
            'status' => 'pending',
        ];
    }
}
