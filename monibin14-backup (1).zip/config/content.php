<?php

return [
    'types' => [
        'session' => 'جلسه',
        'series' => 'سلسله‌جلسه',
        'note' => 'فیش (یادداشت علمی)',
        'text' => 'متن جلسه',
        'article' => 'مقاله',
        'announcement' => 'اعلان',
        'about' => 'درباره استاد',
        'gallery' => 'تصویر نگارخانه',
    ],

    'statuses' => [
        'draft' => 'پیش‌نویس',
        'published' => 'منتشرشده',
        'archived' => 'بایگانی‌شده',
    ],
];
