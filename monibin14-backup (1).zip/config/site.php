<?php

return [
    'name' => env('SITE_NAME', 'منیبین'),
    'full_name' => env('SITE_FULL_NAME', 'پایگاه معارف استاد حامد رنجبر'),
    'tagline' => env('SITE_TAGLINE', 'آرشیو درس‌ها و سخنرانی‌های استاد حامد رنجبر'),
    'teacher' => env('SITE_TEACHER', 'استاد حامد رنجبر'),
    'logo_path' => env('SITE_LOGO_PATH'),
    'logo_mark' => env('SITE_LOGO_MARK', 'م'),
    'demo_content_enabled' => (bool) env('SITE_DEMO_CONTENT', false),

    'navigation' => [
        ['label' => 'خانه', 'route' => 'home'],
        ['label' => 'اعلانات', 'route' => 'announcements.index'],
        ['label' => 'جلسات', 'route' => 'sessions.index'],
        ['label' => 'فیش‌ها', 'route' => 'notes.index'],
        ['label' => 'متن‌ها', 'route' => 'texts.index'],
        ['label' => 'برچسب‌ها', 'route' => 'tags.index'],
        ['label' => 'نگارخانه', 'route' => 'gallery.index'],
        ['label' => 'سلسله‌جلسات', 'route' => 'series.index'],
        ['label' => 'درباره استاد', 'route' => 'about'],
    ],

    'home_sections' => [
        'announcements' => 'اعلانات تازه',
        'sessions' => 'آخرین جلسات',
        'notes' => 'تازه‌ترین فیش‌ها',
        'texts' => 'جدیدترین متن‌ها',
    ],

    'pages' => [
        'gallery' => [
            'title' => 'نگارخانه',
            'description' => 'تصاویر منتشرشده و پیوندهای آن‌ها به محتوای پایگاه.',
            'source' => 'gallery',
            'detail_route' => 'gallery.show',
        ],
        'tags' => [
            'title' => 'برچسب‌ها',
            'description' => 'موضوع‌های مرتبط با محتوا و پیوندهای والد و فرزند آن‌ها.',
            'source' => 'tags',
        ],
        'sessions' => [
            'title' => 'آرشیو جلسات',
            'description' => 'فهرست جلسات و سخنرانی‌ها، با پیوند به یادداشت‌ها و متن‌های مرتبط.',
            'source' => 'sessions',
            'detail_route' => 'sessions.show',
        ],
        'series' => [
            'title' => 'سلسله‌جلسات',
            'description' => 'مجموعه‌های موضوعی و دوره‌های پیوستهٔ استاد حامد رنجبر.',
            'source' => 'series',
            'detail_route' => 'series.show',
        ],
        'notes' => [
            'title' => 'فیش‌ها',
            'description' => 'فیش‌های علمی (یادداشت‌های پژوهشی) مرتبط با جلسه‌ها، برای مطالعه و مراجعهٔ دوباره.',
            'source' => 'notes',
            'detail_route' => 'notes.show',
        ],
        'texts' => [
            'title' => 'متن‌ها و مقاله‌ها',
            'description' => 'مقاله‌ها و متن کامل جلسه‌ها؛ در کنار هر متن، ارتباط آن با آرشیو درج خواهد شد.',
            'source' => 'texts',
            'detail_route' => 'texts.show',
        ],
        'announcements' => [
            'title' => 'اعلانات',
            'description' => 'خبرها و آگاهی‌های مرتبط با این پایگاه.',
            'source' => 'announcements',
            'detail_route' => 'announcements.show',
        ],
        'about' => [
            'title' => 'دربارهٔ استاد',
            'description' => 'این بخش برای معرفی استاد حامد رنجبر و ارائهٔ اطلاعات مستند دربارهٔ ایشان در نظر گرفته شده است.',
        ],
        'search' => [
            'title' => 'جست‌وجو',
            'description' => 'جست‌وجو میان عنوان، خلاصه و متن محتوای منتشرشده.',
        ],
    ],
];
