<?php

return [
    'proxies' => env(
        'TRUSTED_PROXIES',
        env('APP_ENV', 'production') === 'local' ? '127.0.0.1,::1' : null,
    ),
];
