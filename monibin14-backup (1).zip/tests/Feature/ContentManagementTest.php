<?php

namespace Tests\Feature;

use App\Models\ContentItem;
use App\Models\Occasion;
use App\Models\Place;
use App\Models\Tag;
use App\Models\TagSuggestion;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ContentManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_content_management_requires_an_authenticated_admin(): void
    {
        $this->get('/admin')->assertRedirect(route('login'));

        $reader = User::factory()->create();

        $this->actingAs($reader)->get('/admin')->assertForbidden();
        $this->actingAs($reader)->get('/admin/content/create?type=note')->assertForbidden();
        $this->actingAs($reader)->post('/admin/content', [])->assertForbidden();
    }

    public function test_admin_can_create_edit_publish_and_link_content_by_stable_ids(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $tag = Tag::factory()->create(['name' => 'اخلاق', 'slug' => 'ethics']);
        $place = Place::factory()->create(['name' => 'لاهیجان', 'code' => 'lahijan']);
        $occasion = Occasion::factory()->create(['name' => 'محرم', 'code' => 'moharram', 'number' => '02']);
        $this->actingAs($admin);

        $this->get('/admin')->assertOk()->assertSee('مدیریت محتوا');
        $this->get('/admin/content')
            ->assertOk()
            ->assertSee('<h1>محتوا</h1>', false)
            ->assertSee(route('admin.content.create', ['type' => 'session']), false)
            ->assertSee(route('admin.content.create', ['type' => 'note']), false)
            ->assertSee(route('admin.content.create', ['type' => 'gallery']), false);
        $this->get('/admin/content/create')
            ->assertOk()
            ->assertSee('انتخاب نوع محتوا');
        foreach (config('content.types') as $type => $label) {
            $this->get(route('admin.content.create', ['type' => $type]))
                ->assertOk()
                ->assertSee($label);
        }

        $this->get('/admin/content/create?type=session')
            ->assertOk()
            ->assertSee('ثبت جلسه تازه')
            ->assertSee('data-jdp', false)
            ->assertSee('name="place_id"', false)
            ->assertSee('name="occasion_id"', false)
            ->assertSee('data-reference-open="place"', false)
            ->assertSee('data-reference-open="occasion"', false)
            ->assertSee('data-reference-dialog="place"', false)
            ->assertSee('data-reference-dialog="occasion"', false)
            ->assertDontSee('name="slug"', false);
        $this->get('/admin/content/create?type=note')
            ->assertOk()
            ->assertSee('متن فیش (یادداشت علمی)')
            ->assertSee('محتوای مادر')
            ->assertDontSee('خلاصه')
            ->assertDontSee('name="slug"', false);
        $this->get('/admin/content/create?type=article')
            ->assertOk()
            ->assertSee('خلاصه')
            ->assertSee('نویسنده')
            ->assertSee('متن');
        $this->get('/admin/content/create?type=series')->assertOk()->assertSee('معرفی سلسله‌جلسات')->assertSee('مکان غالب');
        foreach (config('content.types') as $type => $label) {
            $this->get(route('admin.content.create', ['type' => $type]))
                ->assertOk()
                ->assertSee($label)
                ->assertDontSee('name="slug"', false);
        }
        $this->get('/admin/tags')->assertOk()->assertSee('اخلاق');
        $this->get('/admin/tags/create')->assertOk()->assertSee('ساخت برچسب');
        $this->get('/admin/tags/'.$tag->id.'/edit')->assertOk()->assertSee('ویرایش برچسب');

        $this->post('/admin/content', [
            'type' => 'series',
            'title' => 'اخلاق و خودشناسی',
            'status' => 'draft',
            'tag_ids' => [$tag->id],
        ])->assertRedirect();

        $series = ContentItem::query()->where('type', 'series')->where('title', 'اخلاق و خودشناسی')->firstOrFail();
        $seriesId = $series->id;

        $this->post('/admin/content', [
            'type' => 'session',
            'title' => 'درآمدی بر خودشناسی',
            'status' => 'draft',
            'series_id' => $seriesId,
            'solar_date' => '1405-07-20',
            'session_number' => '1',
            'place_id' => $place->id,
            'occasion_id' => $occasion->id,
            'tag_ids' => [$tag->id],
        ])->assertRedirect()->assertSessionHasNoErrors();

        $session = ContentItem::query()->where('slug', 'HajRanjbar-14050720-moharram-lahijan')->firstOrFail();
        $sessionId = $session->id;
        $this->assertDatabaseHas('content_items', [
            'id' => $sessionId,
            'solar_date' => '1405-07-20',
            'hijri_date' => '1448-05-01',
            'place_id' => $place->id,
            'occasion_id' => $occasion->id,
        ]);
        $this->assertSame('2026-10-12', $session->fresh()->occurred_at->toDateString());
        $this->get(route('admin.content.edit', $session))->assertOk()->assertSee($session->slug)->assertSee('تاریخ برگزاری شمسی');

        $this->post('/admin/content', [
            'type' => 'note',
            'title' => 'پرسش‌هایی دربارهٔ خودشناسی',
            'slug' => 'forged-browser-slug',
            'status' => 'published',
            'body' => 'این یادداشت به جلسه پیوند دارد.',
            'parent_type' => 'session',
            'parent_id' => $sessionId,
            'tag_ids' => [$tag->id],
        ])->assertRedirect();

        $note = ContentItem::query()->where('type', 'note')->where('title', 'پرسش‌هایی دربارهٔ خودشناسی')->firstOrFail();
        $noteId = $note->id;
        $this->assertDatabaseHas('content_items', ['id' => $noteId, 'parent_type' => 'session', 'parent_id' => $sessionId, 'status' => 'published']);
        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $noteId, 'tag_id' => $tag->id]);

        $this->put('/admin/content/'.$sessionId, [
            'type' => 'session',
            'title' => 'درآمدی بر خودشناسی (ویرایش‌شده)',
            'status' => 'published',
            'series_id' => $seriesId,
            'solar_date' => '1405-07-20',
            'place_id' => $place->id,
            'occasion_id' => $occasion->id,
            'tag_ids' => [$tag->id],
        ])->assertRedirect();

        $this->assertDatabaseHas('content_items', ['id' => $sessionId, 'title' => 'درآمدی بر خودشناسی (ویرایش‌شده)', 'series_id' => $seriesId]);
        $this->assertDatabaseHas('content_items', ['id' => $noteId, 'parent_id' => $sessionId]);
        $this->get(route('sessions.index'))
            ->assertOk()
            ->assertSee('۲۰ مهر ۱۴۰۵')
            ->assertSee('لاهیجان')
            ->assertSee('۱ فیش پیوندخورده')
            ->assertDontSee('�');
        $this->get(route('sessions.show', $session->slug))
            ->assertOk()
            ->assertSee('پرسش‌هایی دربارهٔ خودشناسی')
            ->assertSee('۲۰ مهر ۱۴۰۵')
            ->assertSee('لاهیجان')
            ->assertDontSee('جمادی‌الاول');
        $this->get(route('notes.show', $note->slug))->assertOk()->assertSee('درآمدی بر خودشناسی (ویرایش‌شده)');
        $this->get('/tags/ethics')->assertOk()->assertSee('درآمدی بر خودشناسی (ویرایش‌شده)')->assertSee('پرسش‌هایی دربارهٔ خودشناسی');
    }

    public function test_admin_content_slugs_are_generated_unique_and_stable_when_titles_change(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $place = Place::factory()->create(['name' => 'لاهیجان', 'code' => 'lahijan']);
        $occasion = Occasion::factory()->create(['name' => 'محرم', 'code' => 'moharram', 'number' => '02']);
        $this->actingAs($admin);

        $this->post('/admin/content', [
            'type' => 'session',
            'title' => 'Intro to Ethics',
            'status' => 'draft',
            'solar_date' => '1405-07-20',
            'session_number' => '1',
            'place_id' => $place->id,
            'occasion_id' => $occasion->id,
        ])->assertRedirect()->assertSessionHasNoErrors();

        $session = ContentItem::query()->where('slug', 'HajRanjbar-14050720-moharram-lahijan')->firstOrFail();

        $this->post('/admin/content', [
            'type' => 'note',
            'title' => 'Study Notes',
            'status' => 'draft',
            'body' => 'Study notes body',
            'parent_type' => 'session',
            'parent_id' => $session->id,
        ])->assertRedirect();

        $note = ContentItem::query()->where('slug', 'intro-to-ethics-study-notes')->firstOrFail();

        $this->post('/admin/content', [
            'type' => 'note',
            'title' => 'Study Notes',
            'status' => 'draft',
            'body' => 'Study notes body',
        ])->assertRedirect();

        $this->post('/admin/content', [
            'type' => 'note',
            'title' => 'Study Notes',
            'status' => 'draft',
            'body' => 'Study notes body',
        ])->assertRedirect();

        $duplicate = ContentItem::query()->where('slug', 'study-notes-2')->firstOrFail();

        $this->put('/admin/content/'.$note->id, [
            'type' => 'note',
            'title' => 'Revised Study Notes',
            'status' => 'draft',
            'body' => 'Revised notes body',
        ])->assertRedirect();

        $this->assertDatabaseHas('content_items', ['id' => $note->id, 'slug' => 'intro-to-ethics-study-notes']);
        $this->assertDatabaseHas('content_items', ['id' => $duplicate->id, 'slug' => 'study-notes-2']);
        $this->assertDatabaseHas('content_items', ['id' => $session->id, 'slug' => 'HajRanjbar-14050720-moharram-lahijan']);
    }

    public function test_admin_can_create_and_edit_every_configured_content_type(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $place = Place::factory()->create(['name' => 'مکان تست', 'code' => 'test-place']);
        $occasion = Occasion::factory()->create(['name' => 'مناسبت تست', 'code' => 'test-occasion']);
        $this->actingAs($admin);

        foreach (ContentItem::TYPES as $type) {
            $title = 'Form coverage '.$type;
            $payload = ['type' => $type, 'title' => $title, 'status' => 'draft'];

            if (in_array($type, ['note', 'text', 'article', 'announcement', 'about'], true)) {
                $payload['body'] = 'Content for '.$type;
            }

            if ($type === 'session') {
                $payload += ['solar_date' => '1405-07-20', 'place_id' => $place->id, 'occasion_id' => $occasion->id];
            }

            $this->post('/admin/content', $payload)->assertRedirect()->assertSessionHasNoErrors();
            $item = ContentItem::query()->where('type', $type)->where('title', $title)->firstOrFail();
            $this->get(route('admin.content.edit', $item))->assertOk()->assertSee(config('content.types.'.$type));
            $this->put('/admin/content/'.$item->id, $payload)->assertRedirect()->assertSessionHasNoErrors();
            $this->assertDatabaseHas('content_items', ['id' => $item->id, 'type' => $type, 'title' => $title]);
        }
    }

    public function test_session_dates_are_validated_and_hijri_confirmation_is_explicit(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $place = Place::factory()->create(['name' => 'لاهیجان', 'code' => 'lahijan']);
        $occasion = Occasion::factory()->create(['name' => 'محرم', 'code' => 'moharram', 'number' => '02']);
        $this->actingAs($admin);

        $sessionData = [
            'type' => 'session',
            'title' => 'Session Date Check',
            'status' => 'draft',
            'solar_date' => '1405-07-20',
            'place_id' => $place->id,
            'occasion_id' => $occasion->id,
        ];

        $this->post('/admin/content', [...$sessionData, 'solar_date' => '1405-13-01'])
            ->assertSessionHasErrors('solar_date');

        $this->post('/admin/content', [...$sessionData, 'solar_date' => '1600-01-01'])
            ->assertSessionHasErrors('solar_date');

        $this->post('/admin/content', [...$sessionData, 'hijri_date' => '1448-13-01'])
            ->assertSessionHasErrors('hijri_date');

        $this->post('/admin/content', $sessionData)->assertRedirect()->assertSessionHasNoErrors();
        $firstSession = ContentItem::query()->where('title', 'Session Date Check')->firstOrFail();
        $this->assertSame('HajRanjbar-14050720-moharram-lahijan', $firstSession->slug);
        $this->assertSame('1448-05-01', $firstSession->hijri_date);
        $this->assertNull($firstSession->hijri_date_confirmed_at);

        $this->post('/admin/content', [...$sessionData, 'hijri_date' => '1448-05-01', 'hijri_date_confirmed' => '1'])
            ->assertRedirect()
            ->assertSessionHasNoErrors();

        $secondSession = ContentItem::query()->where('title', 'Session Date Check')->latest('id')->firstOrFail();
        $this->assertSame('HajRanjbar-14050720-moharram-lahijan-2', $secondSession->slug);
        $this->assertNotNull($secondSession->hijri_date_confirmed_at);
        $this->assertSame('HajRanjbar-14050720-moharram-lahijan', $firstSession->fresh()->slug);

        $this->put('/admin/content/'.$secondSession->id, [
            'type' => 'session',
            'title' => 'Session Date Check',
            'status' => 'published',
            'solar_date' => '1405-07-20',
            'place_id' => $place->id,
            'occasion_id' => $occasion->id,
            'hijri_date' => '1448-05-01',
            'hijri_date_confirmed' => '1',
        ])->assertRedirect()->assertSessionHasNoErrors();

        $this->get(route('sessions.show', $secondSession->slug))
            ->assertOk()
            ->assertSee('۱ جمادی‌الاول ۱۴۴۸');
    }

    public function test_editing_non_session_content_preserves_legacy_event_date(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $article = ContentItem::factory()->create([
            'type' => 'article',
            'occurred_at' => '2020-01-15',
            'status' => 'draft',
        ]);

        $this->actingAs($admin)->put('/admin/content/'.$article->id, [
            'type' => 'article',
            'title' => $article->title,
            'body' => 'Updated article text',
            'status' => 'draft',
        ])->assertRedirect()->assertSessionHasNoErrors();

        $this->assertSame('2020-01-15', $article->fresh()->occurred_at->toDateString());
    }

    public function test_editing_text_content_keeps_existing_media_and_allows_replacement(): void
    {
        Storage::fake('local');
        $admin = User::factory()->create(['role' => 'admin']);
        $article = ContentItem::factory()->create([
            'type' => 'article',
            'status' => 'draft',
            'media_path' => 'content/1/cover.jpg',
            'media_kind' => 'image',
            'media_mime' => 'image/jpeg',
            'media_alt' => 'Cover image',
        ]);
        Storage::disk('local')->put($article->media_path, 'existing image');

        $this->actingAs($admin)->get(route('admin.content.edit', $article))
            ->assertOk()
            ->assertSee('name="media_kind"', false)
            ->assertSee('name="media"', false)
            ->assertSee('Cover image');

        $this->put('/admin/content/'.$article->id, [
            'type' => 'article',
            'title' => $article->title,
            'body' => 'Updated article body',
            'status' => 'draft',
        ])->assertRedirect()->assertSessionHasNoErrors();

        $this->assertSame('content/1/cover.jpg', $article->fresh()->media_path);
        Storage::disk('local')->assertExists('content/1/cover.jpg');
    }

    public function test_place_and_occasion_codes_are_admin_managed_and_immutable(): void
    {
        $reader = User::factory()->create();
        $this->actingAs($reader)->get('/admin/places')->assertForbidden();
        $this->actingAs($reader)->post('/admin/places', [])->assertForbidden();
        $this->actingAs($reader)->postJson('/admin/places/quick-store', [])->assertForbidden();
        $this->actingAs($reader)->postJson('/admin/occasions/quick-store', [])->assertForbidden();

        $admin = User::factory()->create(['role' => 'admin']);
        $this->actingAs($admin);

        $this->postJson('/admin/places/quick-store', ['name' => 'مکان پنجره‌ای', 'code' => 'async'])
            ->assertStatus(201)
            ->assertJsonPath('code', 'async');
        $this->assertDatabaseHas('places', ['name' => 'مکان پنجره‌ای', 'code' => 'async']);
        $this->postJson('/admin/places/quick-store', ['name' => 'مکان نامعتبر', 'code' => 'Bad Code'])
            ->assertStatus(422)
            ->assertJsonValidationErrors('code');

        $this->postJson('/admin/occasions/quick-store', ['name' => 'مناسبت پنجره‌ای'])
            ->assertStatus(201)
            ->assertJsonPath('name', 'مناسبت پنجره‌ای');
        $this->assertDatabaseHas('occasions', ['name' => 'مناسبت پنجره‌ای', 'number' => null]);
        $this->postJson('/admin/occasions/quick-store', ['name' => 'رمضان', 'code' => 'ramadan'])
            ->assertStatus(201)
            ->assertJsonPath('code', 'ramadan');

        $this->post('/admin/places', ['name' => 'هیئت انصارالحسین رشت', 'code' => 'ans'])->assertRedirect()->assertSessionHasNoErrors();
        $place = Place::query()->where('code', 'ans')->firstOrFail();
        $this->put('/admin/places/'.$place->id, ['name' => 'هیئت انصارالحسین رشت، سالن اصلی', 'code' => 'changed'])
            ->assertRedirect()
            ->assertSessionHasNoErrors();
        $this->assertSame('ans', $place->fresh()->code);

        $this->post('/admin/occasions', ['name' => 'محرم'])
            ->assertRedirect()
            ->assertSessionHasNoErrors();
        $occasion = Occasion::query()->where('name', 'محرم')->firstOrFail();
        $this->assertNotSame('', $occasion->code);
        $this->assertNull($occasion->number);

        $legacyOccasion = Occasion::factory()->create(['number' => '02']);
        $this->put('/admin/occasions/'.$legacyOccasion->id, ['name' => 'ماه محرم', 'code' => 'changed', 'number' => '99'])
            ->assertRedirect()
            ->assertSessionHasNoErrors();
        $this->assertSame($legacyOccasion->code, $legacyOccasion->fresh()->code);
        $this->assertSame('02', $legacyOccasion->fresh()->number);
    }

    public function test_tag_suggestions_stay_private_and_owner_can_approve_edit_merge_or_delete(): void
    {
        $manager = User::factory()->create(['role' => 'manager']);
        $reader = User::factory()->create(['role' => 'reader']);
        $owner = User::factory()->create(['role' => 'admin']);
        $existingTag = Tag::factory()->create(['name' => 'آموزش', 'slug' => 'education']);
        $article = ContentItem::factory()->create(['type' => 'article', 'status' => 'draft']);

        $this->actingAs($reader)->postJson('/admin/tag-suggestions', ['name' => 'اندیشه'])->assertForbidden();

        $this->actingAs($manager)->get('/admin/tag-suggestions')->assertForbidden();
        $this->get('/admin/content/'.$article->id.'/edit')
            ->assertOk()
            ->assertSee('data-tag-picker', false)
            ->assertSee('جست‌وجوی تگ');

        $this->getJson('/admin/tags/search?q=ایمان')->assertOk();
        $searchResponse = $this->getJson('/admin/tags/search?q=آموزش');
        $searchResponse->assertOk()->assertJsonPath('tags.0.id', $existingTag->id);

        $firstResponse = $this->postJson('/admin/tag-suggestions', ['name' => 'اندیشه']);
        $firstResponse->assertStatus(202)->assertJsonPath('status', 'pending');
        $firstSuggestion = TagSuggestion::query()->findOrFail($firstResponse->json('id'));
        $duplicateSuggestionResponse = $this->postJson('/admin/tag-suggestions', ['name' => 'انديشه']);
        $duplicateSuggestionResponse->assertStatus(202)->assertJsonPath('id', $firstSuggestion->id);
        $this->assertSame(1, TagSuggestion::query()->where('normalized_name', $firstSuggestion->normalized_name)->count());
        $this->assertDatabaseMissing('tags', ['normalized_name' => $firstSuggestion->normalized_name]);
        $this->get('/tags')->assertOk()->assertDontSee('اندیشه');

        $this->actingAs($manager)->post('/admin/tag-suggestions/'.$firstSuggestion->id.'/approve')->assertForbidden();
        $this->patch('/admin/tag-suggestions/'.$firstSuggestion->id, ['name' => 'manager edit'])->assertForbidden();
        $this->post('/admin/tag-suggestions/'.$firstSuggestion->id.'/merge', ['target_tag_id' => $existingTag->id])->assertForbidden();
        $this->delete('/admin/tag-suggestions/'.$firstSuggestion->id)->assertForbidden();
        $this->put('/admin/content/'.$article->id, [
            'type' => 'article',
            'title' => $article->title,
            'body' => 'Article content',
            'status' => 'draft',
            'tag_ids_present' => '1',
            'tag_suggestions_present' => '1',
            'tag_suggestion_ids' => [$firstSuggestion->id],
        ])->assertRedirect()->assertSessionHasNoErrors();
        $this->assertDatabaseHas('content_item_tag_suggestion', ['content_item_id' => $article->id, 'tag_suggestion_id' => $firstSuggestion->id]);

        $secondResponse = $this->postJson('/admin/tag-suggestions', ['name' => 'خردورزی']);
        $secondResponse->assertStatus(202);
        $secondSuggestion = TagSuggestion::query()->findOrFail($secondResponse->json('id'));
        $this->put('/admin/content/'.$article->id, [
            'type' => 'article',
            'title' => $article->title,
            'body' => 'Article content',
            'status' => 'draft',
            'tag_ids_present' => '1',
            'tag_suggestions_present' => '1',
            'tag_suggestion_ids' => [$firstSuggestion->id, $secondSuggestion->id],
        ])->assertRedirect()->assertSessionHasNoErrors();

        $this->actingAs($owner)->get('/admin/tag-suggestions')->assertOk()->assertSee('اندیشه')->assertSee('خردورزی');
        $this->delete('/admin/tag-suggestions/'.$secondSuggestion->id)->assertSessionHasErrors('suggestion');
        $this->assertDatabaseHas('content_item_tag_suggestion', ['content_item_id' => $article->id, 'tag_suggestion_id' => $secondSuggestion->id]);
        $this->patch('/admin/tag-suggestions/'.$firstSuggestion->id, ['name' => 'اندیشهٔ دقیق'])
            ->assertRedirect()
            ->assertSessionHasNoErrors();
        $this->post('/admin/tag-suggestions/'.$firstSuggestion->id.'/merge', ['target_tag_id' => $existingTag->id])
            ->assertRedirect()
            ->assertSessionHasNoErrors();

        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $article->id, 'tag_id' => $existingTag->id]);
        $this->assertDatabaseMissing('content_item_tag_suggestion', ['content_item_id' => $article->id, 'tag_suggestion_id' => $firstSuggestion->id]);

        $this->post('/admin/tag-suggestions/'.$secondSuggestion->id.'/approve')->assertRedirect()->assertSessionHasNoErrors();
        $approvedTag = Tag::query()->where('normalized_name', 'خردورزی')->firstOrFail();
        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $article->id, 'tag_id' => $approvedTag->id]);
        $this->get('/tags')->assertOk()->assertSee('خردورزی');

        $deleteResponse = $this->postJson('/admin/tag-suggestions', ['name' => 'پیشنهاد قابل حذف']);
        $deleteSuggestion = TagSuggestion::query()->findOrFail($deleteResponse->json('id'));
        $this->delete('/admin/tag-suggestions/'.$deleteSuggestion->id)->assertRedirect();
        $this->assertDatabaseMissing('tag_suggestions', ['id' => $deleteSuggestion->id]);
    }

    public function test_drafts_are_private_and_archive_restore_preserves_content_and_tag_links(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $tag = Tag::factory()->create();
        $item = ContentItem::factory()->create([
            'type' => 'article',
            'slug' => 'private-draft',
            'status' => 'draft',
            'published_at' => null,
        ]);
        $item->tags()->attach($tag);

        $this->get('/texts/private-draft')->assertNotFound();
        $this->actingAs($admin)->get('/admin/content/'.$item->id.'/edit')->assertOk()->assertSee('private-draft');

        $this->post('/admin/content/'.$item->id.'/archive')->assertRedirect(route('admin.content.index'));
        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $item->id, 'tag_id' => $tag->id]);
        $this->get('/texts/private-draft')->assertNotFound();

        $this->post('/admin/content/'.$item->id.'/restore')->assertRedirect(route('admin.content.edit', $item));
        $this->assertDatabaseHas('content_items', ['id' => $item->id, 'status' => 'draft', 'archived_at' => null]);
    }

    public function test_tag_parents_cannot_form_cycles_and_archiving_keeps_links(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $parent = Tag::factory()->create(['name' => 'اندیشه', 'slug' => 'thought']);
        $secondParent = Tag::factory()->create(['name' => 'خواندن', 'slug' => 'reading']);
        $child = Tag::factory()->create(['name' => 'اخلاق', 'slug' => 'ethics']);
        $child->parents()->sync([$parent->id, $secondParent->id]);
        $item = ContentItem::factory()->create([
            'type' => 'article',
            'slug' => 'ethics-article',
            'status' => 'published',
            'published_at' => now(),
        ]);
        $item->tags()->attach($child);

        $this->actingAs($admin)->post('/admin/tags', [
            'name' => 'مطالعهٔ دقیق',
            'slug' => 'close-reading',
            'description' => 'تعریف برچسب.',
            'parent_ids' => [$parent->id, $secondParent->id],
        ])->assertRedirect();

        $createdTag = Tag::query()->where('slug', 'close-reading')->firstOrFail();
        $this->assertDatabaseHas('tag_hierarchies', ['parent_id' => $parent->id, 'child_id' => $createdTag->id]);
        $this->assertDatabaseHas('tag_hierarchies', ['parent_id' => $secondParent->id, 'child_id' => $createdTag->id]);

        $this->actingAs($admin)->put('/admin/tags/'.$parent->id, [
            'name' => 'اندیشه',
            'slug' => 'thought',
            'parent_ids' => [$child->id],
        ])->assertSessionHasErrors('parent_ids');

        $this->post('/admin/tags/'.$child->id.'/archive')->assertRedirect(route('admin.tags.index'));
        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $item->id, 'tag_id' => $child->id]);
        $this->get('/tags/ethics')->assertNotFound();

        $this->post('/admin/tags/'.$child->id.'/restore')->assertRedirect(route('admin.tags.edit', $child));
        $this->get('/tags/ethics')->assertOk()->assertSee('ethics-article')->assertSee('اندیشه')->assertSee('خواندن');
    }

    public function test_tag_suggestions_are_private_until_owner_approval_and_owner_can_review_them(): void
    {
        $manager = User::factory()->create(['role' => 'manager']);
        $reader = User::factory()->create(['role' => 'reader']);
        $owner = User::factory()->create(['role' => 'admin']);
        $existingTag = Tag::factory()->create(['name' => 'آموزش', 'slug' => 'education']);
        $article = ContentItem::factory()->create(['type' => 'article', 'status' => 'draft']);

        $this->actingAs($reader)->postJson('/admin/tag-suggestions', ['name' => 'اندیشه'])->assertForbidden();

        $this->actingAs($manager)->get('/admin/tag-suggestions')->assertForbidden();

        $suggestionResponse = $this->actingAs($manager)->postJson('/admin/tag-suggestions', ['name' => 'اندیشه']);
        $suggestionResponse->assertStatus(202)->assertJsonPath('status', 'pending');
        $suggestionId = $suggestionResponse->json('id');
        $suggestion = TagSuggestion::query()->findOrFail($suggestionId);
        $this->actingAs($manager)->post('/admin/tag-suggestions/'.$suggestionId.'/approve')->assertForbidden();

        $this->put('/admin/content/'.$article->id, [
            'type' => 'article',
            'title' => $article->title,
            'body' => 'Article content',
            'status' => 'draft',
            'tag_ids_present' => '1',
            'tag_suggestions_present' => '1',
            'tag_suggestion_ids' => [$suggestion->id],
        ])->assertRedirect()->assertSessionHasNoErrors();

        $this->assertDatabaseHas('content_item_tag_suggestion', ['content_item_id' => $article->id, 'tag_suggestion_id' => $suggestion->id]);
        $this->assertDatabaseMissing('tags', ['normalized_name' => 'اندیشه']);
        $this->get('/tags')->assertOk()->assertDontSee('اندیشه');

        $secondResponse = $this->postJson('/admin/tag-suggestions', ['name' => 'خردورزی']);
        $secondResponse->assertStatus(202);
        $secondSuggestion = TagSuggestion::query()->findOrFail($secondResponse->json('id'));
        $this->put('/admin/content/'.$article->id, [
            'type' => 'article',
            'title' => $article->title,
            'body' => 'Article content',
            'status' => 'draft',
            'tag_ids_present' => '1',
            'tag_suggestions_present' => '1',
            'tag_suggestion_ids' => [$suggestion->id, $secondSuggestion->id],
        ])->assertRedirect()->assertSessionHasNoErrors();

        $this->actingAs($owner)->get('/admin/tag-suggestions')->assertOk()->assertSee('اندیشه')->assertSee('خردورزی');
        $this->patch('/admin/tag-suggestions/'.$suggestion->id, ['name' => 'اندیشهٔ دقیق'])
            ->assertRedirect()
            ->assertSessionHasNoErrors();
        $this->post('/admin/tag-suggestions/'.$suggestion->id.'/merge', ['target_tag_id' => $existingTag->id])
            ->assertRedirect()
            ->assertSessionHasNoErrors();

        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $article->id, 'tag_id' => $existingTag->id]);
        $this->assertDatabaseMissing('content_item_tag_suggestion', ['content_item_id' => $article->id, 'tag_suggestion_id' => $suggestion->id]);
        $this->assertDatabaseHas('tag_suggestions', ['id' => $suggestion->id, 'status' => 'merged', 'resolved_tag_id' => $existingTag->id]);

        $this->post('/admin/tag-suggestions/'.$secondSuggestion->id.'/approve')->assertRedirect()->assertSessionHasNoErrors();
        $approvedTag = Tag::query()->where('normalized_name', 'خردورزی')->firstOrFail();
        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $article->id, 'tag_id' => $approvedTag->id]);
        $this->get('/tags')->assertOk()->assertSee('خردورزی');

        $deleteResponse = $this->postJson('/admin/tag-suggestions', ['name' => 'تگ قابل حذف']);
        $deleteSuggestion = TagSuggestion::query()->findOrFail($deleteResponse->json('id'));
        $this->delete('/admin/tag-suggestions/'.$deleteSuggestion->id)->assertRedirect();
        $this->assertDatabaseMissing('tag_suggestions', ['id' => $deleteSuggestion->id]);
    }

    public function test_tag_search_normalizes_persian_variants_and_owner_merge_preserves_relations(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $manager = User::factory()->create(['role' => 'manager']);
        $source = Tag::factory()->create(['name' => 'كلام', 'slug' => 'source-speech']);
        $target = Tag::factory()->create(['name' => 'گفتار', 'slug' => 'target-speech']);
        $parent = Tag::factory()->create(['name' => 'دانش', 'slug' => 'knowledge']);
        $child = Tag::factory()->create(['name' => 'آموزش', 'slug' => 'instruction']);
        $source->parents()->sync([$parent->id]);
        $source->children()->sync([$child->id]);
        $article = ContentItem::factory()->create(['type' => 'article', 'status' => 'published', 'published_at' => now()]);
        $article->tags()->attach($source);

        $this->actingAs($manager)->getJson('/admin/tags/search?q=کلام')->assertOk()->assertJsonPath('tags.0.name', 'كلام');
        $this->actingAs($manager)->post('/admin/tags/merge', ['source_tag_id' => $source->id, 'target_tag_id' => $target->id])->assertForbidden();

        $this->actingAs($admin)->post('/admin/tags/merge', ['source_tag_id' => $source->id, 'target_tag_id' => $target->id])
            ->assertRedirect()
            ->assertSessionHasNoErrors();

        $this->assertDatabaseHas('content_item_tag', ['content_item_id' => $article->id, 'tag_id' => $target->id]);
        $this->assertDatabaseMissing('content_item_tag', ['content_item_id' => $article->id, 'tag_id' => $source->id]);
        $this->assertDatabaseHas('tag_hierarchies', ['parent_id' => $parent->id, 'child_id' => $target->id]);
        $this->assertDatabaseHas('tag_hierarchies', ['parent_id' => $target->id, 'child_id' => $child->id]);
        $this->assertNotNull($source->fresh()->archived_at);
    }

    public function test_tag_search_and_manual_tag_creation_reject_normalized_duplicates(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);
        $existingTag = Tag::factory()->create(['name' => 'کلام', 'slug' => 'kalam']);
        $this->actingAs($admin);

        $this->getJson('/admin/tags/search?q=كلام')
            ->assertOk()
            ->assertJsonPath('tags.0.id', $existingTag->id)
            ->assertJsonPath('tags.0.exact', true)
            ->assertJsonPath('can_suggest', false);

        $this->post('/admin/tags', ['name' => 'كلام', 'slug' => 'kalam-duplicate'])
            ->assertSessionHasErrors('name');
        $this->assertDatabaseMissing('tags', ['slug' => 'kalam-duplicate']);
    }

    public function test_owner_tag_merge_rejects_cycles_without_changing_any_relationships(): void
    {
        $owner = User::factory()->create(['role' => 'admin']);
        $source = Tag::factory()->create(['name' => 'مبدأ', 'slug' => 'merge-source']);
        $target = Tag::factory()->create(['name' => 'مقصد', 'slug' => 'merge-target']);
        $descendant = Tag::factory()->create(['name' => 'فرزند', 'slug' => 'merge-descendant']);
        $source->children()->sync([$descendant->id]);
        $descendant->children()->sync([$target->id]);

        $this->actingAs($owner)->post('/admin/tags/merge', ['source_tag_id' => $source->id, 'target_tag_id' => $target->id])
            ->assertSessionHasErrors('target_tag_id');

        $this->assertDatabaseHas('tag_hierarchies', ['parent_id' => $source->id, 'child_id' => $descendant->id]);
        $this->assertDatabaseHas('tag_hierarchies', ['parent_id' => $descendant->id, 'child_id' => $target->id]);
        $this->assertDatabaseMissing('tag_hierarchies', ['parent_id' => $target->id, 'child_id' => $descendant->id]);
        $this->assertNull($source->fresh()->archived_at);
    }

    public function test_search_normalizes_common_arabic_and_persian_letter_variants(): void
    {
        ContentItem::factory()->create([
            'type' => 'text',
            'title' => 'حکمت و تربیت',
            'slug' => 'wisdom-and-upbringing',
            'status' => 'published',
            'published_at' => now(),
        ]);

        $this->get('/search?q=حكمت')
            ->assertOk()
            ->assertSee('حکمت و تربیت');

        $this->get('/search?q=تربيت')
            ->assertOk()
            ->assertSee('حکمت و تربیت');
    }

    public function test_private_media_is_not_available_until_content_is_published(): void
    {
        Storage::fake('local');
        $item = ContentItem::factory()->create([
            'type' => 'gallery',
            'status' => 'draft',
            'media_path' => 'content/1/poster.jpg',
            'media_kind' => 'image',
            'media_mime' => 'image/jpeg',
        ]);
        Storage::disk('local')->put($item->media_path, 'test image data');

        $this->get('/media/'.$item->id)->assertNotFound();

        $item->forceFill(['status' => 'published', 'published_at' => now()])->save();

        $this->get('/media/'.$item->id)
            ->assertOk()
            ->assertHeader('content-type', 'image/jpeg')
            ->assertHeader('x-content-type-options', 'nosniff');
    }

    public function test_session_detail_uses_its_audio_file_and_omits_player_when_none_exists(): void
    {
        Storage::fake('local');
        $audioSession = ContentItem::factory()->create([
            'type' => 'session',
            'slug' => 'audio-session',
            'status' => 'published',
            'published_at' => now(),
            'media_path' => 'content/1/audio.mp3',
            'media_kind' => 'audio',
            'media_mime' => 'audio/mpeg',
        ]);
        Storage::disk('local')->put($audioSession->media_path, 'fake audio bytes');
        $silentSession = ContentItem::factory()->create([
            'type' => 'session',
            'slug' => 'silent-session',
            'status' => 'published',
            'published_at' => now(),
        ]);

        $this->get(route('sessions.show', $audioSession->slug))
            ->assertOk()
            ->assertSee('<audio controls', false)
            ->assertSee(route('media.show', $audioSession), false)
            ->assertSee('audio/mpeg');
        $this->get(route('sessions.show', $silentSession->slug))
            ->assertOk()
            ->assertDontSee('<audio', false);
    }

    public function test_published_about_content_is_shown_on_the_about_page(): void
    {
        ContentItem::factory()->create([
            'type' => 'about',
            'title' => 'درباره استاد',
            'slug' => 'about',
            'body' => 'زندگی‌نامهٔ بررسی‌شده.',
            'status' => 'published',
            'published_at' => now(),
        ]);

        $this->get('/about')->assertOk()->assertSee('زندگی‌نامهٔ بررسی‌شده.');
    }

    public function test_admin_upload_rejects_active_or_unsupported_image_formats(): void
    {
        $admin = User::factory()->create(['role' => 'admin']);

        $this->actingAs($admin)->post('/admin/content', [
            'type' => 'gallery',
            'title' => 'تصویر آزمایشی',
            'slug' => 'unsafe-gallery-image',
            'status' => 'draft',
            'media_kind' => 'image',
            'media' => UploadedFile::fake()->create('active.svg', 1, 'image/svg+xml'),
        ])->assertSessionHasErrors('media');

        $this->assertDatabaseMissing('content_items', ['slug' => 'unsafe-gallery-image']);
    }
}
